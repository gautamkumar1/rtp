package com.engine.math.dto;

import java.math.BigDecimal;

public class ResultWinInfoLineDTO 
{
	//-- Symbol
	private Integer sb;
			
	//-- Line
	private Integer ln;
	
	//-- Count
	private Integer cn;
	
	//-- Direction
	private String dr;
			
	//-- Odd
	private BigDecimal od = BigDecimal.ZERO;
			
	//-- Multiplier
	private Integer mul = 1;

	//-- Total Odd
	private BigDecimal tod = BigDecimal.ZERO;

	public Integer getSb() {
		return sb;
	}

	public void setSb(Integer sb) {
		this.sb = sb;
	}

	public Integer getLn() {
		return ln;
	}

	public void setLn(Integer ln) {
		this.ln = ln;
	}

	public Integer getCn() {
		return cn;
	}

	public void setCn(Integer cn) {
		this.cn = cn;
	}

	public String getDr() {
		return dr;
	}

	public void setDr(String dr) {
		this.dr = dr;
	}

	public BigDecimal getOd() {
		return od;
	}

	public void setOd(BigDecimal od) {
		this.od = od;
	}

	public Integer getMul() {
		return mul;
	}

	public void setMul(Integer mul) {
		this.mul = mul;
	}

	public BigDecimal getTod() {
		return tod;
	}

	public void setTod(BigDecimal tod) {
		this.tod = tod;
	}
}
