package com.engine.math.model.mm006;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.helper.StringUtil;

import com.engine.math.common.SecureRNG;
import com.engine.math.dto.ReelStripDTO;
import com.engine.math.dto.ResultGroupWayDTO;
import com.engine.math.dto.ResultInfoWayDTO;
import com.engine.math.dto.ResultSetWayDTO;
import com.engine.math.dto.ResultWinInfoWayDTO;
import com.google.gson.Gson;

/*************************************************************
	Category 6 - Tumble (6x5)
**************************************************************/
public class MathModel006
{
	private PayTable payTable = new PayTable();
	
	public String GetJsonReelStrip(int mode) throws Exception
	{
		ReelStripDTO dto = new ReelStripDTO();
		
        for (int i = 0; i < Strips.base.length ; i++) {
        	dto.setBg(StringUtil.isBlank(dto.getBg()) ? "" : (dto.getBg() + "|"));
        	for (int j = 0; j < Strips.base[i].length ; j++)
        		dto.setBg((j == 0 ? dto.getBg() : (dto.getBg() + ",")) + Strips.base[i][j]);
        }
      
        for (int i = 0; i < Strips.free.length ; i++) {
        	dto.setFg(StringUtil.isBlank(dto.getFg()) ? "" : (dto.getFg() + "|"));
        	for (int j = 0; j < Strips.free[i].length ; j++)
        		dto.setFg((j == 0 ? dto.getFg() : (dto.getFg() + ",")) + Strips.free[i][j]);
        }

		return new Gson().toJson(dto, ReelStripDTO.class);
	}
	
	public String GetJsonResult(int mode) throws Exception
	{
		ResultGroupWayDTO dto = GetResult(mode);
		if(dto != null)
			return new Gson().toJson(dto, ResultGroupWayDTO.class);
		return null;
	}
	
	private ResultGroupWayDTO GetResult(int mode) throws Exception
	{
		ResultGroupWayDTO group = new ResultGroupWayDTO();
		
		int setCount = 0;
		
		int triggerFreeSpin = 0;
		
		//--- Base Game ---
		
		Integer[][] reelStrips = GetReelStrips(GameState.BASE);
		
		InputData inputData = new InputData();
		inputData.setState(GameState.BASE);
		inputData.setMode(mode);
		inputData.setStopPositions(RandomPositions(reelStrips, GameState.BASE, mode));
		inputData.setResults(ClearResults());
		inputData.setResultPositions(ClearResults());
		inputData.getEliminatePositions().clear();
		for(int i=0; i<Constant.ReelHeight.length; i++)
			inputData.getEliminatePositions().add(new ArrayList<Integer>());

		ResultSetWayDTO set = new ResultSetWayDTO();
		set.setId(setCount++);
		
		do
		{
			ResultInfoWayDTO info = GenerateResult(reelStrips, inputData);
			set.getIn().add(info);
		} 
		while(inputData.getRespin() > 0);

		for(int i=0; i<set.getIn().size(); i++)
			set.setOd(set.getOd().add(set.getIn().get(i).getTod()));
		set.setMul(1);
		set.setTod(set.getOd().multiply(new BigDecimal(set.getMul())));
		
		triggerFreeSpin = inputData.getTriggerFreeSpin();
		if(triggerFreeSpin > 0)
		{
			set.setFsg(triggerFreeSpin);
			inputData.setTriggerFreeSpin(0);
		}

		group.getSet().add(set);
		
		group.setBod(set.getTod());
		
		//--- Free Game ---
		if(triggerFreeSpin > 0)
		{
			inputData.setState(GameState.FREE);
			reelStrips = GetReelStrips(GameState.FREE);
	
			BigDecimal totalFreeSpinOdd = BigDecimal.ZERO;
			inputData.setMultiplier(0);
			
			for (int freeSpin = 0; freeSpin < triggerFreeSpin; freeSpin++)
			{
				inputData.setRespin(0);
				inputData.setRespinCount(0);
				inputData.setMultiplier(0);
				inputData.setCumulativeWin(BigDecimal.ZERO);
				inputData.setStopPositions(RandomPositions(reelStrips, GameState.FREE, mode));
				inputData.setResults(ClearResults());
				inputData.setResultPositions(ClearResults());
				inputData.getEliminatePositions().clear();
				for(int i=0; i<Constant.ReelHeight.length; i++)
					inputData.getEliminatePositions().add(new ArrayList<Integer>());
				
				set = new ResultSetWayDTO();
				set.setId(setCount++);
				
				do
				{
					ResultInfoWayDTO info = GenerateResult(reelStrips, inputData);
					set.getIn().add(info);
				} 
				while(inputData.getRespin() > 0);

				for(int i=0; i<set.getIn().size(); i++)
					set.setOd(set.getOd().add(set.getIn().get(i).getTod()));
				set.setMul(1);
				set.setTod(set.getOd().multiply(new BigDecimal(set.getMul())));
				
				set.setFsl((triggerFreeSpin-1) - freeSpin);
			
				int addNewFreeSpin = inputData.getTriggerFreeSpin();
				if(addNewFreeSpin > 0)
				{
					set.setFsg(addNewFreeSpin);
					triggerFreeSpin += addNewFreeSpin;
					inputData.setTriggerFreeSpin(0);
				}
				
				group.getSet().add(set);
				
				totalFreeSpinOdd = totalFreeSpinOdd.add(set.getTod());
			}
			
			group.setFod(totalFreeSpinOdd);
		}
		
		group.setTod(group.getBod().add(group.getFod()));
		
		return group;
	}
	
	private ResultInfoWayDTO GenerateResult(Integer[][] reelStrips, InputData inputData) throws Exception
	{
		ResultInfoWayDTO dto = new ResultInfoWayDTO();
		
		//- Assign stop point.
		if(inputData.getRespinCount() == 0)
		{
			for (int i = 0; i < inputData.getStopPositions().length ; i++)
				dto.setSp((dto.getSp() == null ? "" : (dto.getSp() + ",")) + inputData.getStopPositions()[i]);
		}
		
		//- Assign results.
		int position;
		for(int i=0; i<inputData.getResults().length; i++)
		{
			position = inputData.getStopPositions()[i] + inputData.getResults()[i].length - 2;
			
			for(int j=inputData.getResults()[i].length-1; j>=0; j--)
			{
				if (position < 0)
				    position += reelStrips[i].length;
				position %= reelStrips[i].length;

				while (inputData.getEliminatePositions().size() > i && inputData.getEliminatePositions().get(i).contains(position))
				{
					position--;
					if (position < 0)
						position += reelStrips[i].length;
				}
				
				inputData.getResults()[i][j] = reelStrips[i][position];
				inputData.getResultPositions()[i][j] = position;
				position--;
			}
		}
		
		//- Check pays
		int symbolCount;

		for(Integer key: payTable.payout.keySet())
		{
			int symbol = key;
			symbolCount = 0;
			 
			for (int i = 0; i < Constant.ReelHeight.length; i++)
			{
				for (int j = 0; j < Constant.ReelHeight[j]; j++)
				{
					if (inputData.getResults()[i][j] == symbol)
					{
						symbolCount++;
					}
				}
			}
			
			if (symbolCount > 7)
			{
				Integer[] payout = payTable.payout.get(key);
				 
				ResultWinInfoWayDTO winInfo = new ResultWinInfoWayDTO();
				winInfo.setSb(key);
				winInfo.setNok(symbolCount);
				winInfo.setOd(new BigDecimal(payout[symbolCount > 12 ? 12 : symbolCount -1]));
				winInfo.setMul(1);
				winInfo.setTod(winInfo.getOd().multiply(new BigDecimal(winInfo.getMul())));
				dto.getWl().add(winInfo);
				
				dto.setOd(dto.getOd().add(winInfo.getTod()));
				inputData.setCumulativeWin(inputData.getCumulativeWin().add(winInfo.getTod()));
			}
		}
		
		//- Final results.
		for(int i=0; i<inputData.getResults().length; i++)
		{
			dto.setRs(dto.getRs() == null ? "" : (dto.getRs() + "|"));
			for(int j=0; j<inputData.getResults()[i].length; j++)
			{
				String result = "" + inputData.getResults()[i][j];
				dto.setRs((j == 0 ? dto.getRs() : (dto.getRs() + ",")) + result);
			}
		}
		
		inputData.setRespin(0);

		//- Cascade and reassign when have win.
		if(dto.getWl().size() > 0)
		{
			for(int index=0; index<dto.getWl().size(); index++)
			{
				if(dto.getWl().get(index).getSb() > 20) //F&B symbol will not eliminate
					continue;
				
				for (int i = 0; i < inputData.getResults().length; i++)
				{
					for(int j=0; j<inputData.getResults()[i].length; j++)
					{
						if(inputData.getResults()[i][j] == dto.getWl().get(index).getSb()) {
							inputData.getEliminatePositions().get(i).add(inputData.getResultPositions()[i][j]);
							inputData.setRespin(1);
						}
					}
				}
			}
			
			inputData.setRespinCount(inputData.getRespinCount() + 1);
		}

		if(inputData.getRespin() == 0)
		{
			//-- Assign bonus multiplier.
			if(inputData.getCumulativeWin().compareTo(BigDecimal.ZERO) > 0)
			{
				String bonusProgress = CheckBonus(inputData);
				if(bonusProgress != "")
				{
					dto.setPgs("BONUS?" + bonusProgress);
					
					ResultWinInfoWayDTO winInfo = new ResultWinInfoWayDTO();
					winInfo.setSb(Symbol.B);
					winInfo.setNok(1);
					winInfo.setOd(inputData.getCumulativeWin());
					winInfo.setMul(inputData.getMultiplier()-1);
					winInfo.setTod(winInfo.getOd().multiply(new BigDecimal(winInfo.getMul())));
					dto.getWl().add(winInfo);
					
					dto.setOd(dto.getOd().add(winInfo.getTod()));
				}
			}
			
			//-- Random generate scatter.
			if(inputData.getRespinCount() == 0)
			{
				if(this.AssignScatter(inputData))
				{
					//- Re-assign final results.
					dto.setRs(null);
					for(int i=0; i<inputData.getResults().length; i++)
					{
						dto.setRs(dto.getRs() == null ? "" : (dto.getRs() + "|"));
						for(int j=0; j<inputData.getResults()[i].length; j++)
						{
							String result = "" + inputData.getResults()[i][j];
							dto.setRs((j == 0 ? dto.getRs() : (dto.getRs() + ",")) + result);
						}
					}
				}
			}

			Integer scatterCount = 0;
			Integer threshold = 3;
			Integer freeSpins = 10;
			
			if (inputData.getState() == GameState.FREE) {
	            threshold = 2;
	            freeSpins = 5;
	        }
			
			for (int i = 0; i < inputData.getResults().length; i++)
			{
				for(int j=0; j<inputData.getResults()[i].length; j++)
				{
					if(inputData.getResults()[i][j] == Symbol.F)
						scatterCount++;
				}
			}

			if(scatterCount > threshold)
			{
				Integer[] payout = payTable.payout.get(Symbol.F);
				
				ResultWinInfoWayDTO winInfo = new ResultWinInfoWayDTO();
				winInfo.setSb(Symbol.F);
				winInfo.setNok(scatterCount);
				winInfo.setOd(new BigDecimal(payout[scatterCount-1]).multiply(new BigDecimal(Constant.ReelCost)));
				winInfo.setMul(1);
				winInfo.setTod(winInfo.getOd().multiply(new BigDecimal(winInfo.getMul())));
				dto.getWl().add(winInfo);
				
				dto.setOd(dto.getOd().add(winInfo.getTod()));
				
				inputData.setTriggerFreeSpin(freeSpins);
			}
		}

		dto.setMul(1);
		dto.setTod(dto.getOd().multiply(new BigDecimal(dto.getMul())));
		
		return dto;
	}

	private Integer[][] GetReelStrips(int State)
	{
		Integer[][] newStrips = new Integer[Constant.ReelHeight.length][];
		int[][] strips = null;
		
		if(State == GameState.BASE)
			strips = Strips.base;
    	else if(State == GameState.FREE)
    		strips = Strips.free;
		
        for (int i = 0; i < newStrips.length ; i++) {
        	newStrips[i] = new Integer[strips[i].length];
        	for (int j = 0; j < newStrips[i].length ; j++)
        		newStrips[i][j]  = strips[i][j];
        }
        
        return newStrips;
	}	
	
	private Integer[][] ClearResults() 
	{
		Integer[][] results = new Integer[Constant.ReelHeight.length][];
        for (int i = 0; i < results.length; i++)
        	results[i] = new Integer[Constant.ReelHeight[i]];
        return results;
	}
	
	private Integer[] RandomPositions(Integer[][] reelStrips, int state, int mode) throws NoSuchAlgorithmException
	{
		Integer[] stopPositions = new Integer[reelStrips.length];
		
		if(state == GameState.BASE && mode > 2)
		{
			stopPositions = new Integer[] { 0, 0, 0, 0, 0, 0 };
		}
		else
		{
			for (int i = 0; i < stopPositions.length; i++)
	        	stopPositions[i] = RandomChoose(0, reelStrips[i].length-1);
		}
		
        return stopPositions;
	}
	
	private Integer RandomScatter(int mode) throws NoSuchAlgorithmException
	{
		int totalWeight = 0;
		
		int[][] weights =  Constant.GetRandomScatter(mode);
		
		for (int i = 0; i < weights.length ; i++) {
        	totalWeight += weights[i][1];
        }
		
		int randomWeight = RandomChoose(0, totalWeight-1) + 1;
		
		for (int i = 0; i < weights.length; i++)
	    {
	        if (randomWeight <= weights[i][1])
	        	return weights[i][0];
	        else
	        	randomWeight -= weights[i][1];
	    }
		return weights[weights.length][0];
	}
	
	private Integer GetMultiplier(int mode) throws NoSuchAlgorithmException
	{
		int totalWeight = 0;
		
		int[][] weights =  Constant.GetMultiplier(mode);
		
		for (int i = 0; i < weights.length ; i++) {
        	totalWeight += weights[i][1];
        }
		
		int randomWeight = RandomChoose(0, totalWeight-1) + 1;
		
		for (int i = 0; i < weights.length ; i++) {
			if (randomWeight <= weights[i][1])
	        	return weights[i][0];
	        else
	        	randomWeight -= weights[i][1];
        }
		return weights[weights.length][0];
	}
	
	private String CheckBonus(InputData inputData) throws NoSuchAlgorithmException
	{
		String bonus = "";
		for (int i = 0; i < inputData.getResults().length; i++)
		{
			for(int j=0; j<inputData.getResults()[i].length; j++)
			{
				if(inputData.getResults()[i][j] == Symbol.B)
				{
					int multiplier = GetMultiplier(inputData.getMode()); 
					
					int position = (int) (i + (Constant.ReelHeight.length * j));
					bonus += (bonus == "" ? "" : ",") + position + "=" + multiplier;
					
					inputData.setMultiplier(inputData.getMultiplier() + multiplier);
				}
			}
		}
		return bonus;
	}

	private Boolean AssignScatter(InputData inputData) throws NoSuchAlgorithmException
	{
		Boolean haveScatter = false;
		
		if (inputData.getState() == GameState.BASE)
		{
			if(inputData.getMode() < 3)
			{
				for (int j = 0; j < Constant.ReelHeight.length; j++)
                {
                    if (RandomScatter(inputData.getMode()) == 1)
                    {
                    	inputData.getResults()[j][RandomChoose(0,Constant.ReelHeight[j]-1)] = Symbol.F;
                    	haveScatter = true;
                    }
                }
			}
			else
			{
				List<Integer> column = new ArrayList<Integer>();
				for (int j = 0; j < Constant.ReelHeight.length; j++)
					column.add(j);
				
				int trigger = RandomScatter(inputData.getMode());
				for (int k = 0; k < 6 - trigger; k++)
					column.remove(RandomChoose(0,column.size()-1));
				
				for (int j = 0; j < column.size(); j++)
				{
					inputData.getResults()[column.get(j)][RandomChoose(0,Constant.ReelHeight[column.get(j)]-1)] = Symbol.F;
					haveScatter = true;
				}	
			}
		}
		
		return haveScatter;
	}
	
	private Integer RandomChoose(Integer min, Integer max) throws NoSuchAlgorithmException
	{
		return SecureRNG.nextInt(min, max);
	}
	
	public static void main(String[] args) throws Exception 
	{
		int mode = Mode.R90;
		
		BigDecimal miniBet = BigDecimal.ZERO;
		if(mode == Mode.R90 || mode == Mode.R93 || mode == Mode.R96)
			miniBet = new BigDecimal(20);
		else if(mode == Mode.R90_Buy || mode == Mode.R93_Buy || mode == Mode.R96_Buy)
			miniBet = new BigDecimal(1000);
		
		int sample = 10000000;

		BigDecimal bet = BigDecimal.ZERO;
		BigDecimal baseWin = BigDecimal.ZERO;
		BigDecimal freeWin = BigDecimal.ZERO;
		BigDecimal maxWin = BigDecimal.ZERO;
		int hit = 0;
		int freeSpins = 0;
		int feature = 0;
		
		MathModel006 gs = new MathModel006();
	   
		for(int spins=1; spins<=sample ; spins++)
		{
			bet = bet.add(miniBet);
			
			ResultGroupWayDTO dto = gs.GetResult(mode);
			baseWin = baseWin.add(dto.getBod());
			freeWin = freeWin.add(dto.getFod());

			if(dto.getSet().size() > 1) {
				 feature++;
				 freeSpins += (dto.getSet().size()-1);
			}
			
			if(dto.getTod().compareTo(BigDecimal.ZERO) > 0)
			{
				hit++;
				if(dto.getTod().compareTo(maxWin) > 0) {
					maxWin = dto.getTod();
				}
			}

			if (spins % 2000 == 0)
			{
				System.out.println("Spins / Sample: " + spins + " / " + sample);
				System.out.println("BaseGameRTP: " + baseWin.divide(bet, 6, RoundingMode.HALF_EVEN).multiply(new BigDecimal(100)).setScale(3, RoundingMode.HALF_EVEN) + "%");
				System.out.println("FreeGameRTP: " + freeWin.divide(bet, 6, RoundingMode.HALF_EVEN).multiply(new BigDecimal(100)).setScale(3, RoundingMode.HALF_EVEN) + "%");
				System.out.println("TotalGameRTP: " + baseWin.add(freeWin).divide(bet, 6, RoundingMode.HALF_EVEN).multiply(new BigDecimal(100)).setScale(3, RoundingMode.HALF_EVEN) + "%");
				System.out.println("HitRate: " + new BigDecimal(((float)hit / (float)spins) * 100).setScale(3, RoundingMode.HALF_EVEN) + "%");
				System.out.println("FeatureFrequency: " + new BigDecimal(feature == 0 ? 0 : ((float)spins / (float)feature)).setScale(3, RoundingMode.HALF_EVEN));
				System.out.println("AverageFreeSpins: " + new BigDecimal(feature == 0 ? 0 : ((float)freeSpins / (float)feature)).setScale(3, RoundingMode.HALF_EVEN));
				System.out.println("MaxWin: " + maxWin.divide(miniBet, 3, RoundingMode.DOWN));
				System.out.println("-");
			}
		}
	}
}
