package com.engine.math.model.mm006;

public class Mode 
{
	//0:Normal_90.2%,1:Normal_93%,2:Normal:96%,3:Buy_90.5%,4:Buy_93.5%,5:Buy:96.5%
	
	public static int R90 = 0;
	public static int R93 = 1;
	public static int R96 = 2;
	public static int R90_Buy = 3;
	public static int R93_Buy = 4;
	public static int R96_Buy = 5;
}
