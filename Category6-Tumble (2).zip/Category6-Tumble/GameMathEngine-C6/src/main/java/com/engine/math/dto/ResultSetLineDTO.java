package com.engine.math.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ResultSetLineDTO 
{
	private Integer id;
	
	//-- Info
	private List<ResultInfoLineDTO> in = new ArrayList<ResultInfoLineDTO>();
	
	//-- Odd
	private BigDecimal od = BigDecimal.ZERO;
		
	//-- Multiplier
	private Integer mul = 1;

	//-- Total Odd
	private BigDecimal tod = BigDecimal.ZERO;
	
	//-- Progress
	private String pgs;
	
	//-- Free Spin Given
	private Integer fsg;
	
	//-- Free Spin Left
	private Integer fsl;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public List<ResultInfoLineDTO> getIn() {
		return in;
	}

	public void setIn(List<ResultInfoLineDTO> in) {
		this.in = in;
	}

	public BigDecimal getOd() {
		return od;
	}

	public void setOd(BigDecimal od) {
		this.od = od;
	}

	public Integer getMul() {
		return mul;
	}

	public void setMul(Integer mul) {
		this.mul = mul;
	}

	public BigDecimal getTod() {
		return tod;
	}

	public void setTod(BigDecimal tod) {
		this.tod = tod;
	}

	public String getPgs() {
		return pgs;
	}

	public void setPgs(String pgs) {
		this.pgs = pgs;
	}

	public Integer getFsg() {
		return fsg;
	}

	public void setFsg(Integer fsg) {
		this.fsg = fsg;
	}

	public Integer getFsl() {
		return fsl;
	}

	public void setFsl(Integer fsl) {
		this.fsl = fsl;
	}
}
