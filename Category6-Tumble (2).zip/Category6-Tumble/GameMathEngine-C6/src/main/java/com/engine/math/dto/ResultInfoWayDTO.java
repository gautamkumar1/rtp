package com.engine.math.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ResultInfoWayDTO 
{
	//-- Result
	private String rs;
	
	//-- Stop point
	private String sp;
	
	//-- Win Info
	private List<ResultWinInfoWayDTO> wl = new ArrayList<ResultWinInfoWayDTO>();
	
	//-- Odd
	private BigDecimal od = BigDecimal.ZERO;
		
	//-- Multiplier
	private Integer mul = 1;

	//-- Total Odds
	private BigDecimal tod = BigDecimal.ZERO;
	
	//-- Progress
	private String pgs;

	public String getRs() {
		return rs;
	}

	public void setRs(String rs) {
		this.rs = rs;
	}

	public String getSp() {
		return sp;
	}

	public void setSp(String sp) {
		this.sp = sp;
	}

	public List<ResultWinInfoWayDTO> getWl() {
		return wl;
	}

	public void setWl(List<ResultWinInfoWayDTO> wl) {
		this.wl = wl;
	}

	public BigDecimal getOd() {
		return od;
	}

	public void setOd(BigDecimal od) {
		this.od = od;
	}

	public Integer getMul() {
		return mul;
	}

	public void setMul(Integer mul) {
		this.mul = mul;
	}

	public BigDecimal getTod() {
		return tod;
	}

	public void setTod(BigDecimal tod) {
		this.tod = tod;
	}

	public String getPgs() {
		return pgs;
	}

	public void setPgs(String pgs) {
		this.pgs = pgs;
	}
}
