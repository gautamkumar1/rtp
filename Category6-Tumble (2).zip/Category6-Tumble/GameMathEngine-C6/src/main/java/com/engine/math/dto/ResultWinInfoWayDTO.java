package com.engine.math.dto;

import java.math.BigDecimal;

public class ResultWinInfoWayDTO 
{
	//-- Symbol
	private Integer sb;
			
	//-- Number of kind
	private Integer nok;
	
	//-- Way Count
	private Integer cn;
			
	//-- Odd
	private BigDecimal od = BigDecimal.ZERO;
			
	//-- Multiplier
	private Integer mul = 1;

	//-- Total Odd
	private BigDecimal tod = BigDecimal.ZERO;

	public Integer getSb() {
		return sb;
	}

	public void setSb(Integer sb) {
		this.sb = sb;
	}

	public Integer getNok() {
		return nok;
	}

	public void setNok(Integer nok) {
		this.nok = nok;
	}

	public Integer getCn() {
		return cn;
	}

	public void setCn(Integer cn) {
		this.cn = cn;
	}

	public BigDecimal getOd() {
		return od;
	}

	public void setOd(BigDecimal od) {
		this.od = od;
	}

	public Integer getMul() {
		return mul;
	}

	public void setMul(Integer mul) {
		this.mul = mul;
	}

	public BigDecimal getTod() {
		return tod;
	}

	public void setTod(BigDecimal tod) {
		this.tod = tod;
	}
}
