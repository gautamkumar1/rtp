package com.engine.math.model.mm006;

import java.util.HashMap;

public class PayTable 
{
	public HashMap<Integer, Integer[]> payout = new HashMap<Integer, Integer[]>();
	
	public PayTable()
    {
		payout.put(Symbol.H1, new Integer[] { 0, 0, 0, 0, 0, 0, 0, 200, 200, 500, 500, 1000, 1000, 1000, 1000 });
		payout.put(Symbol.H2, new Integer[] { 0, 0, 0, 0, 0, 0, 0, 50, 50, 200, 200, 500, 500, 500, 500 });
		payout.put(Symbol.H3, new Integer[] { 0, 0, 0, 0, 0, 0, 0, 40, 40, 100, 100, 300, 300, 300, 300 });
		payout.put(Symbol.H4, new Integer[] { 0, 0, 0, 0, 0, 0, 0, 30, 30, 40, 40, 240, 240, 240, 240 });
		payout.put(Symbol.N1, new Integer[] { 0, 0, 0, 0, 0, 0, 0, 20, 20, 30, 30, 200, 200, 200, 200 });
		payout.put(Symbol.N2, new Integer[] { 0, 0, 0, 0, 0, 0, 0, 16, 16, 24, 24, 160, 160, 160, 160 });
		payout.put(Symbol.N3, new Integer[] { 0, 0, 0, 0, 0, 0, 0, 10, 10, 20, 20, 100, 100, 100, 100 });
		payout.put(Symbol.N4, new Integer[] { 0, 0, 0, 0, 0, 0, 0, 8, 8, 18, 18, 80, 80, 80, 80 });
		payout.put(Symbol.N5, new Integer[] { 0, 0, 0, 0, 0, 0, 0, 5, 5, 15, 15, 40, 40, 40, 40 });
		payout.put(Symbol.F, new Integer[] { 0, 0, 0, 3, 5, 100 });
    }
}
