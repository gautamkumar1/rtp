package com.engine.math.model.mm006;

public class Symbol 
{
	public static Integer NU = 0;
	public static Integer H1 = 1;
	public static Integer H2 = 2;
	public static Integer H3 = 3;
	public static Integer H4 = 4;
	public static Integer N1 = 11;
	public static Integer N2 = 12;
	public static Integer N3 = 13;
	public static Integer N4 = 14;
	public static Integer N5 = 15;
	public static Integer F = 31;
	public static Integer B = 41;
}
