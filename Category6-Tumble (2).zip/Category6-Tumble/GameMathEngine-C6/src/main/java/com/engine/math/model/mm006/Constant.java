package com.engine.math.model.mm006;

public class Constant 
{	
	public static int ReelCost = 20;
	
	public static int[] ReelHeight = { 5, 5, 5, 5, 5, 5 };
	
	public static int[][] GetMultiplier(int Mode)
	{
		return new int[][] { 
			new int[] { 2,105 }, 
			new int[] { 3,105 }, 
			new int[] { 5,105 }, 
			new int[] { 8,25 }, 
			new int[] { 10,13 }, 
			new int[] { 12,8 }, 
			new int[] { 15,4 }, 
			new int[] { 18,3 }, 
			new int[] { 20,2 }, 
			new int[] { 25,1 }, 
			new int[] { 30,1 }, 
			new int[] { 35,1 }, 
			new int[] { 50,1 }, 
			new int[] { 100,1 } };
	}
	
	public static int[][] GetRandomScatter(int Mode)
	{
		int[][] weight = new int[2][2];
		
		if(Mode == 0) {
			weight = new int[][] { new int[] { 1,6 }, new int[] { 0,29 } };
		}
		else if(Mode == 1) {
			weight = new int[][] { new int[] { 1,10 }, new int[] { 0,47 } };
		}
		else if(Mode == 2) {
			weight = new int[][] { new int[] { 1,7 }, new int[] { 0,32 } };
		}
		else if(Mode == 3) {
			weight = new int[][] { new int[] { 4,10000 }, new int[] { 5,5000 }, new int[] { 6,295 } };
		}
		else if(Mode == 4) {
			weight = new int[][] { new int[] { 4,10000 }, new int[] { 5,5000 }, new int[] { 6,542 } };
		}
		else if(Mode == 5) {
			weight = new int[][] { new int[] { 4,10000 }, new int[] { 5,5000 }, new int[] { 6,797 } };
		}
		
		return weight;
	}
}

