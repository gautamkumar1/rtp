package com.engine.math.model.mm006;

public class GameState
{
	public static Integer BASE = 0;
	public static Integer FREE = 1;
}
