package com.engine.math.model.mm006;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class InputData 
{
	private Integer mode = 0;
	
	private Integer state = 0;
	
	private Integer multiplier = 0;
	
	private Integer respin = 0;
	
	private Integer respinCount = 0;
	
	private Integer triggerFreeSpin = 0;
	
	private BigDecimal cumulativeWin = BigDecimal.ZERO;
	
	private Integer[] stopPositions = null;
	
	private Integer[][] results = null;
	
	private Integer[][] resultPositions = null;
	
	private List<ArrayList<Integer>> eliminatePositions = new ArrayList<ArrayList<Integer>>();

	public Integer getMode() {
		return mode;
	}

	public void setMode(Integer mode) {
		this.mode = mode;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getMultiplier() {
		return multiplier;
	}

	public void setMultiplier(Integer multiplier) {
		this.multiplier = multiplier;
	}

	public Integer getRespin() {
		return respin;
	}

	public void setRespin(Integer respin) {
		this.respin = respin;
	}

	public Integer getRespinCount() {
		return respinCount;
	}

	public void setRespinCount(Integer respinCount) {
		this.respinCount = respinCount;
	}

	public Integer getTriggerFreeSpin() {
		return triggerFreeSpin;
	}

	public void setTriggerFreeSpin(Integer triggerFreeSpin) {
		this.triggerFreeSpin = triggerFreeSpin;
	}

	public BigDecimal getCumulativeWin() {
		return cumulativeWin;
	}

	public void setCumulativeWin(BigDecimal cumulativeWin) {
		this.cumulativeWin = cumulativeWin;
	}

	public Integer[] getStopPositions() {
		return stopPositions;
	}

	public void setStopPositions(Integer[] stopPositions) {
		this.stopPositions = stopPositions;
	}

	public Integer[][] getResults() {
		return results;
	}

	public void setResults(Integer[][] results) {
		this.results = results;
	}

	public Integer[][] getResultPositions() {
		return resultPositions;
	}

	public void setResultPositions(Integer[][] resultPositions) {
		this.resultPositions = resultPositions;
	}

	public List<ArrayList<Integer>> getEliminatePositions() {
		return eliminatePositions;
	}

	public void setEliminatePositions(List<ArrayList<Integer>> eliminatePositions) {
		this.eliminatePositions = eliminatePositions;
	}
}
