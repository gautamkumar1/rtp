package com.engine.math.dto;

public class ReelStripDTO 
{
	private String bg;
	
	private String fg;

	public String getBg() {
		return bg;
	}

	public void setBg(String bg) {
		this.bg = bg;
	}

	public String getFg() {
		return fg;
	}

	public void setFg(String fg) {
		this.fg = fg;
	}
}
