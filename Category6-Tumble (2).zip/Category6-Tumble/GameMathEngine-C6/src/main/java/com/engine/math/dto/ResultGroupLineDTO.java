package com.engine.math.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ResultGroupLineDTO 
{
	//-- Set
	private List<ResultSetLineDTO> set = new ArrayList<ResultSetLineDTO>();

	//-- Base Odd
	private BigDecimal bod = BigDecimal.ZERO;
	
	//-- Free Spin Odd
	private BigDecimal fod = BigDecimal.ZERO;
		
	//-- Total Odd
	private BigDecimal tod = BigDecimal.ZERO;

	public List<ResultSetLineDTO> getSet() {
		return set;
	}

	public void setSet(List<ResultSetLineDTO> set) {
		this.set = set;
	}

	public BigDecimal getBod() {
		return bod;
	}

	public void setBod(BigDecimal bod) {
		this.bod = bod;
	}

	public BigDecimal getFod() {
		return fod;
	}

	public void setFod(BigDecimal fod) {
		this.fod = fod;
	}

	public BigDecimal getTod() {
		return tod;
	}

	public void setTod(BigDecimal tod) {
		this.tod = tod;
	}
}
