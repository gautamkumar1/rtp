package main

import (
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"os/exec"
	"slices"
	"slot_framework/pkg/utils"
	"strings"
)

type RouterGenCfg struct {
	ControllerPath  string   //工程内的相对路径，例如 ： /internal/controller
	RouterPackage   string   // router
	RouterPath      string   //工程内的相对路径，例如： /internal/router
	InjectFuncName  string   // 生成注册文件的函数名称， 例如：GenRouterInjects
	InjectFilePath  string   // 生成注册文件的路径， 例如：/internal/inject
	InjectPackage   string   // 生成注册文件的包名， 例如：inject
	IgnoreFileNames []string // 不需要自动生成的文件名
}

func main() {
	generateCodeByConf(&RouterGenCfg{
		ControllerPath:  "/internal/controller",
		RouterPackage:   "router",
		RouterPath:      "/internal/router",
		InjectFuncName:  "GenRouterInjects",
		InjectFilePath:  "/internal/inject",
		InjectPackage:   "inject",
		IgnoreFileNames: []string{"doc_generate_controller.go"},
	})
}

func generateCodeByConf(cfg *RouterGenCfg) {
	projectPath, _ := os.Getwd()
	projectPaths := strings.Split(projectPath, "/")
	projectName := projectPaths[len(projectPaths)-1]
	controllerPath := utils.StringUtil.JoinPaths(projectPath, cfg.ControllerPath)
	controllerImport := utils.StringUtil.JoinPaths(projectName, cfg.ControllerPath)
	routerImport := utils.StringUtil.JoinPaths(projectName, cfg.RouterPath)
	routerPackage := cfg.RouterPackage
	routerPath := utils.StringUtil.JoinPaths(projectPath, cfg.RouterPath)
	dir, err := os.ReadDir(controllerPath)
	if err != nil {
		panic("读取controller目录错误")
	}
	apiInfoList := make([]*ApiInfo, 0)
	for i := range dir {
		if !dir[i].IsDir() && strings.HasSuffix(dir[i].Name(), ".go") {
			fileName := dir[i].Name()
			if len(cfg.IgnoreFileNames) > 0 && slices.Contains(cfg.IgnoreFileNames, fileName) {
				continue
			}
			controllerFile, fileErr := os.ReadFile(controllerPath + "/" + fileName)
			if fileErr != nil {
				panic(fileName + ",读取文件错误")
			}
			fileSet := token.NewFileSet()
			astFile, astParseErr := parser.ParseFile(fileSet, fileName, controllerFile, parser.ParseComments)
			if astParseErr != nil {
				panic(fileName + ",解析抽象语法树错误")
			}
			controllerPackage := astFile.Name.String()
			controllerName := ""
			for s := range astFile.Scope.Objects {
				controllerStruct := astFile.Scope.Objects[s]
				if controllerStruct.Kind == ast.Typ && strings.HasSuffix(controllerStruct.Name, "Controller") {
					controllerName = controllerStruct.Name
					break
				}
			}

			routers := make([]*RouteInfo, 0)
			routerGroup := ""
			for j := range astFile.Comments {
				commentList := astFile.Comments[j].List
				routeInfo := parseCommentAsRouteInfo(astFile, commentList)
				if routeInfo != nil {
					routerGroup = commonRouterPrefix(routerGroup, routeInfo.FullRoute)
					routers = append(routers, routeInfo)
				}
			}
			if strings.HasSuffix(routerGroup, "/") {
				routerGroup = routerGroup[0 : len(routerGroup)-1]
			}
			for m := range routers {
				routers[m].ShortRoute = routers[m].FullRoute[len(routerGroup):]
			}

			apiInfo := &ApiInfo{
				RouterGroup:       routerGroup,
				ControllerName:    controllerName,
				ControllerPackage: controllerPackage,
				ControllerImport:  controllerImport,
				RouterPackage:     routerPackage,
				RouterStructName:  strings.Replace(controllerName, "Controller", "Router", -1),
				Routers:           routers,
				GoBuild:           parseGoBuildComment(astFile.Comments),
			}
			apiInfoList = append(apiInfoList, apiInfo)
			writeRouterGenFile(apiInfo, routerPath+"/zz_"+utils.StringUtil.CamelCaseToUnderScore(apiInfo.RouterStructName)+".gen.go")
		}
	}
	routerInjectFilePath := utils.StringUtil.JoinPaths(projectPath, cfg.InjectFilePath)
	writeRouterRegisters(apiInfoList, cfg, routerImport, routerInjectFilePath+"/z_router_injects.gen.go")
	//格式化代码
	_ = exec.Command("gofmt", "-w", routerPath).Run()
	_ = exec.Command("gofmt", "-w", routerInjectFilePath).Run()
}

func parseCommentAsRouteInfo(astFile *ast.File, commentList []*ast.Comment) *RouteInfo {
	routeInfo := &RouteInfo{}
	for k := range commentList {
		commentText := strings.TrimPrefix(commentList[k].Text, "//")
		commentText = strings.Trim(commentText, " ")
		if k == 0 {
			routeInfo.RouteName = commentText
		}
		if strings.HasPrefix(commentText, "@router") {
			method := "GET"
			if strings.HasSuffix(strings.ToLower(commentText), "[post]") {
				method = "POST"
			}
			fullRoute := commentText[len("@router"):(len(commentText) - len(method) - 2)]
			fullRoute = strings.Trim(fullRoute, " ")
			fullRoute = strings.Replace(fullRoute, "}", "", -1)
			fullRoute = strings.Replace(fullRoute, "{", ":", -1)
			routeInfo.FullRoute = fullRoute
			routeInfo.Method = method
		}
	}
	if routeInfo.FullRoute != "" && isRouteDoExists(astFile, routeInfo.RouteName) {
		return routeInfo
	}
	return nil
}

func parseGoBuildComment(commentGroups []*ast.CommentGroup) string {
	for i := range commentGroups {
		commentList := commentGroups[i].List
		for k := range commentList {
			if strings.Contains(commentList[k].Text, "go:build") {
				return commentList[k].Text
			}
		}
	}
	return ""
}

func isRouteDoExists(astFile *ast.File, routeName string) bool {
	if astFile.Scope.Lookup(routeName) != nil {
		return true
	}
	for i := range astFile.Decls {
		decl := astFile.Decls[i]
		funcDecl, ok := decl.(*ast.FuncDecl)
		if ok && funcDecl.Name.String() == routeName {
			return true
		}
	}
	return false
}

func writeRouterGenFile(apiInfo *ApiInfo, destPath string) {
	if len(apiInfo.Routers) > 0 && len(apiInfo.ControllerName) > 0 {
		routeDefinitions := make([]string, len(apiInfo.Routers))
		for i := range apiInfo.Routers {
			router := apiInfo.Routers[i]
			routerDefinition := RouterDefinitionTemplate
			routerDefinition = strings.Replace(routerDefinition, "{{Method}}", router.Method, -1)
			routerDefinition = strings.Replace(routerDefinition, "{{Route}}", router.ShortRoute, -1)
			routerDefinition = strings.Replace(routerDefinition, "{{ControllerName}}", apiInfo.ControllerName, -1)
			routerDefinition = strings.Replace(routerDefinition, "{{RouteName}}", router.RouteName, -1)
			routeDefinitions[i] = routerDefinition
		}

		routerSourceCode := RouterTemplate
		routerSourceCode = strings.Replace(routerSourceCode, "{{GoBuild}}", apiInfo.GoBuild, -1)
		routerSourceCode = strings.Replace(routerSourceCode, "{{RouterPackage}}", apiInfo.RouterPackage, -1)
		routerSourceCode = strings.Replace(routerSourceCode, "{{ControllerImport}}", apiInfo.ControllerImport, -1)
		routerSourceCode = strings.Replace(routerSourceCode, "{{RouterStructName}}", apiInfo.RouterStructName, -1)
		routerSourceCode = strings.Replace(routerSourceCode, "{{ControllerName}}", apiInfo.ControllerName, -1)
		routerSourceCode = strings.Replace(routerSourceCode, "{{ControllerPackage}}", apiInfo.ControllerPackage, -1)
		routerSourceCode = strings.Replace(routerSourceCode, "{{RouterGroup}}", apiInfo.RouterGroup, -1)
		routerSourceCode = strings.Replace(routerSourceCode, "{{RouterDefinitions}}", strings.Join(routeDefinitions, "\n"), -1)

		writeErr := os.WriteFile(destPath, []byte(routerSourceCode), 0644)
		if writeErr != nil {
			fmt.Println(writeErr)
		}
	}
}

func writeRouterRegisters(apiInfoList []*ApiInfo, cfg *RouterGenCfg, routerImport string, destPath string) {
	if len(apiInfoList) > 0 {
		webRegisters := make([]string, 0)
		controllerRegisters := make([]string, 0)
		for i := range apiInfoList {
			if len(apiInfoList[i].Routers) > 0 {
				webReg := WebRegisterTemplate
				webReg = strings.Replace(webReg, "{{RouterStructName}}", apiInfoList[i].RouterStructName, -1)
				webReg = strings.Replace(webReg, "{{RouterPackage}}", cfg.RouterPackage, -1)
				webRegisters = append(webRegisters, webReg)
				controllerReg := ControllerRegisterTemplate
				controllerReg = strings.Replace(controllerReg, "{{ControllerPackage}}", apiInfoList[i].ControllerPackage, -1)
				controllerReg = strings.Replace(controllerReg, "{{ControllerName}}", apiInfoList[i].ControllerName, -1)
				controllerRegisters = append(controllerRegisters, controllerReg)
			}
		}
		injectSourceCode := InjectTemplate
		injectSourceCode = strings.Replace(injectSourceCode, "{{GoBuild}}", apiInfoList[0].GoBuild, -1)
		injectSourceCode = strings.Replace(injectSourceCode, "{{RouterPackage}}", cfg.RouterPackage, -1)
		injectSourceCode = strings.Replace(injectSourceCode, "{{ControllerImport}}", apiInfoList[0].ControllerImport, -1)
		injectSourceCode = strings.Replace(injectSourceCode, "{{RouterImport}}", routerImport, -1)
		injectSourceCode = strings.Replace(injectSourceCode, "{{InjectPackage}}", cfg.InjectPackage, -1)
		injectSourceCode = strings.Replace(injectSourceCode, "{{InjectFuncName}}", cfg.InjectFuncName, -1)
		injectSourceCode = strings.Replace(injectSourceCode, "{{ControllerRegisters}}", strings.Join(controllerRegisters, "\n"), -1)
		injectSourceCode = strings.Replace(injectSourceCode, "{{WebRegisters}}", strings.Join(webRegisters, "\n"), -1)
		writeErr := os.WriteFile(destPath, []byte(injectSourceCode), 0644)
		if writeErr != nil {
			fmt.Println(writeErr)
		}
	}
}

func commonRouterPrefix(routerPrefix string, routerPath string) string {
	if routerPrefix == "" {
		return routerPath
	}
	if strings.HasPrefix(routerPath, routerPrefix) {
		return routerPrefix
	}

	routerPrefixWords := strings.Split(routerPrefix, "/")
	routerPathWords := strings.Split(routerPath, "/")

	commonLength := 0
	idx := 0
	for idx < len(routerPrefixWords) && idx < len(routerPathWords) {
		if routerPrefixWords[idx] != routerPathWords[idx] {
			break
		} else {
			wordLength := len(routerPrefixWords[idx])
			if wordLength > 0 {
				commonLength += wordLength + 1
			}
		}
		idx++
	}
	return routerPrefix[0:commonLength]
}

const RouterTemplate = `
//auto generated by router_gen/main.go.  DO NOT EDIT !!!
//auto generated by router_gen/main.go.  DO NOT EDIT !!!
//auto generated by router_gen/main.go.  DO NOT EDIT !!!
{{GoBuild}}

package {{RouterPackage}}
import (
	"slot_framework/pkg/web"
	"github.com/gin-gonic/gin"
	"go.uber.org/fx"
	"{{ControllerImport}}"
)

type {{RouterStructName}}Args struct {
	fx.In
	{{ControllerName}} *{{ControllerPackage}}.{{ControllerName}}
}

type {{RouterStructName}} struct {
	args *{{RouterStructName}}Args
}

func New{{RouterStructName}}(args {{RouterStructName}}Args) web.Router {
	return &{{RouterStructName}}{
		args: &args,
	}
}

func (r *{{RouterStructName}}) Handle(engine *gin.Engine) {
	group := engine.Group("{{RouterGroup}}")
	{{RouterDefinitions}}
}
`

const RouterDefinitionTemplate = `web.{{Method}}(group, "{{Route}}", r.args.{{ControllerName}}.{{RouteName}})`

const InjectTemplate = `
//auto generated by router_gen/main.go.  DO NOT EDIT !!!
//auto generated by router_gen/main.go.  DO NOT EDIT !!!
//auto generated by router_gen/main.go.  DO NOT EDIT !!!
{{GoBuild}}

package {{InjectPackage}}

import (
	"go.uber.org/fx"
	"slot_framework/pkg/web"
	"{{ControllerImport}}"
	"{{RouterImport}}"
)

func {{InjectFuncName}}() fx.Option {
	return fx.Options(
		{{ControllerRegisters}}
		{{WebRegisters}}
	)
}
`
const WebRegisterTemplate = `web.RegisterRouter({{RouterPackage}}.New{{RouterStructName}}),`
const ControllerRegisterTemplate = `fx.Provide({{ControllerPackage}}.New{{ControllerName}}),`

type ApiInfo struct {
	RouterGroup       string       // 例如 ： /api/front/index
	ControllerName    string       // 例如: IndexController
	ControllerPackage string       // 例如： controller
	ControllerImport  string       //例如 sp-front-api/internal/controller
	RouterPackage     string       //例如： router
	RouterStructName  string       //例如 IndexRouter
	Routers           []*RouteInfo //具体路由信息
	GoBuild           string       //可能包含go:build
}
type RouteInfo struct {
	RouteName  string // 例如 RecordNewList
	ShortRoute string // 例如 "/recordNewList"
	FullRoute  string // 例如 "/api/front/index/recordNewList"
	Method     string // 例如 POST , GET
}
