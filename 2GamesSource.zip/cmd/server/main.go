package main

import (
	"slot_framework/pkg/ioc"
	"slot_mi_game/internal/inject"
)

// 在 go.mod 所在目录下执行 swag init --parseDependency --parseInternal --tags=GameApi,CacheApi,DocGenApi -g ./cmd/server/main.go 生成 swagger 文档
// @title Slot-Game前端接口
// @version 1.0
func main() {
	baseInject, rootInject := inject.GetInjects()
	app := ioc.NewIOC(baseInject, rootInject)
	app.Run()
}
