package job

import (
	"context"
	"go.uber.org/fx"
	"slot_common/pkg/dao/es_dao"
	"slot_common/pkg/dao/mysql_dao"
	"slot_common/pkg/dto"
	"slot_common/pkg/model/mysql_model"
	"slot_framework/pkg/job"
	"slot_framework/pkg/log"
	"slot_framework/pkg/utils"
)

type EsRollbackRedoJobArgs struct {
	fx.In
	TblEsRollbackRedoLogDao *mysql_dao.TblEsRollbackRedoLogDao
	CommonIndexOperationDao *es_dao.CommonIndexOperationDao
}

type EsRollbackRedoJob struct {
	args *EsRollbackRedoJobArgs
	*job.AbstractLightningJob
}

func NewEsRollbackRedoJob(args EsRollbackRedoJobArgs, job *job.AbstractLightningJob) *EsRollbackRedoJob {
	return &EsRollbackRedoJob{
		args:                 &args,
		AbstractLightningJob: job,
	}
}

func (j *EsRollbackRedoJob) Cron() string {
	return "*/3 * * * * ?"
}

func (j *EsRollbackRedoJob) Name() string {
	return "EsRollbackRedoJob"
}

func (j *EsRollbackRedoJob) Execute(ctx context.Context) error {
	redoLogs, err := j.args.TblEsRollbackRedoLogDao.QueryRedoLog(ctx, 100)
	if err != nil {
		return err
	}
	if len(redoLogs) == 0 {
		return nil
	}
	deleteItems := make([]dto.EsIdDelItem, len(redoLogs))
	for i := range redoLogs {
		deleteItems[i] = dto.EsIdDelItem{
			Id:        redoLogs[i].RollbackID,
			IndexName: redoLogs[i].RollbackIndex,
		}
	}
	batchDeleteErr := j.args.CommonIndexOperationDao.BatchDelete(ctx, deleteItems)
	if batchDeleteErr != nil {
		return batchDeleteErr
	}
	ids := utils.SliceToOtherSlice(redoLogs, func(v1 *mysql_model.TblEsRollbackRedoLog) int64 {
		return v1.ID
	})
	log.Info(ctx, "ES回滚补偿操作成功，ids:{}", utils.JoinAnyAsString(ids, ","))
	_ = j.args.TblEsRollbackRedoLogDao.UpdateRetryCount(ctx, ids)
	return nil
}
