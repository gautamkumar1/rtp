package cache

import (
	"context"
	"errors"
	"go.uber.org/fx"
	"slot_common/pkg/constants"
	"slot_common/pkg/dao/mysql_dao"
	"slot_common/pkg/model/mysql_model"
	fwCache "slot_framework/pkg/cache"
	"slot_framework/pkg/conf"
	"slot_framework/pkg/log"
	"slot_framework/pkg/utils"
	"slot_mi_core/slotengine"
	"slot_mi_core/slotengine/scatter"
	"slot_mi_game/internal/constants/cache_name"
	"slot_mi_game/internal/engine"
	"strconv"
	"strings"
	"time"
)

type FruitySweetnessEngineCacheArgs struct {
	fx.In
	TblEngineReelsConfigDao *mysql_dao.TblEngineReelsConfigDao
}

type FruitySweetnessEngineCache struct {
	args *FruitySweetnessEngineCacheArgs
	fwCache.AbstractCacheAction
	Operation fwCache.BaseCache[slotengine.Engine[scatter.FruitySweetnessSpinRound]]
	allowRpc  bool
}

func NewFruitySweetnessEngineCache(args FruitySweetnessEngineCacheArgs, baseConf *conf.BaseConf) *FruitySweetnessEngineCache {
	profile := baseConf.GetProfile()
	wrapper := &FruitySweetnessEngineCache{
		args:     &args,
		allowRpc: "dev" == profile || "local" == profile || "test" == profile,
	}
	core := fwCache.NewPlainCache[slotengine.Engine[scatter.FruitySweetnessSpinRound]](
		fwCache.ValueLoaderFunc(wrapper.valueLoaderFunc),
		fwCache.WithLifeWindow(24*time.Hour),
		fwCache.WithLoaderLockCount(30),
	)
	wrapper.Operation = core
	wrapper.BaseCacheAction = core
	return wrapper
}

func NewFruitySweetnessEngineCacheAsInterface(e *FruitySweetnessEngineCache) fwCache.AbstractCache {
	return e
}

func (c *FruitySweetnessEngineCache) GameId() int {
	return slotengine.FruitySweetnessGameId
}

func (c *FruitySweetnessEngineCache) GetCacheName() string {
	return cache_name.GetEngineCacheName(c.GameId())
}

// GetFruitySweetnessEngine
// 获取水果甜蜜游戏引擎
// gameId 游戏id
// volatility 波动率
func (c *FruitySweetnessEngineCache) GetFruitySweetnessEngine(ctx context.Context, gameId int, volatility int, isBuyFree bool) (slotengine.Engine[scatter.FruitySweetnessSpinRound], error) {
	engineKey := utils.JoinAnyAsString([]any{gameId, isBuyFree, volatility}, "@")
	scatterEngine, err := c.Operation.GetOrLoad(ctx, engineKey)
	if err != nil {
		return nil, err
	}
	return *scatterEngine, nil
}

func (c *FruitySweetnessEngineCache) valueLoaderFunc(ctx context.Context, uniqEngineKey string) (*slotengine.Engine[scatter.FruitySweetnessSpinRound], error) {
	params := strings.Split(uniqEngineKey, "@")
	gameId, err := strconv.Atoi(params[0])
	if err != nil {
		return nil, err
	}
	isBuyFree, err := strconv.ParseBool(params[1])
	if err != nil {
		return nil, err
	}
	volatility, err := strconv.Atoi(params[2])
	if err != nil {
		return nil, err
	}
	engineReelCfg, err := c.queryReelSymbols(ctx, gameId, volatility, isBuyFree)
	if err != nil {
		return nil, err
	}
	var e slotengine.Engine[scatter.FruitySweetnessSpinRound]
	e = engine.NewFruitySweetnessEngine(engineReelCfg)
	return &e, nil
}

func (c *FruitySweetnessEngineCache) queryReelSymbols(ctx context.Context, gameId int, volatility int, isBuyFree bool) (*mysql_model.TblEngineReelsConfig, error) {
	gameMode := constants.TblEngineReelsGameModeNormal
	if isBuyFree {
		gameMode = constants.TblEngineReelsGameModeBuyFree
	}
	rtpLevel := "medium" //目前的rtp等级都是固定的，如果需要扩展，将来可以将该参数移至函数入参
	cfg, err := c.args.TblEngineReelsConfigDao.QueryReel(ctx, gameId, int32(gameMode), int32(volatility), rtpLevel)
	if err != nil || cfg == nil {
		log.Error(ctx, "read reels error ,gameId : {}, isBuyFree:{},Volatility :{}", gameId, isBuyFree, volatility)
		return nil, errors.New("cannot read reels")
	}
	return cfg, nil
}
