package cache

import (
	"context"
	"errors"
	"go.uber.org/fx"
	"slot_common/pkg/constants"
	"slot_common/pkg/dao/mysql_dao"
	"slot_common/pkg/model/mysql_model"
	fwCache "slot_framework/pkg/cache"
	"slot_framework/pkg/conf"
	"slot_framework/pkg/log"
	"slot_framework/pkg/utils"
	"slot_mi_core/slotengine"
	"slot_mi_core/slotengine/megaways"
	"slot_mi_game/internal/constants/cache_name"
	"slot_mi_game/internal/engine"
	"strconv"
	"strings"
	"time"
)

type LuckyAbuEngineCacheArgs struct {
	fx.In
	TblEngineReelsConfigDao *mysql_dao.TblEngineReelsConfigDao
}

type LuckyAbuEngineCache struct {
	args *LuckyAbuEngineCacheArgs
	fwCache.AbstractCacheAction
	Operation fwCache.BaseCache[slotengine.Engine[megaways.LuckyAbuSpinRound]]
	allowRpc  bool
}

func NewLuckyAbuEngineCache(args LuckyAbuEngineCacheArgs, baseConf *conf.BaseConf) *LuckyAbuEngineCache {
	profile := baseConf.GetProfile()
	wrapper := &LuckyAbuEngineCache{
		args:     &args,
		allowRpc: "dev" == profile || "local" == profile || "test" == profile,
	}
	core := fwCache.NewPlainCache[slotengine.Engine[megaways.LuckyAbuSpinRound]](
		fwCache.ValueLoaderFunc(wrapper.valueLoaderFunc),
		fwCache.WithLifeWindow(24*time.Hour),
		fwCache.WithLoaderLockCount(30),
	)
	wrapper.Operation = core
	wrapper.BaseCacheAction = core
	return wrapper
}

func NewLuckyAbuEngineCacheAsInterface(e *LuckyAbuEngineCache) fwCache.AbstractCache {
	return e
}

func (c *LuckyAbuEngineCache) GameId() int {
	return slotengine.LuckyAbu
}

func (c *LuckyAbuEngineCache) GetCacheName() string {
	return cache_name.GetEngineCacheName(c.GameId())
}

// GetLuckyAbuEngine
// 获取幸运阿布的游戏引擎
// gameId 游戏id
// volatility 波动率
func (c *LuckyAbuEngineCache) GetLuckyAbuEngine(ctx context.Context, gameId int, volatility int, isBuyFree bool) (slotengine.Engine[megaways.LuckyAbuSpinRound], error) {
	engineKey := utils.JoinAnyAsString([]any{gameId, isBuyFree, volatility}, "@")
	scatterEngine, err := c.Operation.GetOrLoad(ctx, engineKey)
	if err != nil {
		return nil, err
	}
	return *scatterEngine, nil
}

func (c *LuckyAbuEngineCache) valueLoaderFunc(ctx context.Context, uniqEngineKey string) (*slotengine.Engine[megaways.LuckyAbuSpinRound], error) {
	params := strings.Split(uniqEngineKey, "@")
	gameId, err := strconv.Atoi(params[0])
	if err != nil {
		return nil, err
	}
	isBuyFree, err := strconv.ParseBool(params[1])
	if err != nil {
		return nil, err
	}
	volatility, err := strconv.Atoi(params[2])
	if err != nil {
		return nil, err
	}
	engineReelCfg, err := c.queryReelSymbols(ctx, gameId, volatility, isBuyFree)
	if err != nil {
		return nil, err
	}
	var e slotengine.Engine[megaways.LuckyAbuSpinRound]
	e = engine.NewLuckyAbuEngine(engineReelCfg)
	return &e, nil
}

func (c *LuckyAbuEngineCache) queryReelSymbols(ctx context.Context, gameId int, volatility int, isBuyFree bool) (*mysql_model.TblEngineReelsConfig, error) {
	gameMode := constants.TblEngineReelsGameModeNormal
	if isBuyFree {
		gameMode = constants.TblEngineReelsGameModeBuyFree
	}
	rtpLevel := "medium" //目前的rtp等级都是固定的，如果需要扩展，将来可以将该参数移至函数入参
	cfg, err := c.args.TblEngineReelsConfigDao.QueryReel(ctx, gameId, int32(gameMode), int32(volatility), rtpLevel)
	if err != nil || cfg == nil {
		log.Error(ctx, "read reels error ,gameId : {}, isBuyFree:{},Volatility :{}", gameId, isBuyFree, volatility)
		return nil, errors.New("cannot read reels")
	}
	return cfg, nil
}
