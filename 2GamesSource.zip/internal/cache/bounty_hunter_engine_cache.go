package cache

import (
	"context"
	"errors"
	"go.uber.org/fx"
	"slot_common/pkg/constants"
	"slot_common/pkg/dao/mysql_dao"
	"slot_common/pkg/model/mysql_model"
	fwCache "slot_framework/pkg/cache"
	"slot_framework/pkg/conf"
	"slot_framework/pkg/log"
	"slot_framework/pkg/utils"
	"slot_mi_core/slotengine"
	"slot_mi_core/slotengine/megaways"
	"slot_mi_game/internal/constants/cache_name"
	"slot_mi_game/internal/engine"
	"strconv"
	"strings"
	"time"
)

type BountyHunterEngineCacheArgs struct {
	fx.In
	TblEngineReelsConfigDao *mysql_dao.TblEngineReelsConfigDao
}

type BountyHunterEngineCache struct {
	args *BountyHunterEngineCacheArgs
	fwCache.AbstractCacheAction
	Operation fwCache.BaseCache[slotengine.Engine[megaways.BountyHunterSpinRound]]
	allowRpc  bool
}

func NewBountyHunterEngineCache(args BountyHunterEngineCacheArgs, baseConf *conf.BaseConf) *BountyHunterEngineCache {
	profile := baseConf.GetProfile()
	wrapper := &BountyHunterEngineCache{
		args:     &args,
		allowRpc: "dev" == profile || "local" == profile || "test" == profile,
	}
	core := fwCache.NewPlainCache[slotengine.Engine[megaways.BountyHunterSpinRound]](
		fwCache.ValueLoaderFunc(wrapper.valueLoaderFunc),
		fwCache.WithLifeWindow(24*time.Hour),
		fwCache.WithLoaderLockCount(30),
	)
	wrapper.Operation = core
	wrapper.BaseCacheAction = core
	return wrapper
}

func NewBountyHunterEngineCacheAsInterface(e *BountyHunterEngineCache) fwCache.AbstractCache {
	return e
}

func (c *BountyHunterEngineCache) GameId() int {
	return slotengine.BountyHunter
}

func (c *BountyHunterEngineCache) GetCacheName() string {
	return cache_name.GetEngineCacheName(c.GameId())
}

// GetBountyHunterEngine
// 获取赏金猎人引擎
// gameId 游戏id
// volatility 波动率
func (c *BountyHunterEngineCache) GetBountyHunterEngine(ctx context.Context, gameId int, volatility int, isBuyFree bool) (slotengine.Engine[megaways.BountyHunterSpinRound], error) {
	engineKey := utils.JoinAnyAsString([]any{gameId, isBuyFree, volatility}, "@")
	scatterEngine, err := c.Operation.GetOrLoad(ctx, engineKey)
	if err != nil {
		return nil, err
	}
	return *scatterEngine, nil
}

func (c *BountyHunterEngineCache) valueLoaderFunc(ctx context.Context, uniqEngineKey string) (*slotengine.Engine[megaways.BountyHunterSpinRound], error) {
	params := strings.Split(uniqEngineKey, "@")
	gameId, err := strconv.Atoi(params[0])
	if err != nil {
		return nil, err
	}
	isBuyFree, err := strconv.ParseBool(params[1])
	if err != nil {
		return nil, err
	}
	volatility, err := strconv.Atoi(params[2])
	if err != nil {
		return nil, err
	}
	engineReelCfg, err := c.queryReelSymbols(ctx, gameId, volatility, isBuyFree)
	if err != nil {
		return nil, err
	}
	var e slotengine.Engine[megaways.BountyHunterSpinRound]
	e = engine.NewBountyHunterEngine(engineReelCfg)
	return &e, nil
}

func (c *BountyHunterEngineCache) queryReelSymbols(ctx context.Context, gameId int, volatility int, isBuyFree bool) (*mysql_model.TblEngineReelsConfig, error) {
	gameMode := constants.TblEngineReelsGameModeNormal
	if isBuyFree {
		gameMode = constants.TblEngineReelsGameModeBuyFree
	}
	rtpLevel := "medium" //目前的rtp等级都是固定的，如果需要扩展，将来可以将该参数移至函数入参
	cfg, err := c.args.TblEngineReelsConfigDao.QueryReel(ctx, gameId, int32(gameMode), int32(volatility), rtpLevel)
	if err != nil || cfg == nil {
		log.Error(ctx, "read reels error ,gameId : {}, isBuyFree:{},Volatility :{}", gameId, isBuyFree, volatility)
		return nil, errors.New("cannot read reels")
	}
	return cfg, nil
}
