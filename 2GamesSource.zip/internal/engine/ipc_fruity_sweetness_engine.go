package engine

import (
	"fmt"
	"slot_common/pkg/constants"
	"slot_common/pkg/model/mysql_model"
	"slot_mi_core/slotengine"
	"slot_mi_core/slotengine/scatter"
	"slot_mi_engine/pkg/engine/scatter/fruity_sweetness"
	"slot_mi_engine/pkg/game"
)

type FruitySweetnessEngine struct {
	slotengine.Engine[scatter.FruitySweetnessSpinRound]
}

func NewFruitySweetnessEngine(cfg *mysql_model.TblEngineReelsConfig) *FruitySweetnessEngine {
	gameCfg, err := game.GetFruitySweetnessConfig()
	if err != nil {
		panic(fmt.Errorf("get fruity sweetness engine config error: %v", err))
	}
	volatility := slotengine.VolatilityMedium
	switch cfg.Volatility {
	case 0:
		volatility = slotengine.VolatilityLow
	case 1:
		volatility = slotengine.VolatilityMedium
	case 2:
		volatility = slotengine.VolatilityHigh
	}
	reelSet := game.GetFruitySweetnessReels(volatility, cfg.GameMode == constants.TblEngineReelsGameModeBuyFree)
	return &FruitySweetnessEngine{
		fruity_sweetness.NewScatterEngine(gameCfg, reelSet),
	}
}
