package engine

import (
	"fmt"
	"slot_common/pkg/constants"
	"slot_common/pkg/model/mysql_model"
	"slot_mi_core/slotengine"
	"slot_mi_core/slotengine/megaways"
	"slot_mi_engine/pkg/engine/megaways/lucky_abu"
	"slot_mi_engine/pkg/game"
)

type LuckyAbuEngine struct {
	slotengine.Engine[megaways.LuckyAbuSpinRound]
}

func NewLuckyAbuEngine(cfg *mysql_model.TblEngineReelsConfig) *LuckyAbuEngine {
	gameCfg, err := game.GetLuckyAbuConfig()
	if err != nil {
		panic(fmt.Errorf("get lucky abu engine config error: %v", err))
	}
	volatility := slotengine.VolatilityMedium
	switch cfg.Volatility {
	case 0:
		volatility = slotengine.VolatilityLow
	case 1:
		volatility = slotengine.VolatilityMedium
	case 2:
		volatility = slotengine.VolatilityHigh
	}
	reelSet := game.GetLuckyAbuReels(volatility, cfg.GameMode == constants.TblEngineReelsGameModeBuyFree)
	return &LuckyAbuEngine{
		lucky_abu.NewMegaWaysEngine(gameCfg, reelSet),
	}
}
