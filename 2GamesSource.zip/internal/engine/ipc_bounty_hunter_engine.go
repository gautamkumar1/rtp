package engine

import (
	"fmt"
	"slot_common/pkg/constants"
	"slot_common/pkg/model/mysql_model"
	"slot_mi_core/slotengine"
	"slot_mi_core/slotengine/megaways"
	"slot_mi_engine/pkg/engine/megaways/bounty_hunter"
	"slot_mi_engine/pkg/game"
)

type BountyHunterEngine struct {
	slotengine.Engine[megaways.BountyHunterSpinRound]
}

func NewBountyHunterEngine(cfg *mysql_model.TblEngineReelsConfig) *BountyHunterEngine {
	gameCfg, err := game.GetBountyHunterConfig()
	if err != nil {
		panic(fmt.Errorf("get bounty hunter engine config error: %v", err))
	}
	volatility := slotengine.VolatilityMedium
	switch cfg.Volatility {
	case 0:
		volatility = slotengine.VolatilityLow
	case 1:
		volatility = slotengine.VolatilityMedium
	case 2:
		volatility = slotengine.VolatilityHigh
	}
	reelSet := game.GetBountyHunterReels(volatility, cfg.GameMode == constants.TblEngineReelsGameModeBuyFree)
	return &BountyHunterEngine{
		bounty_hunter.NewEngine(gameCfg, reelSet),
	}
}
