package inject

import (
	"go.uber.org/fx"
	fwJob "slot_framework/pkg/job"
	"slot_mi_game/internal/job"
)

func jobInjects() fx.Option {
	return fx.Options(
		fwJob.ProvideScheduler(fwJob.NewEmptyScheduler),
		_baseJobInjects(),
		_lightJobInjects(),
	)
}

func _baseJobInjects() fx.Option {
	return fx.Options()
}

func _lightJobInjects() fx.Option {
	return fx.Options(
		fwJob.RegisterLightningJob(job.NewEsRollbackRedoJob),
	)
}
