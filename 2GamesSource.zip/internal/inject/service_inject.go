package inject

import (
	"slot_mi_game/internal/service"

	"go.uber.org/fx"
)

func serviceInject() fx.Option {
	return fx.Options(
		fx.Provide(service.NewReelService),
		fx.Provide(service.NewUserPackageService),
		fx.Provide(service.NewUserTaskService),
		fx.Provide(service.NewUserService),
		fx.Provide(service.NewSettlementService),
		fx.Provide(service.NewJackpotService),
	)
}
