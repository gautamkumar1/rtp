package inject

import (
	cmInject "slot_common/pkg/inject"
	"slot_framework/pkg/conf"
	"slot_framework/pkg/i18n"
	"slot_framework/pkg/module"
	"slot_mi_game/configs"
	i18nEmbed "slot_mi_game/internal/i18n"

	"go.uber.org/fx"
)

func GetInjects() ([]fx.Option, []fx.Option) {
	var injects []fx.Option
	baseConf := conf.NewBaseConf(configs.ConfigFile, configs.ActiveConfigFile, configs.Profile)
	if baseConf.GetBool("log.fx-log-disabled", true) {
		injects = append(injects, fx.NopLogger)
	}
	//公用部分，主要是DAO和Cache
	injects = append(injects, cmInject.CommonInject())
	//web相关解析注入，包括middleware，自定义参数解析等
	injects = append(injects, webInjects())
	injects = append(injects, serviceInject())
	//游戏注入
	injects = append(injects, gameInjects())
	injects = append(injects, cacheInjects())
	//任务注入
	injects = append(injects, jobInjects())
	//国际化
	injects = append(injects, fx.Invoke(func() {
		i18n.InitBundle(i18nEmbed.I18nFiles)
	}))
	return module.GetInjectionsByModule(baseConf, injects)
}
