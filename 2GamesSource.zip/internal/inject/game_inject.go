package inject

import (
	"slot_mi_core/slots/pharaohtreasure"
	"slot_mi_game/internal/games"
	"slot_mi_game/internal/games/abus_lucky"
	"slot_mi_game/internal/games/bounty_hunter"
	"slot_mi_game/internal/games/fruity_sweetness"
	"slot_mi_game/internal/games/gold_prophecy/gold_prophecy"

	"go.uber.org/fx"
)

const gameGroup = `group:"slotGames"`

func gameInjects() fx.Option {
	return fx.Options(
		fx.Provide(pharaohtreasure.NewPharaohTreasureGame),
		registerGame(gold_prophecy.NewGameHandler),
		registerGame(fruity_sweetness.NewGameHandler), //06
		registerGame(abus_lucky.NewGameHandler),       //07
		registerGame(bounty_hunter.NewGameHandler),    //10
		fx.Provide(fx.Annotate(games.NewSlotGameHandlerFactory, fx.ParamTags(gameGroup))),
	)
}

func registerGame(constructor any) fx.Option {
	return fx.Provide(fx.Annotate(constructor, fx.As(new(games.SlotGameHandler)), fx.ResultTags(gameGroup)))
}
