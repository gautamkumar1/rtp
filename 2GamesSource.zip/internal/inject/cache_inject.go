package inject

import (
	"go.uber.org/fx"
	fwCache "slot_framework/pkg/cache"
	"slot_mi_game/internal/cache"
)

func cacheInjects() fx.Option {
	return fx.Options(
		fwCache.RegisterCache(cache.NewFruitySweetnessEngineCache, cache.NewFruitySweetnessEngineCacheAsInterface), //水果甜蜜游戏引擎
		fwCache.RegisterCache(cache.NewLuckyAbuEngineCache, cache.NewLuckyAbuEngineCacheAsInterface),               //幸运阿布游戏引擎
		fwCache.RegisterCache(cache.NewBountyHunterEngineCache, cache.NewBountyHunterEngineCacheAsInterface),       //赏金猎人游戏引擎
	)
}
