package inject

import (
	cmWeb "slot_common/pkg/web"
	fwWeb "slot_framework/pkg/web"
	"slot_mi_game/internal/router"
	"slot_mi_game/internal/web"

	"go.uber.org/fx"
)

func webInjects() fx.Option {
	return fx.Options(
		//注入自动生成的controller和router
		GenRouterInjects(),
		//自定义参数解析器
		fwWeb.RegisterArgumentResolver(web.NewUserInfoArgumentResolver),
		//注入Swagger
		fwWeb.RegisterRouter(router.NewSwaggerRouter),
		//测试Router
		fwWeb.RegisterRouter(router.NewTestRouter),
		//注入自定义RecoverMiddleware
		fwWeb.ProvideCustomRecoverMiddleware(cmWeb.NewSlotGameRecoverMiddleware),
		//注册内部访问URI的拦截器
		fwWeb.RegisterMiddleware(web.NewInternalMiddleware),
		//前端接口token校验
		fwWeb.RegisterMiddleware(cmWeb.NewFrontApiTokenMiddleware),
	)
}
