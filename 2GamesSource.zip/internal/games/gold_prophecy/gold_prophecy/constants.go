package gold_prophecy

const BaseMultiplier = 1    //基础投注倍数
const BuyFeeMultiplier = 50 //买免投注倍数

const GoldProphecyDefault = `{
   "aw": 0,
   "bl": 0,
   "blab": 0,
   "blb": 0,
   "cpf": {},
   "cptw": 0,
   "crtw": 0,
   "cs":1,
   "ctw": 0,
   "cwc": 0,
   "fa": {},
   "fb": 1,
   "fs": {},
   "fstc": null,
   "ge": [
      1
   ],
   "gwt": 0,
   "hashr": "",
   "iff": false,
   "ift": false,
   "imw": false,
   "lw": {},
   "ml": 1,
   "mr": null,
   "np": 0,
   "nst": 0,
   "ocr": null,
   "orl": [],
   "pcwc": 0,
   "pf": 0,
   "pmt": "",
   "psid": "",
   "rl": [],
   "rwsp": {},
   "sid": "",
   "st": 0,
   "tb": 1,
   "tbb": 1,
   "tw": 0,
   "wbn": null,
   "wfg": null,
   "wid": 0,
   "wk": "",
   "wp": {},
   "wt": ""
}`
