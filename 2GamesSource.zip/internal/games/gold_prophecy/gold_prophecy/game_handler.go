package gold_prophecy

import (
	"context"
	"fmt"
	"slot_common/pkg/cache"
	"slot_common/pkg/constants"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/constants/game_name"
	"slot_common/pkg/dao/es_dao"
	"slot_common/pkg/model/mysql_model"
	"slot_common/pkg/rsp"
	"slot_common/pkg/runtime"
	"slot_common/pkg/wallet"
	fwConstants "slot_framework/pkg/constants"
	redis "slot_framework/pkg/data/redis/v9"
	"slot_framework/pkg/log"
	"slot_framework/pkg/utils"
	"slot_mi_core/pkg"
	"slot_mi_core/slots/pharaohtreasure"
	"slot_mi_game/internal/constants/redis_key"
	"slot_mi_game/internal/dto"
	"slot_mi_game/internal/service"
	"time"

	"slot_framework/pkg/snowflake"

	"github.com/shopspring/decimal"
	"go.uber.org/fx"
)

type GameHandlerArgs struct {
	fx.In
	UserWalletService   *wallet.UserWalletService
	ReelService         *service.ReelService
	UserPackageService  *service.UserPackageService
	UserTaskService     *service.UserTaskService
	UserService         *service.UserService
	SettlementService   *service.SettlementService
	GameBetCache        *cache.GameBetCache
	RedisTemplate       *redis.RedisTemplate
	Game                *pharaohtreasure.PharaohTreasureGame
	SlotUserLastDataDao *es_dao.SlotUserLastDataDao
	JackpotService      *service.JackpotService
	SnowflakeGenerator  *snowflake.Generator
}

type GameHandler struct {
	args *GameHandlerArgs
}

func NewGameHandler(args GameHandlerArgs) *GameHandler {
	return &GameHandler{
		args: &args,
	}
}

func (g *GameHandler) GameInfo(ctx context.Context, userInfo *dto.SlotUserInfo) *rsp.SlotGameResponse[any] {
	gameBetInfo, exists := g.args.GameBetCache.GetGameBet(ctx, g.Id(), int(userInfo.CurrencyId))
	fmt.Printf("投注大小设置信息：%+v\n", gameBetInfo)
	if !exists || gameBetInfo == nil {
		log.Info(ctx, "{}未设置游戏投注大小", g.Name())
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.BetInfoErr))
	}
	balance := g.args.UserWalletService.GetAvailableBalance(ctx, &wallet.CommonReqInfo{
		Merchant: userInfo.Merchant,
		User:     userInfo.User,
		GameId:   g.Id(),
	})
	glData := g.newGl(balance, gameBetInfo, userInfo.CurrencyId)
	lastData, exists := g.args.SlotUserLastDataDao.FindByGameIdAndUserId(ctx, g.Id(), userInfo.UserId)
	var dt string
	if exists {
		dt = lastData.Data
	} else {
		dt = GoldProphecyDefault
	}
	var si GoldProphecySi
	jsonErr := utils.JsonUtil.UnmarshalString(dt, &si)
	if jsonErr != nil {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.JsonUnmarshalErr))
	}
	if !exists {
		si.Cs = gameBetInfo.DefaultSize.InexactFloat64()
	}
	glData.Ls.Si = si
	return rsp.NewResponse[any](glData)
}

func (g *GameHandler) Spin(ctx context.Context, req *dto.SpinReq) *rsp.SlotGameResponse[any] {
	lockKey := redis_key.GetKey(redis_key.SpinUnique, req.UserInfo.UserId)
	success := g.args.RedisTemplate.Lock(ctx, lockKey, 5*time.Second)
	fmt.Printf("获取锁结果：%+v\n", success)
	if !success {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.SpinLockErr))
	}
	defer func() {
		g.args.RedisTemplate.Unlock(ctx, lockKey)
	}()
	return g.doSpin(ctx, req)
}

func (g *GameHandler) doSpin(ctx context.Context, req *dto.SpinReq) *rsp.SlotGameResponse[any] {
	gameState := constants.GameStateNormal // 对应tbl_game_draw_config 表的游戏状态 1普通游戏 2免费游戏 3购买免费游戏
	betAmount := decimal.NewFromFloat(req.BetAmt).Mul(decimal.NewFromInt32(int32(req.Multiplier)).Mul(decimal.NewFromInt32(BaseMultiplier))).InexactFloat64()
	originBetAmount := betAmount
	freeBuy := req.Fb == constants.GameFreeBuy
	bNormalToFree := false //普通游戏触发免费游戏
	if freeBuy {
		gameState = constants.GameStateFreeBuy
		betAmount = decimal.NewFromFloat(betAmount).Mul(decimal.NewFromFloat(BuyFeeMultiplier)).InexactFloat64()
	}
	balance := g.args.UserWalletService.GetAvailableBalance(ctx, &wallet.CommonReqInfo{
		Merchant: req.UserInfo.Merchant,
		User:     req.UserInfo.User,
		GameId:   g.Id(),
	})
	if balance < betAmount {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.InsufficientBalanceErr))
	}
	//获取对应的RTP设置，reels转轴
	reels, err := g.args.ReelService.GetReels(ctx, g.Id(), 1, req.UserInfo)
	fmt.Printf("reels转轴:%+v\n", reels)
	if err != nil || len(reels) != 7 {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.EngineConfErr))
	}
	//构建开奖vo
	gemKingdomBetIn := pharaohtreasure.PharaohTreasureBetIn{
		BetAmt:   betAmount,
		GameMode: pkg.NormalGameMode, // 默认正常
		Reels:    [...][]int{reels[0], reels[1], reels[2], reels[3], reels[4], reels[5], reels[6]},
	}
	if freeBuy {
		gemKingdomBetIn.GameMode = pkg.BuyFreeGameMode
	}
	goldProphecyBetOut, err := g.args.Game.GetPharaohTreasureRewardByMode(&gemKingdomBetIn)
	if err != nil {
		log.Error(ctx, "GoldProphecy结算错误", err)
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.CalcRewardErr))
	}
	if len(goldProphecyBetOut.FreeGameRewardsPerSpinOut) > 1 {
		if !freeBuy {
			bNormalToFree = true
		}
		// 普通触发了免费判断
		freeBuy = true

	}

	// 前端返回结果构造
	var si GoldProphecySi
	si.Cs = req.BetAmt
	si.Ml = req.Multiplier
	si.Tb = betAmount
	si.Tbb = originBetAmount
	si.Fb = 1
	if gameState > 1 {
		si.Fb = 2
	}
	// 中奖金额
	si.Aw = goldProphecyBetOut.RewardAmt
	si.Ctw = si.Aw
	si.Tw = si.Aw
	// 盈利金额 =tw-tb
	si.Np = decimal.NewFromFloat(si.Tw).Sub(decimal.NewFromFloat(si.Tb)).Truncate(2).InexactFloat64()

	settlement := &dto.Settlement{
		Spin:            req,
		Mode:            constants.GameModeNormal,
		ParentId:        "",
		BetAmount:       betAmount,
		WinAmount:       si.Ctw,
		GameId:          g.Id(),
		GameName:        g.ZHName(),
		Balance:         balance,
		OriginBetAmount: originBetAmount,
	}
	if freeBuy {
		settlement.Mode = constants.GameModeBuyFree
		si.Iff = true
		si.Ge = append(si.Ge, 2)
		if bNormalToFree {
			settlement.Mode = constants.GameModeFree
		}
	} else {
		si.Ge = append(si.Ge, 1)
	}
	historyId := g.args.SnowflakeGenerator.NextStringId()
	orderTimeMs := time.Now().UnixMilli()

	if goldProphecyBetOut.RewardAmt > 0 &&
		decimal.NewFromFloat(goldProphecyBetOut.RewardAmt/originBetAmount).GreaterThanOrEqual(decimal.NewFromInt(g.Limit())) {
		log.Info(ctx, "game:{}  g.Limit: {}", g.ZHName(), g.Limit())
		goldProphecyBetOut.RewardAmt = originBetAmount * float64(g.Limit()) //最大限12000倍
		goldProphecyBetOut.ReachedMaxPayout = true
		settlement.WinAmount = settlement.OriginBetAmount * float64(g.Limit())
	}

	si.Fa = goldProphecyBetOut
	g.args.SettlementService.DoSettlementWithCustomAction(ctx, settlement,
		historyId, orderTimeMs,
		func(r *dto.SettlementResult) string {
			//构建游戏历史记录
			si.Blb = r.BeforeBalance
			//si.Bl = r.BeforeBalance - settlement.BetAmount + settlement.WinAmount
			//si.Blab = r.BeforeBalance - settlement.BetAmount
			si.Bl = decimal.NewFromFloat(r.BeforeBalance).Sub(decimal.NewFromFloat(settlement.BetAmount)).Add(decimal.NewFromFloat(settlement.WinAmount)).InexactFloat64()
			si.Blab = decimal.NewFromFloat(r.BeforeBalance).Sub(decimal.NewFromFloat(settlement.BetAmount)).InexactFloat64()
			si.Psid = r.ParentId
			si.Sid = r.HistoryId
			gameData, _ := utils.JsonUtil.MarshalString(si)
			return gameData
		})
	//更新用户总输赢，总投注，并升级会员等级，保存等级奖金
	traceId := ctx.Value(fwConstants.TraceId).(string)
	go func(trace string) {
		//这里使用新的context，避免主流程结束，ctx被取消，影响内部协程异常中止，使用主流程的traceId跟踪后续流程
		newCtx := context.WithValue(context.Background(), fwConstants.TraceId, trace)
		//防呆
		defer func() {
			if r := recover(); r != nil {
				log.Error(newCtx, "UpdateUserAmt panic", r)
			}
		}()
		g.args.UserService.UpdateUserAmt(newCtx, req.UserInfo, settlement.BetAmount, settlement.WinAmount)
	}(traceId)
	data := GoldProphecyDt{Si: si}
	return rsp.NewResponse[any](data)
}

func (g *GameHandler) newGl(balance float64, gameBet *mysql_model.TblGameBet, currencyId int64) *GoldProphecyUserInfoData {
	sizes := make([]float64, 0)
	if gameBet.BetSize1.GreaterThan(decimal.Zero) {
		sizes = append(sizes, gameBet.BetSize1.InexactFloat64())
	}
	if gameBet.BetSize2.GreaterThan(decimal.Zero) {
		sizes = append(sizes, gameBet.BetSize2.InexactFloat64())
	}
	if gameBet.BetSize3.GreaterThan(decimal.Zero) {
		sizes = append(sizes, gameBet.BetSize3.InexactFloat64())
	}
	if gameBet.BetSize4.GreaterThan(decimal.Zero) {
		sizes = append(sizes, gameBet.BetSize4.InexactFloat64())
	}
	s := &GoldProphecyUserInfoData{
		Bl:    balance,
		Cc:    constants.GetCurrencyName(int(currencyId)),
		Cs:    sizes,
		Fb:    BuyFeeMultiplier,
		Inwe:  false,
		Iuwe:  false,
		Maxwm: constants.GetMaxwmBet(int(currencyId), int(currencyId)),
		Ml:    []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
		Al:    []int{10, 30, 50, 80, 1000},
		Mxl:   BaseMultiplier,
	}
	s.Wt.Bw = 20
	s.Wt.Mgw = 35
	s.Wt.Mw = 5
	s.Wt.Smgw = 50
	return s
}

func (g *GameHandler) Id() int {
	return g.args.Game.GameId
}

func (g *GameHandler) Name() string {
	return game_name.GoldProphecy
}

func (g *GameHandler) ZHName() string {
	return game_name.GoldProphecy_ZH
}

func (g *GameHandler) Limit() int64 {
	return game_name.GoldProphecy_Limit
}
