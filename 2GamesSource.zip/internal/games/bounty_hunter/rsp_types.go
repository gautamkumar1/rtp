package bounty_hunter

import (
	"slot_mi_core/slotengine"
	"slot_mi_core/slotengine/megaways"
)

type BountyHunterUserInfoData struct {
	Fb int `json:"fb"`
	Wt struct {
		Mw   int `json:"mw"`
		Bw   int `json:"bw"`
		Mgw  int `json:"mgw"`
		Smgw int `json:"smgw"`
	} `json:"wt"`
	Maxwm interface{}    `json:"maxwm"`
	Cs    []float64      `json:"cs"`
	Ml    []int          `json:"ml"`
	Al    []int          `json:"al"`
	Mxl   int            `json:"mxl"`
	Bl    float64        `json:"bl"`
	Inwe  bool           `json:"inwe"`
	Iuwe  bool           `json:"iuwe"`
	Ls    BountyHunterLs `json:"ls"`
	Cc    string         `json:"cc"`
}

type BountyHunterDt struct {
	Si BountyHunterSi `json:"si"`
}

type BountyHunterLs struct {
	Si BountyHunterSi `json:"si"`
}

type BountyHunterSi struct {
	Aw    float64                                                `json:"aw"`   // 累计赢取金额
	Bl    float64                                                `json:"bl"`   // 余额 一般=Blab+Aw
	Blab  float64                                                `json:"blab"` // 投注后余额
	Blb   float64                                                `json:"blb"`  // 投注前余额
	Cpf   interface{}                                            `json:"cpf"`
	Cptw  float64                                                `json:"cptw"`
	Crtw  float64                                                `json:"crtw"`
	Cs    float64                                                `json:"cs"`  // 投注大小
	Ctw   float64                                                `json:"ctw"` // 一般等于Aw
	Cwc   int                                                    `json:"cwc"`
	Fa    *slotengine.SpinResult[megaways.BountyHunterSpinRound] `json:"fa"` // 每款游戏特别字段
	Fb    int                                                    `json:"fb"` // 1正常 2免费
	Fs    *BountyHunterFs                                        `json:"fs"` // 免费次数的统计说明
	Fstc  map[string]int                                         `json:"fstc"`
	Ge    []int                                                  `json:"ge"`
	Gwt   int                                                    `json:"gwt"` // 游戏倍数
	Hashr string                                                 `json:"hashr"`
	Iff   bool                                                   `json:"iff"`
	Ift   bool                                                   `json:"ift"`
	Imw   bool                                                   `json:"imw"`
	Lw    map[string]float64                                     `json:"lw"` // 中奖结果对赢的:金额 = cs*ml*符号赔付值
	Ml    int                                                    `json:"ml"` // 倍数
	Mr    interface{}                                            `json:"mr"`
	Np    float64                                                `json:"np"` // 盈利金额 =tw-tb
	Nst   int                                                    `json:"nst"`
	Ocr   interface{}                                            `json:"ocr"`
	Orl   []int                                                  `json:"orl"`
	Pcwc  int                                                    `json:"pcwc"`
	Pf    int                                                    `json:"pf"`
	Pmt   string                                                 `json:"pmt"`
	Psid  string                                                 `json:"psid"`
	Rl    []int                                                  `json:"rl"`
	Rwsp  map[string]float64                                     `json:"rwsp"` // 中奖结果对应的：符号赔付值
	Sid   string                                                 `json:"sid"`
	St    int                                                    `json:"st"`
	Tb    float64                                                `json:"tb"`  // 游戏投注金额 免费就是0
	Tbb   float64                                                `json:"tbb"` // 游戏本应投注金额
	Tw    float64                                                `json:"tw"`  // 一般等于aw
	Tt    float64                                                `json:"tt"`
	Wbn   interface{}                                            `json:"wbn"`
	Wfg   interface{}                                            `json:"wfg"`
	Wid   int                                                    `json:"wid"`
	Wk    string                                                 `json:"wk"`
	Wp    map[string][]int                                       `json:"wp"`
	Wt    string                                                 `json:"wt"`
	Pool  interface{}                                            `json:"pool"` //奖池信息
}

type BountyHunterFs struct {
	S  int     `json:"s"`
	Ts int     `json:"ts"`
	Aw float64 `json:"aw"`
}
