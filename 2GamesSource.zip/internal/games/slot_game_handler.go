package games

import (
	"context"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/rsp"
	"slot_common/pkg/runtime"
	"slot_framework/pkg/utils"
	"slot_mi_game/internal/dto"
)

type SlotGameHandler interface {
	Name() string
	ZHName() string
	Id() int
	GameInfo(ctx context.Context, userInfo *dto.SlotUserInfo) *rsp.SlotGameResponse[any]
	Spin(ctx context.Context, req *dto.SpinReq) *rsp.SlotGameResponse[any]
}

type SlotGameHandlerFactory struct {
	gameMap *utils.ReadOnlyMap[string, SlotGameHandler]
}

func NewSlotGameHandlerFactory(gameHandlers []SlotGameHandler) *SlotGameHandlerFactory {
	return &SlotGameHandlerFactory{
		gameMap: utils.NewReadOnlyMap(gameHandlers, func(v SlotGameHandler) string {
			return v.Name()
		}),
	}
}

func (f *SlotGameHandlerFactory) GetGameHandler(ctx context.Context, gameName string) SlotGameHandler {
	handler, exists := f.gameMap.Get(gameName)
	if !exists {
		panic(runtime.NewSlotError(ctx, error_code.GameNotFoundErr))
	}
	return handler
}
