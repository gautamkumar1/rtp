package abus_lucky

import (
	"context"
	cmCache "slot_common/pkg/cache"
	"slot_common/pkg/constants"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/constants/game_name"
	"slot_common/pkg/dao/es_dao"
	"slot_common/pkg/model/mysql_model"
	"slot_common/pkg/rsp"
	"slot_common/pkg/runtime"
	"slot_common/pkg/wallet"
	fwConstants "slot_framework/pkg/constants"
	redis "slot_framework/pkg/data/redis/v9"
	"slot_framework/pkg/log"
	"slot_framework/pkg/utils"
	"slot_mi_core/slotengine"
	"slot_mi_core/slotengine/megaways"
	"slot_mi_game/internal/cache"
	"slot_mi_game/internal/constants/redis_key"
	"slot_mi_game/internal/dto"
	"slot_mi_game/internal/service"
	"time"

	"slot_framework/pkg/snowflake"

	"github.com/shopspring/decimal"
	"go.uber.org/fx"
)

// GameHandlerArgs 依赖注入后的大类
type GameHandlerArgs struct {
	fx.In
	UserWalletService   *wallet.UserWalletService
	UserPackageService  *service.UserPackageService
	UserTaskService     *service.UserTaskService
	UserService         *service.UserService
	SettlementService   *service.SettlementService
	GameBetCache        *cmCache.GameBetCache
	RedisTemplate       *redis.RedisTemplate
	EngineCache         *cache.LuckyAbuEngineCache
	SlotUserLastDataDao *es_dao.SlotUserLastDataDao
	SnowflakeGenerator  *snowflake.Generator
	JackpotService      *service.JackpotService
}

type GameHandler struct {
	args *GameHandlerArgs
}

func NewGameHandler(args GameHandlerArgs) *GameHandler {
	return &GameHandler{
		args: &args,
	}
}

func (g *GameHandler) GameInfo(ctx context.Context, userInfo *dto.SlotUserInfo) *rsp.SlotGameResponse[any] {
	gameBetInfo, exists := g.args.GameBetCache.GetGameBet(ctx, g.Id(), int(userInfo.CurrencyId))
	if !exists || gameBetInfo == nil {
		log.Info(ctx, "{}未设置游戏投注大小", g.Name())
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.BetInfoErr))
	}
	balance := g.args.UserWalletService.GetAvailableBalance(ctx, &wallet.CommonReqInfo{
		Merchant: userInfo.Merchant,
		User:     userInfo.User,
		GameId:   g.Id(),
	})
	glData := g.newGl(balance, gameBetInfo, userInfo.CurrencyId)
	lastData, exists := g.args.SlotUserLastDataDao.FindByGameIdAndUserId(ctx, g.Id(), userInfo.UserId)
	var dt string
	if exists {
		dt = lastData.Data
	} else {
		dt = AbusLuckyDefault
	}
	var si AbusLuckySi
	jsonErr := utils.JsonUtil.UnmarshalString(dt, &si)
	if jsonErr != nil {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.JsonUnmarshalErr))
	}
	if !exists {
		si.Cs = gameBetInfo.DefaultSize.InexactFloat64()
	}
	glData.Ls.Si = si
	return rsp.NewResponse[any](glData)
}

func (g *GameHandler) Spin(ctx context.Context, req *dto.SpinReq) *rsp.SlotGameResponse[any] {
	lockKey := redis_key.GetKey(redis_key.SpinUnique, req.UserInfo.UserId) //本次旋转的锁
	success := g.args.RedisTemplate.Lock(ctx, lockKey, 5*time.Second)
	if !success { //加锁失败报错
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.SpinLockErr))
	}
	defer func() {
		g.args.RedisTemplate.Unlock(ctx, lockKey) //解锁
	}()
	return g.doSpin(ctx, req) //进入主逻辑
}

func (g *GameHandler) doSpin(ctx context.Context, req *dto.SpinReq) *rsp.SlotGameResponse[any] {
	gameState := constants.GameStateNormal // 对应tbl_game_draw_config 表的游戏状态 1普通游戏 2免费游戏 3购买免费游戏
	betAmount := decimal.NewFromFloat(req.BetAmt).Mul(decimal.NewFromInt32(int32(req.Multiplier)).Mul(decimal.NewFromInt32(BaseMultiplier))).InexactFloat64()
	originBetAmount := betAmount
	freeBuy := req.Fb == constants.GameFreeBuy
	if freeBuy {
		gameState = constants.GameStateFree
		betAmount = decimal.NewFromFloat(betAmount).Mul(decimal.NewFromFloat(BuyFeeMultiplier)).InexactFloat64()
	}
	balance := g.args.UserWalletService.GetAvailableBalance(ctx, &wallet.CommonReqInfo{
		Merchant: req.UserInfo.Merchant,
		User:     req.UserInfo.User,
		GameId:   g.Id(),
	})
	if balance < betAmount {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.InsufficientBalanceErr))
	}

	volatility := int(utils.AsValue(req.UserInfo.Merchant.Volatility))

	//获取对应的RTP设置，reels转轴
	engine, err := g.args.EngineCache.GetLuckyAbuEngine(ctx, g.Id(), volatility, freeBuy)
	if err != nil {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.EngineConfErr))
	}

	var result *slotengine.SpinResult[megaways.LuckyAbuSpinRound]
	if freeBuy {
		actualBetAmt := decimal.NewFromFloat(betAmount).Div(decimal.NewFromInt(BuyFeeMultiplier))
		result = engine.BuyFreeGame(ctx, actualBetAmt)
	} else {
		result = engine.Spin(ctx, decimal.NewFromFloat(betAmount))
	}

	if result.TriggeredFree {
		// 普通触发了免费判断
		if !freeBuy { //不是购买免费，但是又进了免费
			gameState = constants.GameStateFree
		}
	}

	// 前端返回结果构造
	var si AbusLuckySi
	si.Cs = req.BetAmt
	si.Ml = req.Multiplier
	si.Tb = betAmount
	si.Tbb = originBetAmount
	si.Fb = 1
	if gameState > 1 {
		si.Fb = 2
	}
	// 中奖金额
	si.Aw = result.TotalWin.InexactFloat64()
	si.Ctw = si.Aw
	si.Tw = si.Aw
	// 盈利金额 =tw-tb
	si.Np = decimal.NewFromFloat(si.Tw).Sub(decimal.NewFromFloat(si.Tb)).Truncate(2).InexactFloat64()

	settlement := &dto.Settlement{
		Spin:            req,
		Mode:            constants.GameModeNormal,
		ParentId:        "",
		BetAmount:       betAmount,
		WinAmount:       result.TotalWin.InexactFloat64(),
		GameId:          g.Id(),
		GameName:        g.ZHName(),
		Balance:         balance,
		OriginBetAmount: originBetAmount,
	}

	if gameState == constants.GameStateFree {
		settlement.Mode = constants.GameModeFree
		if freeBuy {
			settlement.Mode = constants.GameModeBuyFree
			si.Ge = append(si.Ge, 2)
		} else {
			si.Ge = append(si.Ge, 1)
		}
	}
	if decimal.NewFromFloat(settlement.WinAmount / settlement.OriginBetAmount).GreaterThanOrEqual(decimal.NewFromInt(g.Limit())) {
		log.Info(ctx, "game:{}  g.Limit: {}", g.ZHName(), g.Limit())
		settlement.WinAmount = settlement.OriginBetAmount * float64(g.Limit()) //最大限12000倍
		result.TotalWin = decimal.NewFromFloat(settlement.WinAmount)
		result.ReachedMaxPayout = true
	}
	si.Fa = result
	historyId := g.args.SnowflakeGenerator.NextStringId()
	orderTimeMs := time.Now().UnixMilli()
	g.args.SettlementService.DoSettlementWithCustomAction(ctx, settlement, historyId, orderTimeMs,
		func(r *dto.SettlementResult) string {
			//构建游戏历史记录
			si.Blb = r.BeforeBalance
			si.Bl = decimal.NewFromFloat(r.BeforeBalance).Sub(decimal.NewFromFloat(settlement.BetAmount)).Add(decimal.NewFromFloat(settlement.WinAmount)).InexactFloat64()
			si.Blab = decimal.NewFromFloat(r.BeforeBalance).Sub(decimal.NewFromFloat(settlement.BetAmount)).InexactFloat64()
			si.Psid = r.ParentId
			si.Sid = r.HistoryId
			gameData, _ := utils.JsonUtil.MarshalString(si)
			return gameData
		})
	traceId := ctx.Value(fwConstants.TraceId).(string)
	go func(trace string) {
		//这里使用新的context，避免主流程结束，ctx被取消，影响内部协程异常中止，使用主流程的traceId跟踪后续流程
		newCtx := context.WithValue(context.Background(), fwConstants.TraceId, trace)
		//防呆
		defer func() {
			if r := recover(); r != nil {
				log.Error(newCtx, "UpdateUserAmt panic", r)
			}
		}()
		g.args.UserService.UpdateUserAmt(newCtx, req.UserInfo, settlement.BetAmount, settlement.WinAmount)
	}(traceId)
	data := AbusLuckyDt{Si: si}
	return rsp.NewResponse[any](data)
}

func (g *GameHandler) newGl(balance float64, gameBet *mysql_model.TblGameBet, currencyId int64) *AbusLuckyUserInfoData {
	sizes := make([]float64, 0)
	if gameBet.BetSize1.GreaterThan(decimal.Zero) {
		sizes = append(sizes, gameBet.BetSize1.InexactFloat64())
	}
	if gameBet.BetSize2.GreaterThan(decimal.Zero) {
		sizes = append(sizes, gameBet.BetSize2.InexactFloat64())
	}
	if gameBet.BetSize3.GreaterThan(decimal.Zero) {
		sizes = append(sizes, gameBet.BetSize3.InexactFloat64())
	}
	if gameBet.BetSize4.GreaterThan(decimal.Zero) {
		sizes = append(sizes, gameBet.BetSize4.InexactFloat64())
	}
	s := &AbusLuckyUserInfoData{
		Bl:    balance,
		Cc:    constants.GetCurrencyName(int(currencyId)),
		Cs:    sizes,
		Fb:    BuyFeeMultiplier,
		Inwe:  false,
		Iuwe:  false,
		Maxwm: constants.GetMaxwmBet(int(currencyId), int(currencyId)),
		Ml:    []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
		Al:    []int{10, 30, 50, 80, 1000},
		Mxl:   BaseMultiplier,
	}
	s.Wt.Bw = 20
	s.Wt.Mgw = 35
	s.Wt.Mw = 5
	s.Wt.Smgw = 50
	return s
}

func (g *GameHandler) Id() int {
	return slotengine.LuckyAbu
}

func (g *GameHandler) Name() string {
	return game_name.AbusLucky
}

func (g *GameHandler) ZHName() string {
	return game_name.AbusLucky_ZH
}

func (g *GameHandler) Limit() int64 {
	return game_name.AbusLucky_Limit
}
