package router

import (
	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
	"slot_framework/pkg/conf"
	"slot_framework/pkg/web"
	_ "slot_mi_game/docs"
	"strings"
)

type SwaggerRouter struct {
	baseConf *conf.BaseConf
}

func NewSwaggerRouter(baseConf *conf.BaseConf) web.Router {
	return &SwaggerRouter{
		baseConf: baseConf,
	}
}

func (r *SwaggerRouter) Handle(engine *gin.Engine) {
	// prd 和 uat 环境，不开放文档
	if strings.Contains(r.baseConf.GetProfile(), "prd") || strings.Contains(r.baseConf.GetProfile(), "uat") {
		return
	}
	engine.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler, ginSwagger.DefaultModelsExpandDepth(5)))

}
