package router

import (
	"context"
	"github.com/panjf2000/ants/v2"
	"github.com/shopspring/decimal"
	"slot_common/pkg/cache"
	"slot_common/pkg/constants"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/constants/game_name"
	"slot_common/pkg/dao/es_dao"
	"slot_common/pkg/dao/mysql_dao"
	"slot_common/pkg/dto"
	"slot_common/pkg/model/mysql_model"
	"slot_common/pkg/rsp"
	"slot_common/pkg/runtime"
	"slot_common/pkg/wallet"
	"slot_framework/pkg/conf"
	fwConstants "slot_framework/pkg/constants"
	"slot_framework/pkg/data/mysql"
	"slot_framework/pkg/log"
	"slot_framework/pkg/utils"
	"slot_framework/pkg/web"
	gameDto "slot_mi_game/internal/dto"
	"slot_mi_game/internal/games"
	"slot_mi_game/internal/service"
	"strconv"

	"github.com/gin-gonic/gin"
	"go.uber.org/fx"
)

type TestRouterArgs struct {
	fx.In
	TxManager          *mysql.TxManager
	TblUserWalletDao   *mysql_dao.TblUserWalletDao
	TblUserDao         *mysql_dao.TblUserDao
	BaseConf           *conf.BaseConf
	SettlementService  *service.SettlementService
	UserCache          *cache.UserCache
	MerchantCache      *cache.MerchantCache
	UserWalletService  *wallet.UserWalletService
	SlotGameHistoryDao *es_dao.SlotGameHistoryDao
	Factory            *games.SlotGameHandlerFactory
}

type TestRouter struct {
	args *TestRouterArgs
}

func NewTestRouter(args TestRouterArgs) web.Router {
	return &TestRouter{
		args: &args,
	}
}

func (r *TestRouter) Handle(engine *gin.Engine) {
	// prd 和 uat 环境，不开放文档
	profile := r.args.BaseConf.GetProfile()
	if profile == "dev" || profile == "local" {
		group := engine.Group("/test")
		web.GET(group, "/user/wallet/update", r.userWalletUpdateTest)
		web.GET(group, "/user/wallet/query", r.userWalletQueryTest)
		web.GET(group, "/settlement/concurrency", r.settlementConcurrencyTest)
		web.GET(group, "/settlement/multiUser", r.multiUserConcurrencyTest)
		web.GET(group, "/initTestUser", r.initTestUser)
		web.GET(group, "/checkBalance", r.checkBalance)
	}
}

func (r *TestRouter) userWalletUpdateTest(wrapper *web.ContextWrapper) *rsp.SlotApiResponse[[]*mysql_model.TblUserWallet] {
	ctx := wrapper.Request.Context()
	ctx = r.args.TxManager.Begin(ctx)
	defer r.args.TxManager.End(ctx)
	users, _ := r.args.TblUserDao.QueryUserByIds(ctx, []string{
		"1943864036949385216",
		"1943864036949385217",
		"1943864036949385218",
		"1943864036949385220",
	})
	userWalletChanges := make([]*dto.UserWalletChangeDto, len(users))
	for i := 0; i < len(users); i++ {
		userWalletChanges[i] = &dto.UserWalletChangeDto{
			TblUser:     users[i],
			ChangeValue: float64(i + 1),
		}
	}
	wallets, err := r.args.TblUserWalletDao.UpdateMultiUserWallet(ctx, userWalletChanges, true)
	if err != nil {
		log.Error(ctx, "批量更新用户钱包失败", err)
	}
	return rsp.NewSlotApiSuccessRsp(ctx, wallets)
}
func (r *TestRouter) userWalletQueryTest(wrapper *web.ContextWrapper) *rsp.SlotApiResponse[[]*mysql_model.TblUserWallet] {
	ctx := wrapper.Request.Context()
	ctx = r.args.TxManager.Begin(ctx)
	defer r.args.TxManager.End(ctx)
	users, _ := r.args.TblUserDao.QueryUserByIds(ctx, []string{
		"1943864036949385216",
		"1943864036949385217",
		"1943864036949385218",
		"1943864036949385220",
	})
	wallets, err := r.args.TblUserWalletDao.QueryMultiUserWallet(ctx, users)
	if err != nil {
		log.Error(ctx, "批量查询用户钱包失败", err)
	}
	return rsp.NewSlotApiSuccessRsp(ctx, wallets)
}

// settlementConcurrencyTest 单用户结算
// 请求样例：http://localhost:8863/test/settlement/concurrency?total=1000&userId=1943864036949385218&concurrency=100
func (r *TestRouter) settlementConcurrencyTest(wrapper *web.ContextWrapper) *rsp.SlotGameResponse[any] {
	ctx := wrapper.Request.Context()
	userId := wrapper.Query("userId")
	totalStr := wrapper.Query("total")
	total, err := strconv.Atoi(totalStr)
	if err != nil {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.InvalidRequestErr))
	}
	if total < 1 {
		total = 1
	}
	concurrencyStr := wrapper.Query("concurrency")
	concurrency, err := strconv.Atoi(concurrencyStr)
	if err != nil {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.InvalidRequestErr))
	}
	if concurrency < 1 {
		concurrency = 1
	}
	user, exists := r.args.UserCache.GetUserById(ctx, userId)
	if !exists {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.PlayerNotExistErr))
	}
	merchant, merchantExists := r.args.MerchantCache.GetMerchantById(ctx, utils.AsValue(user.MerchantID))
	if !merchantExists {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.InvalidMerchantErr))
	}
	slotUser := &gameDto.SlotUserInfo{
		Merchant:   merchant,
		User:       user,
		UserId:     userId,
		CurrencyId: int64(utils.AsValue(user.CurrencyID)),
	}
	gameId := 3
	traceId := ctx.Value(fwConstants.TraceId).(string)
	pool, poolErr := ants.NewPool(concurrency, ants.WithPreAlloc(true), ants.WithMaxBlockingTasks(total))
	if poolErr != nil {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.GameStateErr))
	}
	for i := 0; i < total; i++ {
		//模拟结算
		submitErr := pool.Submit(func() {
			func(tid string) {
				newCtx := context.WithValue(context.Background(), fwConstants.TraceId, tid)
				defer func() {
					if recoverErr := recover(); recoverErr != nil {
						log.Error(newCtx, "并发余额测试 recover panic", recoverErr)
					}
				}()
				balance := r.args.UserWalletService.GetAvailableBalance(newCtx, &wallet.CommonReqInfo{
					Merchant: merchant,
					User:     user,
					GameId:   gameId,
				})
				req := gameDto.SpinReq{
					UserInfo:   slotUser,
					BetAmt:     1,
					Multiplier: 1,
					Fb:         "",
					Ab:         "",
					BpId:       nil,
					Token:      "tk",
				}
				settlement := &gameDto.Settlement{
					Spin:      &req,
					Mode:      constants.GameModeNormal,
					ParentId:  "",
					BetAmount: 1,
					WinAmount: 0.1,
					GameId:    gameId,
					GameName:  "并发测试",
					Balance:   balance,
				}
				r.args.SettlementService.DoSettlement(newCtx, settlement, func(result *gameDto.SettlementResult) string {
					return "concurrency test"
				})
			}(traceId)
		})
		if submitErr != nil {
			return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.GameStateErr))
		}
	}
	return rsp.NewResponse[any]("success")
}

// multiUserConcurrencyTest 多用户投注
// 请求样例： http://localhost:8863/test/settlement/multiUser? runLoop = 1000 & startUserId = 1000 & userCount = 500
func (r *TestRouter) multiUserConcurrencyTest(wrapper *web.ContextWrapper) *rsp.SlotGameResponse[any] {
	startUserIdStr := wrapper.Query("startUserId")
	startUserId, _ := strconv.Atoi(startUserIdStr)
	userCountStr := wrapper.Query("userCount")
	userCount, _ := strconv.Atoi(userCountStr)
	runLoopStr := wrapper.Query("runLoop")
	runLoop, _ := strconv.Atoi(runLoopStr)
	traceId := wrapper.Request.Context().Value(fwConstants.TraceId).(string)
	gameHandler := r.args.Factory.GetGameHandler(wrapper.Request.Context(), game_name.FortuneAce)
	for j := 0; j < userCount; j++ {
		userId := strconv.Itoa(startUserId + j)
		go func(tid string) {
			newCtx := context.WithValue(context.Background(), fwConstants.TraceId, tid)
			defer func() {
				if recoverErr := recover(); recoverErr != nil {
					log.Error(newCtx, "并发余额测试 recover panic", recoverErr)
				}
			}()
			user, _ := r.args.UserCache.GetUserById(newCtx, userId)
			merchant, _ := r.args.MerchantCache.GetMerchantById(newCtx, utils.AsValue(user.MerchantID))
			slotUser := &gameDto.SlotUserInfo{
				Merchant:   merchant,
				User:       user,
				UserId:     userId,
				CurrencyId: int64(utils.AsValue(user.CurrencyID)),
			}
			req := gameDto.SpinReq{
				UserInfo:   slotUser,
				BetAmt:     1,
				Multiplier: 1,
				Fb:         "1",
				Ab:         "",
				BpId:       nil,
				Token:      "tk",
			}
			for i := 0; i < runLoop; i++ {
				gameHandler.Spin(newCtx, &req)
			}
		}(traceId)

	}
	return rsp.NewResponse[any]("success")
}

// createUserByRange 初始化测试用户
// 请求样例： http://localhost:8863/test/initTestUser?copyFrom=1943864036949385218 & startUserId = 1000 & userCount = 500
func (r *TestRouter) initTestUser(wrapper *web.ContextWrapper) *rsp.SlotGameResponse[any] {
	ctx := wrapper.Request.Context()
	copyFromUserId := wrapper.Query("copyFrom")
	copyFrom, err := r.args.TblUserDao.QueryUserById(ctx, copyFromUserId)
	if err != nil {
		return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.PlayerNotExistErr))
	}
	startUserIdStr := wrapper.Query("startUserId")
	startUserId, _ := strconv.Atoi(startUserIdStr)
	userCountStr := wrapper.Query("userCount")
	userCount, _ := strconv.Atoi(userCountStr)
	initBalance := decimal.NewFromInt(100_0000)
	defaultValue := decimal.Zero
	for i := 0; i < userCount; i++ {
		userId := strconv.Itoa(startUserId + i)
		copiedUserInfo := *copyFrom
		copiedUserInfo.UserID = userId
		copiedUserInfo.UserName = &userId
		err = r.args.TblUserDao.Save(ctx, &copiedUserInfo)
		if err != nil {
			return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.GameStateErr))
		}
		err = r.args.TblUserWalletDao.Save(ctx, &mysql_model.TblUserWallet{
			UserID:           userId,
			Balance:          initBalance,
			FreezeBalance:    &defaultValue,
			AvailableBalance: &initBalance,
			CurrencyID:       utils.AsValue(copiedUserInfo.CurrencyID),
		}, &copiedUserInfo)
		if err != nil {
			return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.GameStateErr))
		}
	}
	return rsp.NewResponse[any]("success")
}

// checkBalance 对账
// 请求样例: http://localhost:8863/test/checkBalance?startUserId=1000&userCount=500
func (r *TestRouter) checkBalance(wrapper *web.ContextWrapper) *rsp.SlotGameResponse[any] {
	ctx := wrapper.Request.Context()
	startUserIdStr := wrapper.Query("startUserId")
	startUserId, _ := strconv.Atoi(startUserIdStr)
	userCountStr := wrapper.Query("userCount")
	userCount, _ := strconv.Atoi(userCountStr)
	initBalance := decimal.NewFromInt(100_0000)
	for i := 0; i < userCount; i++ {
		userId := strconv.Itoa(startUserId + i)
		user, _ := r.args.UserCache.GetUserById(ctx, userId)
		merchant, _ := r.args.MerchantCache.GetMerchantById(ctx, utils.AsValue(user.MerchantID))
		balance := r.args.UserWalletService.GetAvailableBalance(wrapper.Request.Context(), &wallet.CommonReqInfo{
			Merchant: merchant,
			User:     user,
			GameId:   3,
		})
		betAmt, rewardAmt, err := r.args.SlotGameHistoryDao.GetRecent24HoursBetAndReward(ctx, userId)
		if err != nil {
			return rsp.NewErrorResponse(runtime.NewSlotError(ctx, error_code.GameStateErr))
		}
		balanceDiff := decimal.NewFromFloat(balance).Sub(initBalance)
		betWin := rewardAmt.Sub(betAmt)

		checkValue := balanceDiff.Sub(betWin).InexactFloat64()
		if checkValue < -1 || checkValue > 1 {
			log.Info(ctx, "找到用户{},对账错误，{},{}", userId, balanceDiff, betWin)
		}
	}
	return rsp.NewResponse[any]("success")
}
