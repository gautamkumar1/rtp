package service

import (
	"context"
	"fmt"
	"github.com/shopspring/decimal"
	"go.uber.org/fx"
	"slot_common/pkg/constants"
	"slot_common/pkg/dao/mysql_dao"
	"slot_common/pkg/model/mysql_model"
	"slot_framework/pkg/debug"
	"slot_framework/pkg/log"
	"sort"
	"time"
)

type UserTaskServiceArgs struct {
	fx.In
	TblUserTaskRelationDao *mysql_dao.TblUserTaskRelationDao
	TblPropsDao            *mysql_dao.TblPropsDao
	TblUserPackageDao      *mysql_dao.TblUserPackageDao
	TblPackageRecordDao    *mysql_dao.TblPackageRecordDao
}

type UserTaskService struct {
	args *UserTaskServiceArgs
}

func NewUserTaskService(args UserTaskServiceArgs) *UserTaskService {
	return &UserTaskService{
		args: &args,
	}
}

func (s *UserTaskService) UserTaskProgress(ctx context.Context, userId string, todayTotalBet, betAmount float64) {
	if betAmount == 0 {
		return
	}
	defer debug.PrintTimeCost(ctx, fmt.Sprintf("%s", "UserTaskProgress"))()

	userTaskRels, err := s.args.TblUserTaskRelationDao.QueryTodayNotCompletedTask(ctx, userId)
	if err != nil {
		log.Error(ctx, "查询用户每日任务失败")
		return
	}
	sort.Slice(userTaskRels, func(i, j int) bool {
		return userTaskRels[i].TaskTarget.InexactFloat64() < userTaskRels[j].TaskTarget.InexactFloat64()
	})
	if len(userTaskRels) > 0 {
		for _, userTaskRel := range userTaskRels {
			if userTaskRel != nil {
				if todayTotalBet < userTaskRel.TaskTarget.InexactFloat64() {
					//更新进度
					err = s.args.TblUserTaskRelationDao.UpdateProcessBar(ctx, userTaskRel.ID, todayTotalBet)
					if err != nil {
						log.Error(ctx, "更新用户每日任务进度失败", err)
						return
					}
					break
				} else {
					todayTotalBet = decimal.NewFromFloat(todayTotalBet).Sub(userTaskRel.TaskTarget).InexactFloat64()
					if userTaskRel.TaskState != constants.TblTaskStateNotCompleted {
						continue
					}
					err = s.args.TblUserTaskRelationDao.Completed(ctx, userTaskRel.ID)
					if err != nil {
						log.Error(ctx, "更新用户每日任务进度失败", err)
						return
					}
					props, propsErr := s.args.TblPropsDao.QueryById(ctx, userTaskRel.AwardPid)
					if propsErr != nil {
						log.Error(ctx, "查询道具失败")
						return
					}

					awardNum := int(userTaskRel.AwardPnum)
					tblUserPackages := make([]*mysql_model.TblUserPackage, awardNum)
					packageRecords := make([]*mysql_model.PackageRecord, awardNum)
					for i := 0; i < awardNum; i++ {
						mp := mysql_model.TblUserPackage{
							UserID:     userId,
							PropsID:    props.ID,
							PropsName:  props.PropsDesc,
							PropsLevel: props.PropsLevel,
							PropsType:  props.PropsType,
							PropsIcon:  props.PropsIcon,
							BetAmount:  props.BetAmount,
							PropsDesc:  props.PropsDesc,
							CreatedAt:  int32(time.Now().Unix()),
							CurrencyID: props.CurrencyID,
							ExpiredAt:  int32(time.Now().Unix()) + props.AvailableTime*24*60*60,
							State:      1,
							GameID:     props.GameID,
							IsNew:      1,
						}
						tblUserPackages[i] = &mp

						pr := mysql_model.PackageRecord{
							PackageID:  mp.ID,
							PropsID:    props.ID,
							UserID:     userId,
							PropsName:  props.PropsName,
							PropsLevel: props.PropsLevel,
							RecordType: 1,
							BetAmount:  userTaskRel.TaskTarget,
							CreateAt:   int32(time.Now().Unix()),
							ExpiredAt:  int32(time.Now().Unix()) + props.AvailableTime*24*60*60,
							PropsDesc:  props.PropsDesc,
							Channel:    0,
							Num:        1,
							GameID:     props.GameID,
						}
						packageRecords[i] = &pr
					}

					upErr := s.args.TblUserPackageDao.SaveAll(ctx, tblUserPackages)
					if upErr != nil {
						log.Error(ctx, "保存用户背包道具错误", upErr)
						return
					}
					//重新填充生成（Id在保存后生成）
					for i := range tblUserPackages {
						packageRecords[i].PackageID = tblUserPackages[i].ID
					}
					prErr := s.args.TblPackageRecordDao.SaveAll(ctx, packageRecords)
					if prErr != nil {
						log.Error(ctx, "用户背包记录插入失败", upErr)
						return
					}
				}
			}
		}
	}
}
