package service

import (
	"context"
	"fmt"
	"github.com/shopspring/decimal"
	"go.uber.org/fx"
	"gorm.io/gorm"
	"math"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/dao/mysql_dao"
	"slot_common/pkg/model/mysql_model"
	"slot_common/pkg/runtime"
	redis "slot_framework/pkg/data/redis/v9"
	"slot_framework/pkg/log"
	"time"
)

type UserPackageServiceArgs struct {
	fx.In
	RedisTemplate          *redis.RedisTemplate
	TblUserPackageDao      *mysql_dao.TblUserPackageDao
	TblPackageRecordDao    *mysql_dao.TblPackageRecordDao
	TblUserTaskRelationDao *mysql_dao.TblUserTaskRelationDao
}

type UserPackageService struct {
	args *UserPackageServiceArgs
}

func NewUserPackageService(args UserPackageServiceArgs) *UserPackageService {
	return &UserPackageService{
		args: &args,
	}
}

func (s *UserPackageService) QueryUnusePackageById(ctx context.Context, packageId int, gameId int) *mysql_model.TblUserPackage {
	tblUserPackage, err := s.args.TblUserPackageDao.QueryUnusedPackage(ctx, packageId)
	if err != nil || tblUserPackage == nil {
		panic(runtime.NewSlotError(ctx, error_code.PropsNotExistErr))
	}
	if int(tblUserPackage.GameID) != gameId {
		panic(runtime.NewSlotError(ctx, error_code.PropsNotExistErr))
	}
	//如果过期时间小于当前时间，
	if int64(tblUserPackage.ExpiredAt) < time.Now().Unix() {
		_ = s.args.TblUserPackageDao.UpdatePackageAsExpired(ctx, int(tblUserPackage.ID))
		//道具已过期
		panic(runtime.NewSlotError(ctx, error_code.PropsExpiredErr))
	}
	return tblUserPackage
}

func (s *UserPackageService) UpdatePackageAsUsed(ctx context.Context, userPackage *mysql_model.TblUserPackage, winAmount float64) error {
	err := s.args.TblUserPackageDao.UpdatePackageAsUsed(ctx, int(userPackage.ID))
	if err != nil {
		log.Error(ctx, "更新背包状态为已使用失败", err.Error())
		return err
	}
	pr := mysql_model.PackageRecord{
		PackageID:  userPackage.ID,
		PropsID:    userPackage.PropsID,
		UserID:     userPackage.UserID,
		PropsName:  userPackage.PropsName,
		PropsLevel: userPackage.PropsLevel,
		RecordType: 2,
		CreateAt:   int32(time.Now().Unix()),
		ExpiredAt:  userPackage.ExpiredAt,
		PropsDesc:  userPackage.PropsDesc,
		WinAmount:  decimal.NewFromFloat(winAmount),
		GameID:     userPackage.GameID,
	}
	recordErr := s.args.TblPackageRecordDao.Save(ctx, &pr)
	if recordErr != nil {
		log.Error(ctx, "用户背包记录保存失败", recordErr.Error())
	}
	return recordErr
}

func (s *UserPackageService) UpdatePackageRecordWinAmount(ctx context.Context, packageId int, winAmount float64) {
	if packageId != 0 && winAmount > 0 {
		repo := s.args.TblPackageRecordDao.Query(ctx).PackageRecord
		_, _ = repo.WithContext(ctx).WriteDB().Where(repo.PackageID.Eq(int32(packageId))).Updates(map[string]any{
			repo.WinAmount.ColumnName().String(): gorm.Expr("win_amount + ?", winAmount),
		})
	}
}

func (s *UserPackageService) AddBetInCents(ctx context.Context, userId string, amount float64) float64 {
	cents := amountToCents(amount)
	key := fmt.Sprintf("bet:total:%s:%s", userId, time.Now().Format("2006-01-02"))
	// Redis 原子自增
	newVal, err := s.args.RedisTemplate.IncrementBy(ctx, key, cents)
	if err != nil {
		return 0
	}
	// 转回元
	todayBetAmount := decimal.NewFromInt(newVal).Div(decimal.NewFromFloat(100)).InexactFloat64()
	return todayBetAmount
}

// 金额换算成分（避免浮点误差）
func amountToCents(amount float64) int64 {
	return int64(math.Round(amount * 100))
}
