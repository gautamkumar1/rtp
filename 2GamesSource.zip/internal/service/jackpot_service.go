package service

import (
	"context"
	"fmt"
	
	"slot_common/pkg/runtime"
	"slot_framework/pkg/conf"
	"slot_framework/pkg/httpclient"
	"slot_framework/pkg/debug"
	"slot_framework/pkg/log"
	_const "slot_mi_game/internal/constants"
	"slot_mi_game/internal/dto"
	"time"

	
	"go.uber.org/fx"
)

type JackpotServiceArgs struct {
	fx.In
	BaseConf *conf.BaseConf
}

type JackpotService struct {
	args *JackpotServiceArgs
}

func NewJackpotService(args JackpotServiceArgs) *JackpotService {
	return &JackpotService{
		args: &args,
	}
}

/*
*
请求jackpot服，返回是不是有中奖
*/
func (s *JackpotService) RequestJackpot(
	ctx context.Context, userInfo *dto.SlotUserInfo,
	betAmt float64, token string, historyId string, orderTimeMs int64) (result *dto.SlotJackpotResp) {

	defer debug.PrintTimeCost(ctx, fmt.Sprintf("%s", "RequestJackpot"))()

	result = &dto.SlotJackpotResp{}
	tmpUrl := s.args.BaseConf.GetString("jackpot.server", "")
	if tmpUrl == "" {
		log.Error(ctx, "jackpot server is not set⭕️⭕️⭕️⭕️⭕️⭕️⭕️⭕️⭕️⭕️")
		return
	}
	tail := "/data-api/jackpot/trigger"

	//打印日志
	log.Info(ctx, "RequestJackpot 🌟🌟请求jackpot服, url: {}, betAmt: {}, token: {}, currencyId: {}", tmpUrl+tail, betAmt, token, userInfo.CurrencyId)
	resp := s.triggerJackpot(tmpUrl+tail, token, betAmt, userInfo.CurrencyId, historyId , orderTimeMs )
	result.WinMode = 0
	result.WinAmount = 0.0
	if resp.Error != nil && resp.Error.Code != "" {
		log.Info(ctx, "jackpot resp error了笨{}", resp.Error)
		return
	}
	log.Info(ctx, "jackpot resp{}", resp)
	result.PoolInfo = resp.Data.Pool
	if resp.Data.Status != 0 {
		result.WinAmount = resp.Data.Result.Money
		result.JackpotNumber = resp.Data.Result.DrawNumber
		switch resp.Data.Result.DrawName {
		case _const.JP_GRAND:
			result.WinMode = _const.JP_GrandMode
		case _const.JP_MAJOR:
			result.WinMode = _const.JP_MajorMode
		case _const.JP_MINOR:
			result.WinMode = _const.JP_MinorMode
		case _const.JP_MINI:
			result.WinMode = _const.JP_MiniMode
		}

	}
	return result
}
func (s *JackpotService) triggerJackpot(url string, atk string, cs float64, currencyId int64,
	historyId string, orderTimeMs int64	) dto.JackpotResult {
	/*
		请求jackpot服，返回中奖信息
	*/
	var (
	result dto.JackpotResult
	// response map[string]any
	 client = httpclient.NewClient()
	 data = map[string]string{
		"atk": atk,
		"cs":  fmt.Sprint(cs),
		"cid": fmt.Sprint(currencyId),
		"hid": historyId,
		"ot": fmt.Sprint(orderTimeMs),
	})
	client.Timeout = 3 * time.Second
	err := client.PostForm(context.Background(), 
		url,data,  &result)
	/*
	resp, err := resty.New().SetTimeout(3*time.Second). // 设置 3 秒超时
								R().
								SetHeader("Content-Type", "application/x-www-form-urlencoded"). // 如果是表单
								SetFormData(map[string]string{
			"atk": atk,
			"cs":  fmt.Sprint(cs),
			"cid": fmt.Sprint(currencyId),
		}).
		SetResult(&result). // or SetResult(AuthSuccess{}).
		Post(url)*/
	if err != nil || 
		(result.Error != nil && result.Error.Code != "") {
		if result.Error == nil {
				result.Error = &runtime.SlotError{
					Code : "10404",
				}
			}else {
			if result.Error.Code == "" {
				result.Error.Code = "10043"
			}
		}//end if result.Error == nil
		if err != nil {
			result.Error.Message = fmt.Sprintf("http返回%s-请求参数:%f",  err.Error(), cs)
		} else {
			result.Error.Message = fmt.Sprintf("请求参数:%f", cs)
		}//end if err != nil
	} //end if 报错
	return result
}

/*
*
有多大的概率会去请求jackpot服
<=r时会请求jackpot服
*/
func (s *JackpotService) GetJackpotBaseRate() float64 {
	return 0.001
}
