package service

import (
	"context"
	"github.com/pkg/errors"
	"go.uber.org/fx"
	"slot_common/pkg/cache"
	"slot_common/pkg/constants"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/dao/mysql_dao"
	"slot_common/pkg/model/mysql_model"
	"slot_common/pkg/runtime"
	fwCache "slot_framework/pkg/cache"
	"slot_framework/pkg/data/mysql"
	"slot_framework/pkg/log"
	"slot_framework/pkg/utils"
	"slot_mi_core/pkg"
	"slot_mi_core/slotengine"
	"slot_mi_core/slots/pharaohtreasure"
	"slot_mi_game/internal/constants/cache_name"
	"slot_mi_game/internal/dto"
	"strconv"
	"strings"
)

type ReelServiceArgs struct {
	fx.In
	GameDrawConfigCache     *cache.GameDrawConfigCache
	TblGameDrawConfigDao    *mysql_dao.TblGameDrawConfigDao
	TblEngineReelsConfigDao *mysql_dao.TblEngineReelsConfigDao
	TxManager               *mysql.TxManager
	CacheEmitter            *fwCache.Emitter
}

type ReelService struct {
	args *ReelServiceArgs
}

func NewReelService(args ReelServiceArgs) *ReelService {
	return &ReelService{
		args: &args,
	}
}

func (s *ReelService) GetReels(ctx context.Context, gameId int, gameState int, userInfo *dto.SlotUserInfo) ([][]int, error) {
	volatility := int(utils.AsValue(userInfo.Merchant.Volatility))
	cfgs, ok := s.args.GameDrawConfigCache.GetGameDrawConfig(ctx, gameId, volatility, gameState)
	if !ok || len(cfgs) == 0 {
		log.Error(ctx, "read reels error ,gameId : {}, gameMode:{},Volatility :{}", gameId, gameState, volatility)
		return nil, errors.New("cannot read reels")
	}
	reels := make([][]int, len(cfgs))
	for i := range cfgs {
		icons := strings.Split(utils.AsValue(cfgs[i].Base), ",")
		reels[i] = utils.SliceToOtherSlice(icons, func(v1 string) int {
			value, _ := strconv.Atoi(v1)
			return value
		})
	}
	return reels, nil
}

func (s *ReelService) SyncEngineReels(ctx context.Context, gameId int) {
	ctx = s.args.TxManager.Begin(ctx)
	s.args.TxManager.RegisterAfterTxCommitHandler(ctx, func() {
		s.args.CacheEmitter.NotifyAll(cache_name.GetEngineCacheName(gameId))
	})
	defer s.args.TxManager.End(ctx)
	buyFreeFlags := []bool{true, false} //0:普通，1:买免
	volatilityList := []int32{0, 1, 2}  //0:低波，1:中波，2:高波
	gameRtp := "medium"
	cfgs := make([]*mysql_model.TblEngineReelsConfig, 0)
	for _, isBuyFree := range buyFreeFlags {
		gameMode := constants.TblEngineReelsGameModeNormal
		if isBuyFree {
			gameMode = constants.TblEngineReelsGameModeBuyFree
		}
		for _, volatility := range volatilityList {
			cfg := &mysql_model.TblEngineReelsConfig{
				KindID:       int32(gameId),
				GameMode:     int32(gameMode),
				Volatility:   volatility,
				Remark:       "",
				RtpLevel:     gameRtp,
				RPCAddress:   "https://slot-engine-v1.pgs-games.com",
				TestScenario: "",
			}
			cfgs = append(cfgs, cfg)
		}
	}
	err := s.args.TblEngineReelsConfigDao.SaveAll(ctx, cfgs)
	if err != nil {
		panic(runtime.NewSlotError(ctx, error_code.SystemErr))
	}
}

func (s *ReelService) SyncReels(ctx context.Context, gameId int) {
	gameModes := []int{pkg.NormalGameMode, pkg.FreeGameMode, pkg.BuyFreeGameMode}
	volatilityList := []int{pkg.HighVolatility, pkg.MediumVolatility, pkg.LowVolatility}
	gameRtp := pkg.MediumRtpLevel
	gameDrawConfigs := make([]*mysql_model.TblGameDrawConfig, 0)
	emptyStr := ""
	for _, gameMode := range gameModes {
		//GameStateNormal  = 1 //普通游戏
		//GameStateFree    = 2 // 免费游戏
		//GameStateFreeBuy = 3 // 购买免费
		gameState := int32(gameMode + 1)
		for _, volatility := range volatilityList {
			reelMap := make(map[int32]int32)
			cfgs, exists := s.args.GameDrawConfigCache.GetGameDrawConfig(ctx, gameId, volatility, int(gameState))
			if exists {
				for i := range cfgs {
					reelMap[utils.AsValue(cfgs[i].Reel)] = cfgs[i].ID
				}
			}
			vl := int32(volatility)
			reels := s.getReelsFromCore(ctx, gameMode, volatility, gameId, gameRtp)
			for i := 0; i < len(reels); i++ {
				base := utils.JoinAsString(reels[i], func(s slotengine.Symbol) string {
					return string(s)
				}, ",")
				reelIdx := int32(i + 1)
				gameDrawConfig := &mysql_model.TblGameDrawConfig{
					KindID:     int32(gameId),
					GameState:  &gameState,
					Base:       &base,
					Bomb:       &emptyStr,
					Buy:        &emptyStr,
					Reel:       &reelIdx,
					Volatility: &vl,
					Remark:     &emptyStr,
					Rtp:        &gameRtp,
				}
				id, ok := reelMap[reelIdx]
				if ok {
					gameDrawConfig.ID = id
				}
				gameDrawConfigs = append(gameDrawConfigs, gameDrawConfig)
			}
		}
	}
	err := s.args.TblGameDrawConfigDao.SaveAll(ctx, gameDrawConfigs)
	if err != nil {
		panic(runtime.NewSlotError(ctx, error_code.SystemErr))
	}
}

func (s *ReelService) getReelsFromCore(ctx context.Context, gameMode, volatility, gameId int, gameRtp string) [][]slotengine.Symbol {
	switch gameId {
	case pkg.PharaohTreasureGameId:
		g := pharaohtreasure.NewPharaohTreasureGame()
		reels, _ := g.GetReels(gameMode, gameRtp, volatility)
		return [][]slotengine.Symbol{s.toSymbol(reels[0]), s.toSymbol(reels[1]), s.toSymbol(reels[2]), s.toSymbol(reels[3]), s.toSymbol(reels[4]), s.toSymbol(reels[5]), s.toSymbol(reels[6])}
	}
	panic(runtime.NewSlotError(ctx, error_code.GameNotFoundErr))
}

func (s *ReelService) toSymbol(reel []int) []slotengine.Symbol {
	return utils.SliceToOtherSlice(reel, func(v1 int) slotengine.Symbol {
		return slotengine.Symbol(utils.ToString(v1))
	})
}
