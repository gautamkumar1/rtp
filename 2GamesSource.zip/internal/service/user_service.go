package service

import (
	"context"
	"fmt"
	"go.uber.org/fx"
	"gorm.io/gorm"
	"slot_common/pkg/cache"
	"slot_common/pkg/dao/mysql_dao"
	"slot_framework/pkg/debug"
	"slot_mi_game/internal/dto"
	"time"
)

type UserServiceArgs struct {
	fx.In
	LevelConfigCache       *cache.LevelConfigCache
	VipLevelSwitchCache    *cache.VipLevelSwitchCache
	TblUserDao             *mysql_dao.TblUserDao
	TblLevelAwardRecordDao *mysql_dao.TblLevelAwardRecordDao
}

type UserService struct {
	args *UserServiceArgs
}

func NewUserService(args UserServiceArgs) *UserService {
	return &UserService{
		args: &args,
	}
}

func (s *UserService) UpdateUserAmt(ctx context.Context, userInfo *dto.SlotUserInfo, betAmt float64, winAmt float64) {
	defer debug.PrintTimeCost(ctx, fmt.Sprintf("%s", "UpdateUserAmt"))()

	/*user, err := s.args.TblUserDao.QueryUserById(ctx, userInfo.UserId)
	if err != nil {
		log.Error(ctx, "用户查询失败")
		return
	}*/
	/*levelConfigs := s.args.LevelConfigCache.GetLevelConfigByCurrencyId(ctx, int(userInfo.CurrencyId))
	totalBet := user.TotalBet.InexactFloat64() + betAmt
	levelNum := int32(0)
	for _, config := range levelConfigs {
		if int64(totalBet) >= config.LevelLimit && config.LevelNum > levelNum {
			levelNum = config.LevelNum
		}
	}
	log.Info(ctx, "levelNum:{}-----User.VipLevel:{}", levelNum, user.VipLevel)*/
	updateColumns := make(map[string]any)
	if betAmt > 0 {
		updateColumns["total_bet"] = gorm.Expr("total_bet + ?", betAmt)

		// vip等级开关
		if s.args.VipLevelSwitchCache.IsVipLevelEnabled(ctx) {
			updateColumns["exp"] = gorm.Expr("exp + ?", betAmt)
		}

		updateColumns["total_bet_num"] = gorm.Expr("total_bet_num + ?", 1)
		updateColumns["last_bet_time"] = time.Now().Unix()
		updateColumns["login_bet_count"] = gorm.Expr("login_bet_count + ?", 1)
	}
	/*if levelNum > user.VipLevel {
		updateColumns["vip_level"] = levelNum
		levelAwardRecords := make([]*mysql_model.LevelAwardRecord, 0)
		for i := user.VipLevel + 1; i <= levelNum; i++ {
			pr := mysql_model.LevelAwardRecord{
				UserID:   user.UserID,
				LevelNum: i,
				State:    2,
			}
			levelAwardRecords = append(levelAwardRecords, &pr)
		}
		awardRecordErr := s.args.TblLevelAwardRecordDao.SaveAll(ctx, levelAwardRecords)
		if awardRecordErr != nil {
			log.Error(ctx, "保存等级奖励失败", awardRecordErr)
		}
	}*/
	if winAmt > 0 {
		updateColumns["total_win"] = gorm.Expr("total_win + ?", winAmt)
	}
	if len(updateColumns) > 0 {
		_ = s.args.TblUserDao.DoUpdateColumns(ctx, userInfo.UserId, updateColumns)
	}
}
