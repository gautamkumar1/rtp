package service

import "testing"

func TestReq(t *testing.T) {
	/*s := NewJackpotService(JackpotServiceArgs{
		BaseConf: nil,
	})

	   s.triggerJackpot("https://slot-data-master.pgs-games.com/data-api/jackpot/trigger",

	   	 "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjM0LCJqdGkiOiIxOTY3Nzc1NTcxNzczOTc2NTc2IiwiaWF0IjoxLCJuYmYiOjE3NTc5ODkyMzN9.jyI0sTrx-cx44EAVGjBVlKGAJAxPIktET7tmb5i6d3o",
	   	// "fdsafsdaas",
	   	109000.0,
	   	1)
	*/
}
