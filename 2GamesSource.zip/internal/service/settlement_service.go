package service

import (
	"context"
	"fmt"
	"math"
	"slot_common/pkg/constants"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/dao/es_dao"
	"slot_common/pkg/dao/mysql_dao"
	"slot_common/pkg/model/es_model"
	"slot_common/pkg/model/mysql_model"
	"slot_common/pkg/runtime"
	"slot_common/pkg/wallet"
	constants2 "slot_framework/pkg/constants"
	esv7 "slot_framework/pkg/data/es/v7"
	"slot_framework/pkg/data/mysql"
	"slot_framework/pkg/debug"
	"slot_framework/pkg/geo"
	"slot_framework/pkg/log"
	"slot_framework/pkg/snowflake"
	"slot_framework/pkg/utils"
	"slot_mi_game/internal/dto"

	"time"

	"github.com/shopspring/decimal"
	"go.uber.org/fx"
)

type SettlementServiceArgs struct {
	fx.In
	SnowflakeGenerator      *snowflake.Generator
	TxManager               *mysql.TxManager
	SlotTransferRecordDao   *es_dao.SlotTransferRecordDao
	SlotGameHistoryDao      *es_dao.SlotGameHistoryDao
	UserWalletService       *wallet.UserWalletService
	UserLastDataDao         *es_dao.SlotUserLastDataDao
	TblEsRollbackRedoLogDao *mysql_dao.TblEsRollbackRedoLogDao
	BatchOperation          *esv7.BatchOperation
	GeoService              *geo.GeoService
}

type SettlementService struct {
	args *SettlementServiceArgs
}

func NewSettlementService(args SettlementServiceArgs) *SettlementService {
	return &SettlementService{
		args: &args,
	}
}

func (s *SettlementService) DoSettlement(ctx context.Context, settlement *dto.Settlement, gameDataFunc func(*dto.SettlementResult) string) *dto.SettlementResult {
	historyId := s.args.SnowflakeGenerator.NextStringId()
	orderTimeMs := time.Now().UnixMilli()
	return s.DoSettlementWithCustomAction(ctx, settlement,
		historyId, orderTimeMs,
		gameDataFunc)
}

// DoSettlementWithCustomAction
// 通用游戏结算流程，统一抽出
func (s *SettlementService) DoSettlementWithCustomAction(
	ctx context.Context, settlement *dto.Settlement, historyId string, orderTimeMs int64,
	gameDataFunc func(*dto.SettlementResult) string) *dto.SettlementResult {
	singleWallet := settlement.Spin.UserInfo.Merchant.WalletType == constants.WalletSingle
	if singleWallet {
		defer debug.PrintTimeCost(ctx, "DoSettlementSingleWallet")()
	} else {
		defer debug.PrintTimeCost(ctx, "DoSettlementTransferWallet")()
	}

	transferId := s.args.SnowflakeGenerator.NextStringId()

	// 记录客户端IP和国家
	clientIp := fmt.Sprintf("%v", ctx.Value(constants2.RealClientIp))
	clientCountry := ""
	if clientIp != "" {
		if clientIp != "127.0.0.1" && clientIp != "localhost" && clientIp != "::1" {
			clientCountry = s.args.GeoService.GetCountry(clientIp)
		} else {
			clientCountry = "internal"
		}
	}
	gameHistory := &es_model.GameHistory{
		HistoryId:         historyId,
		KindId:            settlement.GameId,
		ParentId:          historyId,
		GameMode:          settlement.Mode,
		BetSize:           settlement.Spin.BetAmt,
		BetLevel:          settlement.Spin.Multiplier,
		Multiplier:        1,
		UserId:            settlement.Spin.UserInfo.User.UserID,
		UserName:          utils.AsValue(settlement.Spin.UserInfo.User.UserName),
		KindName:          settlement.GameName,
		NickName:          utils.AsValue(settlement.Spin.UserInfo.User.Nickname),
		MerchantId:        int64(settlement.Spin.UserInfo.Merchant.MerchantID),
		MerchantCode:      settlement.Spin.UserInfo.Merchant.Code,
		MerchantName:      settlement.Spin.UserInfo.Merchant.MerchantName,
		Zone:              int(settlement.Spin.UserInfo.User.Zone),
		CurrencyId:        int64(utils.AsValue(settlement.Spin.UserInfo.User.CurrencyID)),
		BetAmount:         settlement.BetAmount,
		WinAmount:         settlement.WinAmount,
		ValidateBetAmount: settlement.BetAmount,
		CreateAt:          orderTimeMs,
		FirstBetAt:        orderTimeMs,
		PayoutAt:          orderTimeMs,
		Round:             1,
		IP:                clientIp,
		Country:           clientCountry,
	}
	//构建转账记录
	transferRecord := &es_model.TransferRecord{
		Id:           transferId,
		UserId:       settlement.Spin.UserInfo.User.UserID,
		KindId:       settlement.GameId,
		KindName:     settlement.GameName,
		UserName:     utils.AsValue(settlement.Spin.UserInfo.User.UserName),
		TfType:       constants.TransferGame, //投注派彩
		BetAmount:    settlement.BetAmount,
		PayOutAmount: settlement.WinAmount,
		CurrencyId:   int64(utils.AsValue(settlement.Spin.UserInfo.User.CurrencyID)),
		Status:       constants.StateOk,
		CreateAt:     orderTimeMs,
		Mode:         int(settlement.Spin.UserInfo.Merchant.WalletType),
		MerchantId:   int64(settlement.Spin.UserInfo.Merchant.MerchantID),
		MerchantName: settlement.Spin.UserInfo.Merchant.MerchantName,
	}
	if settlement.Mode == constants.GameModeBuyFree {
		transferRecord.TfType = constants.TransferBuyFree
	}
	//游戏记录是否保存成功，如果发生回滚，需要删除游戏记录
	gameHistorySaved := false
	//用户金额是否已经发生变更
	userBalanceChanged := false
	//变更前余额
	beforeBalance := settlement.Balance
	ctx = s.args.TxManager.Begin(ctx)
	defer s.args.TxManager.End(ctx)
	s.args.TxManager.RegisterAfterTxRollbackHandler(ctx, func() {
		//如果是自定义流程部分错误，或者转账记录错误，那么需要回滚注单
		redoLogs := make([]*mysql_model.TblEsRollbackRedoLog, 0)
		if gameHistorySaved {
			batch := s.args.BatchOperation.PrepareBatch()
			s.args.SlotGameHistoryDao.AddDeleteRequestInBatch(gameHistory, batch)
			s.args.SlotTransferRecordDao.AddDeleteRequestInBatch(transferRecord, batch)
			err := batch.Commit(ctx)
			if err != nil {
				log.Error(ctx, "回滚注单记录错误,historyId:{},transferId:{} ", historyId, transferId)
				redoLogs = append(redoLogs, &mysql_model.TblEsRollbackRedoLog{
					RollbackID:    historyId,
					RollbackIndex: s.args.SlotGameHistoryDao.GetIndex(gameHistory),
					RetryCount:    0,
					CreateAt:      orderTimeMs,
					UpdateAt:      orderTimeMs,
				})
				redoLogs = append(redoLogs, &mysql_model.TblEsRollbackRedoLog{
					RollbackID:    transferId,
					RollbackIndex: s.args.SlotTransferRecordDao.GetIndex(transferRecord),
					RetryCount:    0,
					CreateAt:      orderTimeMs,
					UpdateAt:      orderTimeMs,
				})
			}
		}
		//如果是es回滚发生错误，保存回滚错误redo日志，方便job重试
		if len(redoLogs) > 0 {
			createErr := s.args.TblEsRollbackRedoLogDao.Create(context.Background(), redoLogs...)
			if createErr != nil {
				log.Error(ctx, "保存回滚错误redo日志错误，无解，请检索该日志定位问题，,historyId:{} ,transferId :{} ", historyId, transferId)
			}
		}
		// 如果是普通钱包，mysql自动回滚
		// 如果是单钱包，发生事务回滚时，如果余额已经变更成功，应该要扣回派彩（用户赢），或者返还本金（用户输）
		if singleWallet && userBalanceChanged {
			rollbackTransferId := s.args.SnowflakeGenerator.NextStringId()
			s.args.UserWalletService.UpdateUserBalance(ctx, &wallet.TransferReqInfo{
				CommonReqInfo: wallet.CommonReqInfo{
					Merchant: settlement.Spin.UserInfo.Merchant,
					User:     settlement.Spin.UserInfo.User,
					GameId:   settlement.GameId,
				},
				Balance:    beforeBalance,
				BetAmt:     settlement.BetAmount,
				WinAmt:     settlement.WinAmount,
				HistoryId:  historyId,
				ParentId:   settlement.ParentId,
				TransferId: rollbackTransferId,
				IsRollback: true,
			})
		}
	})
	amount := decimal.NewFromFloat(settlement.WinAmount).Sub(decimal.NewFromFloat(settlement.BetAmount)).InexactFloat64()
	//存在输赢，需要变更余额
	if math.Abs(amount) > 1e-6 {
		//更新用户余额，返回更新前的用户余额
		balance := s.args.UserWalletService.UpdateUserBalance(ctx, &wallet.TransferReqInfo{
			CommonReqInfo: wallet.CommonReqInfo{
				Merchant: settlement.Spin.UserInfo.Merchant,
				User:     settlement.Spin.UserInfo.User,
				GameId:   settlement.GameId,
			},
			Balance:    settlement.Balance,
			BetAmt:     settlement.BetAmount,
			WinAmt:     settlement.WinAmount,
			HistoryId:  historyId,
			ParentId:   settlement.ParentId,
			TransferId: transferId,
			IsRollback: false,
		})
		userBalanceChanged = true
		beforeBalance = balance
	}

	settlementResult := &dto.SettlementResult{
		ParentId:      gameHistory.ParentId,
		HistoryId:     historyId,
		TransferId:    transferId,
		BeforeBalance: beforeBalance,
	}
	//构建游戏历史记录
	afterAmount := decimal.NewFromFloat(amount).Add(decimal.NewFromFloat(beforeBalance)).InexactFloat64()
	gameData := gameDataFunc(settlementResult)
	gameHistory.Data = gameData
	gameHistory.WinLossAmount = amount
	gameHistory.BeforeAmount = beforeBalance
	gameHistory.AfterAmount = afterAmount
	gameHistory.State = wallet.WinOrLose(amount)
	if settlement.ParentId != "" {
		gameHistory.ParentId = settlement.ParentId
	}

	//构建转账记录
	transferRecord.Before = beforeBalance
	transferRecord.After = afterAmount
	transferRecord.HistoryId = historyId
	transferRecord.MerchantTransferId = historyId

	//转账记录和gameHistory以及用户最近游戏记录一起提交
	batch := s.args.BatchOperation.PrepareBatch()
	s.args.SlotGameHistoryDao.AddSaveRequestInBatch(gameHistory, batch)
	s.args.SlotTransferRecordDao.AddSaveRequestInBatch(transferRecord, batch)
	s.args.UserLastDataDao.AddSaveRequestInBatch(&es_model.SlotUserLastData{
		KindId: gameHistory.KindId,
		UserId: gameHistory.UserId,
		Data:   gameHistory.Data}, batch)
	err := batch.Commit(ctx)
	if err != nil {
		//批量提交失败后，需要触发回滚
		log.Error(ctx, "保存游戏记录失败,historyId:{}，transferId:{}", historyId, transferId, err)
		panic(runtime.NewSlotError(ctx, error_code.DaoSaveHistoryErr))
	}
	gameHistorySaved = true
	return settlementResult
}
