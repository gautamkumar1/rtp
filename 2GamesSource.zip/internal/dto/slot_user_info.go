package dto

import "slot_common/pkg/model/mysql_model"

type SlotUserInfo struct {
	User       *mysql_model.TblUser     //用户信息
	Merchant   *mysql_model.TblMerchant // 商户信息
	UserId     string                   // 用户id
	CurrencyId int64                    //货币信息
}
