package dto

type SlotJackpotResp struct {
	WinMode       int     //中奖类型
	WinAmount     float64 //中奖金额
	CurrencyId    int64   //货币信息
	JackpotNumber string  //奖池期数
	PoolInfo    []JackpotPoolValuesBody //奖池信息
}
