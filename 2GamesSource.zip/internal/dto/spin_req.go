package dto

type SpinReq struct {
	UserInfo   *SlotUserInfo //用户信息
	BetAmt     float64       // 投注金额
	Multiplier int           //投注倍数
	Fb         string        // 游戏模式
	Ab         string        //待定
	BpId       *int          //背包id（具体含义待定）
	Token      string
}
