package dto

import "slot_common/pkg/runtime"

// ---------------这些是从data-master中搬过来的---------------
type JackpotPoolLotteryResult struct {
	Status int                          `json:"s"`     // 是否中奖
	Result JackpotPoolLotteryResultBody `json:"r"`     // 中奖数据
	Pool   []JackpotPoolValuesBody      `json:"pools"` // 当前奖池数据
}

type JackpotPoolLotteryResultBody struct {
	DrawPoolNumber string  `json:"dp"` // 奖池期数
	DrawNumber     string  `json:"d"`  // 中奖流水号
	DrawName       string  `json:"p"`  // 中奖类型,即4个池名称
	MoneyUsd       float64 `json:"u"`  // 中奖金额，USD
	Money          float64 `json:"m"`  // 中奖金额，本币
}
type JackpotPoolValuesBody struct {
	DrawName string  `json:"p"`
	MoneyUsd float64 `json:"u"`
	Money    float64 `json:"m"`
}

type JackpotResult struct {
	Data  JackpotPoolLotteryResult `json:"dt"`  //返回值
	Error *runtime.SlotError       `json:"err"` //错误信息
}
