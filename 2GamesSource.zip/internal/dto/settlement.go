package dto

// Settlement 游戏结算对象
type Settlement struct {
	Spin            *SpinReq
	Mode            int     //游戏模式, 1: 正常摇奖 2: 免费模式 3: 奖励模式 4: 买免 5: 使用道具
	BetAmount       float64 //投注金额
	WinAmount       float64 //获胜金额
	ParentId        string  // 父订单id
	GameId          int     //游戏id
	GameName        string  // 游戏名称
	Balance         float64 //余额
	OriginBetAmount float64 //原始投注金额，买免时为1倍金额，使用道具时为道具价值
}

type SettlementResult struct {
	ParentId      string  //父历史订单id
	TransferId    string  //转账id
	HistoryId     string  //订单id
	BeforeBalance float64 //结算前余额
}
