package dto

type SlotGameInfoReq struct {
	Token string `form:"atk"`
}

type SlotSpinApiReq struct {
	Token      string  `json:"atk" form:"atk" validate:"required"`      //jwt验证token
	BetAmt     float64 `json:"cs" form:"cs" validate:"required,gt=0"`   // 投注额
	Multiplier int     `json:"ml" form:"ml"  validate:"required,gte=1"` //投注倍数
	Fb         string  `json:"fb" form:"fb"`                            //买免模式:"2" , 使用道具 "3"
	Ab         string  `json:"ab" form:"ab"`                            //TODO 意义暂不明确
	BpId       *int    `json:"bpId" form:"bpId"`                        //背包里的id
}
