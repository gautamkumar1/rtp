package web

import (
	"github.com/golang-jwt/jwt/v5"
	"go.uber.org/fx"
	"reflect"
	"slot_common/pkg/cache"
	"slot_common/pkg/constants"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/runtime"
	"slot_framework/pkg/utils"
	"slot_framework/pkg/web"
	"slot_mi_game/internal/dto"
)

type UserInfoArgumentResolverArgs struct {
	fx.In
	MerchantCache *cache.MerchantCache
	UserCache     *cache.UserCache
}

type UserInfoArgumentResolver struct {
	args      *UserInfoArgumentResolverArgs
	allowType reflect.Type
}

func NewUserInfoArgumentResolver(args UserInfoArgumentResolverArgs) web.ArgumentResolver {
	return &UserInfoArgumentResolver{
		args:      &args,
		allowType: reflect.TypeOf(&dto.SlotUserInfo{}),
	}
}

func (ar *UserInfoArgumentResolver) AllowType() reflect.Type {
	return ar.allowType
}

func (ar *UserInfoArgumentResolver) Resolve(ctx *web.ContextWrapper) reflect.Value {
	token := ctx.PostForm(constants.FormToken)
	if token == "" {
		panic(runtime.NewSlotError(ctx.Request.Context(), error_code.InvalidRequestErr))
	}
	sc := jwt.RegisteredClaims{}
	// 返回一个 token 结构体类型指针
	tokenModel, _ := jwt.ParseWithClaims(token, &sc, func(token *jwt.Token) (interface{}, error) {
		return []byte(constants.JWTKey), nil
	})
	if tokenModel == nil {
		panic(runtime.NewSlotError(ctx.Request.Context(), error_code.SystemErr))
	}
	// 此处是将JWT中的expireAt字段作为商户id （历史做法，有待商榷,更合理的定义是自定义拓展字段）
	merchantId := sc.ExpiresAt.Unix()
	merchant, mExists := ar.args.MerchantCache.GetMerchantById(ctx, int32(merchantId))
	//商户不存在或者状态不正常，不允许后续流程
	if !mExists || merchant == nil || merchant.State != constants.StateOk {
		panic(runtime.NewSlotError(ctx.Request.Context(), error_code.GameClosedErr))
	}

	userId := sc.ID
	userInfo, exists := ar.args.UserCache.GetUserById(ctx, userId)
	//用户不存在，或者状态不正常，不允许后续流程
	if !exists || userInfo == nil || int(utils.AsValue(userInfo.Status)) != constants.StateOk {
		panic(runtime.NewSlotError(ctx.Request.Context(), error_code.InvalidUserErr))
	}
	if utils.AsValue(userInfo.MerchantID) != int32(merchantId) {
		panic(runtime.NewSlotError(ctx.Request.Context(), error_code.InvalidMerchantErr))
	}
	// 此处是将JWT中的issueAt字段作为货币id （历史做法，有待商榷,更合理的定义是自定义拓展字段）
	currencyId := sc.IssuedAt.Unix()
	return reflect.ValueOf(&dto.SlotUserInfo{
		Merchant:   merchant,
		User:       userInfo,
		UserId:     userId,
		CurrencyId: currencyId,
	})
}
