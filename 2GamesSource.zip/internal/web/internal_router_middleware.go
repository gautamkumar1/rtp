package web

import (
	"github.com/gin-gonic/gin"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/runtime"
	"slot_framework/pkg/conf"
	"slot_framework/pkg/constants"
	"slot_framework/pkg/utils"
	"slot_framework/pkg/web"
)

type InternalMiddleware struct {
	internalUriList []string
}

func NewInternalMiddleware(cfg *conf.BaseConf) web.Middleware {
	return &InternalMiddleware{
		internalUriList: cfg.GetStringSlice("uri.internal.list", []string{}),
	}
}

func (m *InternalMiddleware) HandlerFunc(c *gin.Context) {
	ctx := c.Request.Context()
	uri := c.Request.RequestURI
	//如果是内部的URI，那么需要限制只有本地访问
	if utils.StringUtil.IsUriMatch(uri, m.internalUriList) {
		clientIp := ctx.Value(constants.RealClientIp).(string)
		if clientIp == "127.0.0.1" || clientIp == "localhost" || clientIp == "::1" {
			c.Next()
		} else {
			panic(runtime.NewSlotError(ctx, error_code.InvalidRequestErr))
		}
	}
	c.Next()
}

func (m *InternalMiddleware) Sort() int {
	return 1
}
