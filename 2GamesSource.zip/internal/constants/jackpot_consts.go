package _const

const (
	JP_GRAND = "GRAND"
	JP_MAJOR = "MAJOR"
	JP_MINOR = "MINOR"
	JP_MINI  = "MINI"
)
const (
	JP_GrandMode = 88 //Grand jackpot
	JP_MajorMode = 83 //Major jackpot
	JP_MinorMode = 82 //Minor jackpot
	JP_MiniMode  = 81 //Mini jackpot
)
const (
	MULTI_LIMIT         = 12_000 //最大赔付倍率
	MULTI_LIMIT_GEMKING = 20_000 //宝石王国限制20000倍最大赔付倍率
)
