package redis_key

import "fmt"

const (
	ProjectPrefix              = "slot_mi_"
	SpinUnique                 = ProjectPrefix + "spin_game_%s" //spin锁
	WildBreakerRewardWindows   = ProjectPrefix + "wild_breaker_reward_%s"
	LaiCaiMahjongRewardWindows = ProjectPrefix + "lc_mahjong_reward_%s"   //来财麻将摇奖记录
	ActiveUserSetIn10Secs      = ProjectPrefix + "active_user_set_10s_%s" //活跃用户集合,每10s的粒度， 用于统计玩家最近游戏历史，玩家总余额更新，
)

func GetKey(redisKey string, params ...any) string {
	return fmt.Sprintf(redisKey, params...)
}
