package cache_name

import "strconv"

const (
	engineCachePrefix = "engineCache_"
)

func GetEngineCacheName(gameId int) string {
	return engineCachePrefix + strconv.Itoa(gameId)
}
