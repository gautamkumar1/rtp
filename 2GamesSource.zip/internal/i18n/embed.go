package i18n

import (
	"embed"
)

//go:embed *.json
var I18nFiles embed.FS
