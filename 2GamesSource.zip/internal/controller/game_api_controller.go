package controller

import (
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/rsp"
	"slot_common/pkg/runtime"
	redis "slot_framework/pkg/data/redis/v9"
	"slot_framework/pkg/web"
	"slot_mi_game/internal/dto"
	"slot_mi_game/internal/games"

	"go.uber.org/fx"
)

type GameApiControllerArgs struct {
	fx.In
	Factory       *games.SlotGameHandlerFactory
	RedisTemplate *redis.RedisTemplate
}

type GameApiController struct {
	args *GameApiControllerArgs
}

func NewGameApiController(args GameApiControllerArgs) *GameApiController {
	return &GameApiController{
		args: &args,
	}
}

// GameInfo
// @description 获取游戏信息
// @tags GameApi
// @produce json
// @param traceId query string true "溯源id"
// @param game_name path string true "游戏名称"
// @param atk formData string true "JWT Token"
// @router /game-api/{game_name}/v2/GameInfo/Get [post]
// @success 200 {object} rsp.SlotGameResponse[any]
func (c *GameApiController) GameInfo(ctx *web.ContextWrapper, userInfo *dto.SlotUserInfo) *rsp.SlotGameResponse[any] {
	gameName := ctx.Param("game_name")
	handler := c.args.Factory.GetGameHandler(ctx.Request.Context(), gameName)

	gameId := handler.Id()
	if c.args.RedisTemplate.SetContains(ctx.Request.Context(), "slot_merchant_state", gameId) {
		panic(runtime.NewSlotError(ctx.Request.Context(), error_code.GameClosedErr))
	}
	return handler.GameInfo(ctx.Request.Context(), userInfo)
}

// DoSpin
// @description 获取游戏信息
// @tags GameApi
// @produce json
// @param traceId query string true "溯源id"
// @param game_name path string true "游戏名称"
// @param atk formData string true "JWT Token"
// @param cs formData string true "投注金额"
// @param ml formData int true "投注倍数"
// @param fb formData string false "待定"
// @param ab formData string false "待定"
// @param pbId formData int false "背包id"
// @router /game-api/{game_name}/v2/spin [post]
// @success 200 {object} rsp.SlotGameResponse[any]
func (c *GameApiController) DoSpin(ctx *web.ContextWrapper, req *dto.SlotSpinApiReq, userInfo *dto.SlotUserInfo) *rsp.SlotGameResponse[any] {
	gameName := ctx.Param("game_name")
	handler := c.args.Factory.GetGameHandler(ctx.Request.Context(), gameName) //通过gameName取得实例

	gameId := handler.Id()
	if c.args.RedisTemplate.SetContains(ctx.Request.Context(), "slot_merchant_state", gameId) {
		panic(runtime.NewSlotError(ctx.Request.Context(), error_code.GameClosedErr))
	}

	if c.args.RedisTemplate.SetContains(ctx.Request.Context(), "slot_user_block", userInfo.User.UserID) {
		panic(runtime.NewSlotError(ctx.Request.Context(), error_code.UserBlockErr))
	}
	return handler.Spin(ctx.Request.Context(), &dto.SpinReq{
		UserInfo:   userInfo,
		BetAmt:     req.BetAmt,
		Multiplier: req.Multiplier,
		Fb:         req.Fb,
		Ab:         req.Ab,
		BpId:       req.BpId,
		Token:      req.Token,
	})
}

// Spin
// @description 获取游戏信息
// @tags GameApi
// @produce json
// @param traceId query string true "溯源id"
// @param game_name path string true "游戏名称"
// @param atk formData string true "JWT Token"
// @param cs formData string true "投注金额"
// @param ml formData int true "投注倍数"
// @param fb formData string false "是否买免，1为正常，2为购买免费"
// @param ab formData string false "待定"
// @param pbId formData int false "背包id"
// @router /game-api/{game_name}/v2/Spin [post]
// @success 200 {object} rsp.SlotGameResponse[any]
func (c *GameApiController) Spin(ctx *web.ContextWrapper, req *dto.SlotSpinApiReq, userInfo *dto.SlotUserInfo) *rsp.SlotGameResponse[any] {
	return c.DoSpin(ctx, req, userInfo)
}
