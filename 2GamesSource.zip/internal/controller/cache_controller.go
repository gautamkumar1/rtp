package controller

import (
	"go.uber.org/fx"
	"slot_common/pkg/constants/error_code"
	"slot_common/pkg/dto"
	"slot_common/pkg/rsp"
	"slot_common/pkg/runtime"
	"slot_framework/pkg/cache"
	"slot_framework/pkg/web"
)

type CacheControllerArgs struct {
	fx.In
	FwCacheEmitter       *cache.Emitter
	FwCacheHandleFactory *cache.HandleFactory
}

type CacheController struct {
	args *CacheControllerArgs
}

func NewCacheController(args CacheControllerArgs) *CacheController {
	return &CacheController{
		args: &args,
	}
}

// DoRefresh
// @description 缓存刷新
// @tags CacheApi
// @produce json
// @param traceId query string true "溯源id"
// @param vo body dto.CacheRefreshSO true "缓存刷新参数"
// @router /api/cache/refresh [post]
// @success 200 {object} rsp.SlotGameResponse[string]
func (c *CacheController) DoRefresh(_ *web.ContextWrapper, vo *dto.CacheRefreshSO) *rsp.SlotGameResponse[string] {
	if len(vo.RefreshKeys) > 0 {
		c.args.FwCacheEmitter.NotifyMulti(vo.CacheName, vo.RefreshKeys)
	} else {
		c.args.FwCacheEmitter.NotifyAll(vo.CacheName)
	}
	return rsp.NewResponse("success")
}

// CacheList
// @description 获取缓存列表
// @tags CacheApi
// @produce json
// @param traceId query string true "溯源id"
// @router /api/cache/list [get]
// @success 200 {object} rsp.SlotGameResponse[[]string]
func (c *CacheController) CacheList(_ *web.ContextWrapper) *rsp.SlotGameResponse[[]string] {
	return rsp.NewResponse(c.args.FwCacheHandleFactory.GetCacheNameList())
}

// GetCacheInfo
// @description 获取缓存值
// @tags CacheApi
// @produce json
// @param traceId query string true "溯源id"
// @param vo body dto.CacheQuery true "缓存查询参数"
// @router /api/cache/value [post]
// @success 200 {object} rsp.SlotGameResponse[any]
func (c *CacheController) GetCacheInfo(wrapper *web.ContextWrapper, vo *dto.CacheQuery) *rsp.SlotGameResponse[any] {
	cacheValue, err := c.args.FwCacheHandleFactory.GetValue(wrapper.Request.Context(), vo.CacheName, vo.CacheKey)
	if err != nil {
		return rsp.NewErrorResponse(runtime.NewSlotError(wrapper.Request.Context(), error_code.SystemErr))
	}
	return rsp.NewResponse(cacheValue)
}
