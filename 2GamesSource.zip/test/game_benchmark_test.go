package test

import (
	"fmt"
	"slot_mi_core/pkg"
	"slot_mi_core/slots/mahjong"
	"slot_mi_core/slots/moneyrabbit"
	"testing"
)

func BenchmarkWildBreaker(b *testing.B) {
	game := moneyrabbit.NewMoneyRabbitGame()
	for n := 0; n < b.N; n++ {
		wildBreaker(game)
	}
}

func BenchmarkLaicaiMahjong(b *testing.B) {
	game := mahjong.NewMahjongGame()
	for n := 0; n < b.N; n++ {
		laicaiMahjong(game)
	}
}

func wildBreaker(g *moneyrabbit.MoneyRabbitGame) {
	rewardFreeGameCount := 8
	freeGameReel, _ := g.GetReels(pkg.FreeGameMode, pkg.MediumRtpLevel, pkg.MediumVolatility)
	betIn := moneyrabbit.MoneyRabbitBetIn{
		BetAmt:   40,
		Reels:    freeGameReel,
		GameMode: pkg.BuyFreeGameMode,
	}

	rewardOuts := make([]*moneyrabbit.MoneyRabbitBetOut, 0)
	out, err := g.GetMoneyRabbitRewardByMode(&betIn)
	if err != nil {
		fmt.Println(err)
	}
	rewardOuts = append(rewardOuts, out)
	//如果是免费模式，额外转7次
	if betIn.GameMode == pkg.FreeGameMode || betIn.GameMode == pkg.BuyFreeGameMode {
		for i := 0; i < rewardFreeGameCount-1; i++ {
			freeGameOut, freeGameErr := g.GetMoneyRabbitRewardByMode(&betIn)
			if freeGameErr != nil {
				fmt.Println(freeGameErr)
			}
			rewardOuts = append(rewardOuts, freeGameOut)
		}
	}
}
func laicaiMahjong(g *mahjong.MahjongGame) {
	freeGameReel, _ := g.GetReels(pkg.FreeGameMode, pkg.MediumRtpLevel, pkg.MediumVolatility)
	betIn := mahjong.MahjongBetIn{
		BetAmt:                      40,
		Reels:                       freeGameReel,
		GameMode:                    pkg.BuyFreeGameMode,
		IsTheSpinToEnterBuyFreeGame: 1,
	}
	rewardOut, err := g.GetMahjongRewardByMode(&betIn)
	if err != nil {
		fmt.Println(err)
	}
	//总免费游戏次数
	totalCountOfFreeGame := rewardOut.NumberOfTriggeredFreeGames
	//剩余免费游戏次数
	countOfFreeGameLeft := rewardOut.NumberOfTriggeredFreeGames
	freeGameMode := pkg.FreeGameMode
	if betIn.GameMode == pkg.BuyFreeGameMode {
		freeGameMode = pkg.BuyFreeGameMode
	}
	for countOfFreeGameLeft > 0 {
		countOfFreeGameLeft--
		freeGameBetIn := &mahjong.MahjongBetIn{
			BetAmt:                      betIn.BetAmt,
			GameMode:                    freeGameMode,
			Reels:                       freeGameReel,
			IsTheSpinToEnterBuyFreeGame: 0,
		}
		freeGameRewardOut, freeGameErr := g.GetMahjongRewardByMode(freeGameBetIn)
		if freeGameErr != nil {
			fmt.Println(freeGameErr)
		}
		//免费游戏过程中再次获得免费次数
		countOfFreeGameLeft += freeGameRewardOut.NumberOfTriggeredFreeGames
		totalCountOfFreeGame += freeGameRewardOut.NumberOfTriggeredFreeGames
		//防止测试时错误的数据导致无法退出免费游戏
		if totalCountOfFreeGame > 30 {
			fmt.Println("too many free-games of mahjong")
		}
	}
}
