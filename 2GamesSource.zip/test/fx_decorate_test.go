package test

import (
	"context"
	"fmt"
	"go.uber.org/fx"
	"testing"
	"time"
)

func TestDecorate(t *testing.T) {
	fxOptions := make([]fx.Option, 0)
	fxOptions = append(fxOptions, fx.NopLogger)
	fxOptions = append(fxOptions, register(NewApple))
	fxOptions = append(fxOptions, fx.Provide(NewSellService))
	fxOptions = append(fxOptions, fx.Invoke(func(s *SellService) {
		s.Sell()
	}))
	fxOptions = append(fxOptions, fx.Decorate(func(fruit Fruit) Fruit {
		fmt.Println("default fruit: " + fruit.name())
		return NewOrange()
	}))
	app := fx.New(fxOptions...)
	go func() {
		app.Run()
	}()

	time.Sleep(1 * time.Second)
	if err := app.Stop(context.Background()); err != nil {
		fmt.Println("error stopping")
	}
}

func register(constructor any) fx.Option {
	return fx.Provide(fx.Annotate(constructor, fx.As(new(Fruit))))
}

type SellService struct {
	fruit Fruit
}

func NewSellService(fruit Fruit) *SellService {
	return &SellService{
		fruit: fruit,
	}
}

func (s *SellService) Sell() {
	fmt.Println("sell " + s.fruit.name())
}

type Fruit interface {
	name() string
}

type Apple struct {
}

func (a *Apple) name() string {
	return "apple"
}

func NewApple() *Apple {
	return &Apple{}
}

type Orange struct {
}

func (o *Orange) name() string {
	return "orange"
}

func NewOrange() *Orange {
	return &Orange{}
}
