INSERT INTO `slot_mi`.`tbl_game_bet` (`id`, `currency`, `bet_size_1`, `bet_size_2`, `bet_size_3`, `bet_size_4`, `kind_id`, `default_size`) VALUES (0, 1, 1.00, 20.00, 80.00, 200.00, 10, 1.00);
INSERT INTO `slot_mi`.`tbl_game_bet` (`id`, `currency`, `bet_size_1`, `bet_size_2`, `bet_size_3`, `bet_size_4`, `kind_id`, `default_size`) VALUES (0, 2, 0.20, 2.00, 6.00, 20.00, 10, 0.20);
INSERT INTO `slot_mi`.`tbl_game_bet` (`id`, `currency`, `bet_size_1`, `bet_size_2`, `bet_size_3`, `bet_size_4`, `kind_id`, `default_size`) VALUES (0, 3, 0.20, 2.00, 6.00, 20.00, 10, 0.20);
INSERT INTO `slot_mi`.`tbl_game_bet` (`id`, `currency`, `bet_size_1`, `bet_size_2`, `bet_size_3`, `bet_size_4`, `kind_id`, `default_size`) VALUES (0, 4, 0.20, 2.00, 6.00, 20.00, 10, 0.20);
INSERT INTO `slot_mi`.`tbl_game_bet` (`id`, `currency`, `bet_size_1`, `bet_size_2`, `bet_size_3`, `bet_size_4`, `kind_id`, `default_size`) VALUES (0, 5, 0.20, 2.00, 6.00, 20.00, 10, 0.20);
INSERT INTO `slot_mi`.`tbl_game_bet` (`id`, `currency`, `bet_size_1`, `bet_size_2`, `bet_size_3`, `bet_size_4`, `kind_id`, `default_size`) VALUES (0, 6, 0.20, 2.00, 6.00, 20.00, 10, 0.20);
INSERT INTO `slot_mi`.`tbl_game_bet` (`id`, `currency`, `bet_size_1`, `bet_size_2`, `bet_size_3`, `bet_size_4`, `kind_id`, `default_size`) VALUES (0, 7, 0.20, 2.00, 6.00, 20.00, 10, 0.20);
INSERT INTO `slot_mi`.`tbl_game_bet` (`id`, `currency`, `bet_size_1`, `bet_size_2`, `bet_size_3`, `bet_size_4`, `kind_id`, `default_size`) VALUES (0, 8, 500.00, 2000.00, 10000.00, 50000.00, 10, 500.00);
