/**
在添加之前，
1. tbl_props 表查看这个游戏的道具信息；
2. （在游戏端）看当前玩家的user_id是多少
*/
/*
SELECT * from tbl_props where game_id=1 and currency_id = 1;
*/
-- 声明并设置变量
SET @user_id = '1992774653143711744';
SET @props_id = 399;  -- 只需要指定道具ID

/*-----------------------------------*/
SET @created_at = UNIX_TIMESTAMP(NOW());
SET @update_at = UNIX_TIMESTAMP(NOW());
SET @expired_at = UNIX_TIMESTAMP(DATE_ADD(NOW(), INTERVAL 7 DAY));
SET @is_new = 1;

-- 执行插入语句（从 tbl_props 表查询道具信息）
INSERT INTO `slot_mi`.`tbl_user_package` (
    `user_id`, 
    `props_id`, 
    `props_name`, 
    `props_icon`, 
    `props_type`, 
    `props_level`, 
    `bet_amount`, 
    `props_desc`, 
    `created_at`, 
    `update_at`, 
    `currency_id`, 
    `expired_at`, 
    `state`, 
    `game_id`, 
    `is_new`
)
SELECT 
    @user_id,
    @props_id,
    p.props_name,
    p.props_icon,
    p.props_type,
    p.props_level,
    p.bet_amount,
    p.props_desc,
    @created_at,
    @update_at,
    p.currency_id,
    @expired_at,
    1,
    p.game_id,
    @is_new
FROM `slot_mi`.`tbl_props` p
WHERE p.id = @props_id;

-- 获取刚插入的自增ID
SET @package_id = LAST_INSERT_ID();

/**领取记录***/
-- 声明并设置变量
SET @record_type = 1;
SET @channel = 0;
SET @num = 1;

-- 执行插入语句（从 tbl_props 表查询道具信息）
INSERT INTO `slot_mi`.`package_record` (
    `package_id`,
    `props_id`,
    `user_id`,
    `props_name`,
    `props_level`,
    `record_type`,
                `bet_amount`,
    `create_at`,
    `expired_at`,
    `props_desc`,
    `channel`,
    `num`,
    `game_id`
)
SELECT 
    @package_id,
    @props_id,
    @user_id,
    p.props_name,
    p.props_level,
    @record_type,
    p.bet_amount,
    @created_at,
    @expired_at,
    p.props_desc,
    @channel,
    @num,
    p.game_id
FROM `slot_mi`.`tbl_props` p
WHERE p.id = @props_id;