package configs

import _ "embed"

//go:embed application.yaml
var ConfigFile []byte
