//go:build prd

package configs

import _ "embed"

//go:embed application-prd.yaml
var ActiveConfigFile []byte

var Profile = "prd"
