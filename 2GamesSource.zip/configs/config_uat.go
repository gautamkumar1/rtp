//go:build uat

package configs

import _ "embed"

//go:embed application-uat.yaml
var ActiveConfigFile []byte

var Profile = "uat"
