//go:build local

package configs

import _ "embed"

//go:embed application-local.yaml
var ActiveConfigFile []byte

var Profile = "local"
