//go:build !prd && !uat && !local

package configs

import _ "embed"

//go:embed application-dev.yaml
var ActiveConfigFile []byte

var Profile = "dev"
