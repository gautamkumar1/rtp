find . \( -name ".vscode"  -o -name ".git" -o -name "build" -o -name "cfg" \) -prune -o -type f ! \( -name ".DS_Store" -o -name ".gitignore" -o -name "*.json" -o -name "*.sh" -o -name "*.md" -o -name "*.csv" \) -print | sort | xargs shasum -a 256 | tee ./build/hash_src.csv

cp ./cfg/config*.json build
find ./build \( -name ".vscode" \) -prune -o -type f ! \( -name ".DS_Store" -o -name ".gitignore" -o -name "*.csv" \) -print | sort | xargs shasum -a 256 | tee ./build/hash_bin.csv
