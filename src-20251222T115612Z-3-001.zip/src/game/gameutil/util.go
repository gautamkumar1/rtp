package gameutil

import (
	"github.com/idtksrv/simulator-server/internal/configuration"
	"github.com/idtksrv/simulator-server/internal/util/rand"
)

func SymbolIDInSlice(symbolID int, IDSlice []int) bool {
	for i, _ := range IDSlice {
		if symbolID == IDSlice[i] {
			return true
		}
	}
	return false
}

func DecideReRun(targetRTP string, reRunTimes int, payout, betCredit float64, lowerBound, upperBound int, reSpinData map[string]float64) bool {

	//no rerun
	if targetRTP == configuration.RTPDefault {
		return false
	}

	//rerun once only
	if reRunTimes < 1 {
		lb := lowerBound
		//超過要reRun倍數
		if (payout / betCredit) >= float64(lb) {
			if rtp, ok := reSpinData[targetRTP]; ok {
				if rand.Float64() < rtp {
					return true
				}
			}
		}
	}
	return false
}
