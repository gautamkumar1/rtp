package cascade

import (
	"fmt"
	"reflect"
	"testing"

	"github.com/idtksrv/simulator-server/game/core"
	"github.com/idtksrv/simulator-server/internal/util/slot"
)

var (
	setting2900 = &core.BaseSetting{

		ColumnAndLine:    []int{6, 6},
		ColumnAndLineMax: []int{6, 6},
		Symbol: &core.BaseSymbol{
			WildID:    []int{-1},
			ScatterID: []int{10},
			SymbolID:  []int{1, 2, 3, 4, 5, 6, 7, 8, 9},
		},
		GetPrizeSymbolMinNumPerLine: 9,
		Reel:                        [][]int{{-1}},
		PayLine:                     [][]int{{0, 0, 0}},
		PayTable: []*core.BasePayTable{
			{
				SymbolID: 1,
				PayRate:  []float64{0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 5, 5, 7.5, 7.5, 12.5, 12.5, 15},
			},
			{
				SymbolID: 2,
				PayRate:  []float64{0, 0, 0, 0, 0, 0, 0, 0, 0, 1.5, 1.5, 2.5, 2.5, 3, 3, 4, 4, 5},
			},
			{
				SymbolID: 3,
				PayRate:  []float64{0, 0, 0, 0, 0, 0, 0, 0, 0, 1.25, 1.25, 2, 2, 2.5, 2.5, 3.5, 3.5, 4},
			},
			{
				SymbolID: 4,
				PayRate:  []float64{0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1.5, 1.5, 2.25, 2.25, 3, 3, 3.75},
			},
			{
				SymbolID: 5,
				PayRate:  []float64{0, 0, 0, 0, 0, 0, 0, 0, 0, 0.6, 0.6, 1, 1, 1.25, 1.25, 2, 2, 2.5},
			},
			{
				SymbolID: 6,
				PayRate:  []float64{0, 0, 0, 0, 0, 0, 0, 0, 0, 0.6, 0.6, 1, 1, 1.25, 1.25, 2, 2, 2.5},
			},
			{
				SymbolID: 7,
				PayRate:  []float64{0, 0, 0, 0, 0, 0, 0, 0, 0, 0.4, 0.4, 0.6, 0.6, 1, 1, 1.25, 1.25, 1.75},
			},
			{
				SymbolID: 8,
				PayRate:  []float64{0, 0, 0, 0, 0, 0, 0, 0, 0, 0.25, 0.25, 0.4, 0.4, 0.6, 0.6, 0.9, 0.9, 1.25},
			},
			{
				SymbolID: 9,
				PayRate:  []float64{0, 0, 0, 0, 0, 0, 0, 0, 0, 0.1, 0.1, 0.25, 0.25, 0.5, 0.5, 0, 0.75, 0.75, 1},
			},
			{
				SymbolID: 10,
				PayRate:  []float64{0, 0, 0, 1, 3, 10, 50, 50},
			},
		},
	}

	baseReel2900 = [][]int{
		{7, 6, 6, 2, 2, 2, 6, 6, 4, 4, 4, 5, 5, 1, 1, 8, 8, 7, 9, 8, 8, 9, 3, 3, 8, 8, 10, 9, 9, 4, 4, 5, 5, 3, 3, 8, 8, 4, 9, 9, 4, 9, 3, 3, 8, 8, 2, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
		{7, 6, 6, 2, 2, 2, 6, 6, 4, 4, 4, 5, 5, 1, 1, 8, 8, 7, 9, 8, 8, 9, 3, 3, 8, 8, 10, 9, 9, 4, 4, 5, 5, 3, 3, 8, 8, 4, 9, 9, 4, 9, 3, 3, 8, 2, 2, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
		{7, 6, 6, 2, 2, 2, 7, 8, 8, 4, 4, 5, 5, 1, 1, 8, 8, 2, 2, 8, 8, 9, 3, 3, 8, 8, 10, 9, 9, 9, 9, 4, 4, 3, 3, 8, 8, 4, 9, 9, 4, 9, 3, 3, 8, 7, 7, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
		{7, 6, 6, 2, 2, 2, 7, 8, 8, 4, 4, 5, 5, 1, 1, 8, 8, 2, 2, 8, 8, 9, 3, 3, 8, 8, 10, 7, 9, 9, 9, 4, 4, 3, 3, 8, 8, 2, 2, 9, 9, 7, 7, 9, 9, 7, 2, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
		{7, 6, 6, 2, 2, 2, 7, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 7, 9, 8, 8, 9, 3, 3, 8, 8, 10, 7, 9, 4, 4, 5, 5, 3, 3, 9, 9, 9, 9, 9, 9, 7, 7, 9, 9, 7, 2, 5, 3, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
		{7, 6, 6, 2, 2, 2, 7, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 2, 2, 8, 8, 9, 3, 3, 8, 8, 10, 7, 9, 4, 4, 5, 5, 3, 3, 9, 9, 9, 9, 9, 9, 7, 7, 9, 9, 6, 2, 5, 3, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
	}
	respinReel2900 = [][]int{
		{7, 6, 6, 2, 2, 5, 6, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 5, 6, 7, 9, 5, 1, 2, 3, 4, 5, 6, 7, 9, 1, 3},
		{7, 6, 6, 2, 2, 5, 6, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 5, 6, 7, 9, 5, 1, 2, 3, 4, 5, 6, 7, 9, 1, 1},
		{7, 6, 6, 2, 2, 5, 6, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 5, 6, 7, 9, 5, 1, 2, 3, 4, 5, 6, 7, 9, 1, 1},
		{7, 6, 6, 2, 2, 5, 5, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 5, 6, 7, 9, 5, 1, 2, 3, 4, 5, 6, 7, 9, 9, 7},
		{7, 6, 6, 2, 2, 5, 5, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 5, 6, 7, 9, 5, 1, 2, 3, 4, 5, 6, 7, 9, 9},
		{7, 6, 6, 2, 2, 5, 5, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 5, 6, 7, 9, 5, 1, 2, 3, 4, 5, 6, 7, 9, 9},
	}

	freeSpinBaseReelWeightTable2900 = []int{3345, 10000}

	freeSpinBaseReel2900 = [][][]int{
		{{7, 6, 6, 2, 2, 2, 6, 6, 4, 4, 4, 5, 5, 1, 1, 8, 8, 7, 9, 8, 8, 9, 3, 3, 8, 8, 10, 9, 9, 4, 4, 5, 5, 3, 3, 8, 8, 4, 9, 9, 4, 9, 3, 3, 8, 10, 5, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
			{7, 6, 6, 2, 2, 2, 6, 6, 4, 4, 4, 5, 5, 1, 1, 8, 8, 7, 9, 8, 8, 9, 3, 3, 8, 8, 10, 9, 9, 4, 4, 5, 5, 3, 3, 8, 8, 4, 9, 9, 4, 9, 3, 3, 8, 7, 7, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
			{7, 6, 6, 2, 2, 2, 7, 8, 8, 4, 4, 5, 5, 1, 1, 8, 8, 2, 2, 8, 8, 9, 3, 3, 8, 8, 10, 9, 9, 9, 9, 4, 4, 3, 3, 8, 8, 4, 9, 9, 4, 9, 3, 3, 8, 7, 7, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
			{7, 6, 6, 2, 2, 2, 7, 8, 8, 4, 4, 5, 5, 1, 1, 8, 8, 2, 2, 8, 8, 9, 3, 3, 8, 8, 10, 7, 9, 9, 9, 4, 4, 3, 3, 8, 8, 2, 2, 9, 9, 7, 7, 9, 9, 7, 7, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
			{7, 6, 6, 2, 2, 2, 7, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 7, 9, 8, 8, 9, 3, 3, 8, 8, 10, 7, 9, 4, 4, 5, 5, 3, 3, 9, 9, 9, 9, 9, 9, 7, 7, 9, 9, 7, 7, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 6},
			{7, 6, 6, 2, 2, 2, 7, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 2, 2, 8, 8, 9, 3, 3, 8, 8, 10, 7, 9, 4, 4, 5, 5, 3, 3, 9, 9, 9, 9, 9, 9, 7, 7, 9, 9, 7, 7, 5, 4, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 5, 6}},

		{{7, 6, 6, 2, 2, 2, 6, 6, 4, 4, 4, 5, 5, 1, 1, 8, 8, 7, 9, 8, 8, 9, 3, 3, 8, 8, 10, 9, 9, 4, 4, 5, 5, 3, 3, 8, 8, 4, 9, 9, 4, 9, 3, 3, 8, 10, 5, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
			{7, 6, 6, 2, 2, 2, 6, 6, 4, 4, 4, 5, 5, 1, 1, 8, 8, 7, 9, 8, 8, 9, 3, 3, 8, 8, 10, 9, 9, 4, 4, 5, 5, 3, 3, 8, 8, 4, 9, 9, 4, 9, 3, 3, 8, 7, 7, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
			{7, 6, 6, 2, 2, 2, 7, 8, 8, 4, 4, 5, 5, 1, 1, 8, 8, 2, 2, 8, 8, 9, 3, 3, 8, 8, 10, 9, 9, 9, 9, 4, 4, 3, 3, 8, 8, 4, 9, 9, 4, 9, 3, 3, 8, 7, 7, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
			{7, 6, 6, 2, 2, 2, 7, 8, 8, 4, 4, 5, 5, 1, 1, 8, 8, 2, 2, 8, 8, 9, 3, 3, 8, 8, 10, 7, 9, 9, 9, 4, 4, 3, 3, 8, 8, 2, 2, 9, 9, 7, 7, 9, 9, 7, 7, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 7},
			{7, 6, 6, 2, 2, 2, 7, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 7, 9, 8, 8, 9, 3, 3, 8, 8, 10, 7, 9, 4, 4, 5, 5, 3, 3, 9, 9, 9, 9, 9, 9, 7, 7, 9, 9, 7, 7, 5, 5, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 6, 6},
			{7, 6, 6, 2, 2, 2, 7, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 2, 2, 8, 8, 9, 3, 3, 8, 8, 10, 7, 9, 4, 4, 5, 5, 3, 3, 9, 9, 9, 9, 9, 9, 7, 7, 9, 9, 7, 7, 5, 1, 7, 7, 4, 4, 8, 8, 1, 1, 2, 3, 4, 5, 5, 6}},
	}
	freeSpinRespinReel2900 = [][]int{
		{7, 6, 6, 2, 2, 5, 6, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 1, 1, 2, 2, 5, 5, 6, 6, 8, 8, 8, 9, 9, 1, 3},
		{7, 6, 6, 2, 2, 5, 6, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 1, 1, 2, 2, 5, 5, 6, 6, 8, 8, 8, 9, 9, 1, 1},
		{7, 6, 6, 2, 2, 5, 6, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 1, 1, 1, 5, 5, 5, 6, 6, 8, 8, 8, 9, 9, 1, 1},
		{7, 6, 6, 2, 2, 5, 5, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 1, 1, 1, 5, 5, 6, 6, 6, 7, 7, 7, 9, 9, 9, 7},
		{7, 6, 6, 2, 2, 5, 5, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 1, 1, 1, 1, 5, 5, 6, 6, 8, 7, 7, 9, 9, 9},
		{7, 6, 6, 2, 2, 5, 5, 6, 6, 4, 4, 5, 5, 1, 1, 8, 8, 9, 9, 7, 7, 7, 3, 3, 8, 8, 8, 1, 1, 1, 1, 5, 5, 6, 6, 8, 7, 7, 9, 9, 9},
	}
)

func TestBase_markCascadingSymbol(t *testing.T) {
	base := &Cascade{}

	type args struct {
		resultReel                  [][]int
		allSymbolInfo               []*core.BaseSymbolInfo
		getPrizeSymbolMinNumPerLine int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{
				[][]int{
					{1, 2, 3, 4, 6, 6},
					{1, 2, 3, 4, 6, 6},
					{1, 2, 3, 4, 6, 6},
					{1, 2, 3, 4, 6, 6},
					{1, 2, 3, 4, 6, 6},
					{1, 2, 3, 4, 6, 6},
				},
				[]*core.BaseSymbolInfo{
					{
						[]int{6},
						[][]int{
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
						},
						12,
						0, 0, 0,
					},
				},
				9,
			},
			[][]int{
				{1, 2, 3, 4, -1, -1},
				{1, 2, 3, 4, -1, -1},
				{1, 2, 3, 4, -1, -1},
				{1, 2, 3, 4, -1, -1},
				{1, 2, 3, 4, -1, -1},
				{1, 2, 3, 4, -1, -1},
			},
		},
		{
			"1",
			args{
				[][]int{
					{1, 2, 4, 4, 6, 6},
					{1, 2, 4, 4, 6, 6},
					{1, 2, 4, 4, 6, 6},
					{1, 2, 4, 4, 6, 6},
					{1, 2, 4, 4, 6, 6},
					{1, 2, 4, 4, 6, 6},
				},
				[]*core.BaseSymbolInfo{
					{
						[]int{6},
						[][]int{
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
							{-1, -1, -1, -1, 1, 1},
						},
						12,
						0, 0, 0,
					},
					{
						[]int{4},
						[][]int{
							{-1, -1, 1, 1, -1, -1},
							{-1, -1, 1, 1, -1, -1},
							{-1, -1, 1, 1, -1, -1},
							{-1, -1, 1, 1, -1, -1},
							{-1, -1, 1, 1, -1, -1},
							{-1, -1, 1, 1, -1, -1},
						},
						12,
						0, 0, 0,
					},
				},
				9,
			},
			[][]int{
				{1, 2, -1, -1, -1, -1},
				{1, 2, -1, -1, -1, -1},
				{1, 2, -1, -1, -1, -1},
				{1, 2, -1, -1, -1, -1},
				{1, 2, -1, -1, -1, -1},
				{1, 2, -1, -1, -1, -1},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := base.MarkCascadingSymbol(tt.args.resultReel, tt.args.allSymbolInfo, tt.args.getPrizeSymbolMinNumPerLine); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("markCascadingSymbol() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestBase_arrangeReel(t *testing.T) {
	base := &Cascade{}

	type args struct {
		markedReel [][]int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{
				[][]int{
					{1, -1, 1, 1, -1, -1},
					{1, -1, 1, 1, -1, -1},
					{1, -1, 1, 1, -1, -1},
					{1, -1, 1, 1, -1, -1},
					{1, -1, 1, 1, -1, -1},
					{1, -1, 1, 1, -1, -1},
				},
			},
			[][]int{
				{-1, -1, -1, 1, 1, 1},
				{-1, -1, -1, 1, 1, 1},
				{-1, -1, -1, 1, 1, 1},
				{-1, -1, -1, 1, 1, 1},
				{-1, -1, -1, 1, 1, 1},
				{-1, -1, -1, 1, 1, 1},
			},
		},
		{
			"1",
			args{
				[][]int{
					{1, -1, 1, 1, -1, -1},
					{2, -1, 1, 1, 2, -1},
					{2, -1, 1, 1, -1, 2},
					{1, -1, 9, 8, -1, 8},
					{1, -1, 1, 1, -1, -1},
					{1, -1, 1, 1, -1, -1},
				},
			},
			[][]int{
				{-1, -1, -1, 1, 1, 1},
				{-1, -1, 2, 1, 1, 2},
				{-1, -1, 2, 1, 1, 2},
				{-1, -1, 1, 9, 8, 8},
				{-1, -1, -1, 1, 1, 1},
				{-1, -1, -1, 1, 1, 1},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			if got := base.DownSymbol(tt.args.markedReel, -1); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("arrangeReel() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestBase_getCascadingResult(t *testing.T) {
	base := &Cascade{}

	type args struct {
		setting       *core.BaseSetting
		allSymbolInfo []*core.BaseSymbolInfo
		oldResultReel [][]int
		respinResult  [][]int
		multiplier    int
		betCredit     float64
	}
	tests := []struct {
		name             string
		args             args
		wantRetResult    *Cascading
		wantRetPayCredit float64
		wantErr          bool
	}{
		{
			"0",
			args{
				setting2900,
				[]*core.BaseSymbolInfo{
					{
						[]int{1},
						[][]int{{1, 1, 1, -1, -1, -1}, {1, 1, 1, -1, -1, -1}, {1, 1, 1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1}},
						9,
						0, 0, 0,
					},
				},
				[][]int{
					{1, 1, 1, 2, 3, 4},
					{1, 1, 1, 2, 3, 4},
					{1, 1, 1, 2, 3, 4},
					{5, 6, 7, 8, 9, 9},
					{5, 6, 7, 8, 9, 9},
					{5, 6, 7, 8, 9, 9},
				},
				[][]int{
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
				},
				1,
				1000,
			},
			&Cascading{
				1,
				[]*flow{},
				[][]int{
					{1, 2, 3},
					{1, 2, 3},
					{1, 2, 3},
					{},
					{},
					{},
				},
				[][]int{
					{1, 2, 3, 2, 3, 4},
					{1, 2, 3, 2, 3, 4},
					{1, 2, 3, 2, 3, 4},
					{5, 6, 7, 8, 9, 9},
					{5, 6, 7, 8, 9, 9},
					{5, 6, 7, 8, 9, 9},
				},
			},
			60,
			false,
		},
		{
			"1",
			args{
				setting2900,
				[]*core.BaseSymbolInfo{
					{
						[]int{1},
						[][]int{{1, 1, 1, -1, -1, -1}, {1, 1, 1, -1, -1, -1}, {1, 1, 1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1}},
						9,
						0, 0, 0,
					},
					{
						[]int{2},
						[][]int{{-1, -1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1, -1}, {1, 1, 1, -1, -1, -1}, {1, 1, 1, -1, -1, -1}, {1, 1, 1, -1, -1, -1}},
						9,
						0, 0, 0,
					},
				},
				[][]int{
					{1, 1, 1, 2, 3, 4},
					{1, 1, 1, 2, 3, 4},
					{1, 1, 1, 2, 3, 4},
					{2, 2, 2, 8, 9, 9},
					{2, 2, 2, 8, 9, 9},
					{2, 2, 2, 8, 9, 9},
				},
				[][]int{
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
				},
				1,
				1000,
			},
			&Cascading{
				1,
				[]*flow{},
				[][]int{
					{1, 2, 3},
					{1, 2, 3},
					{1, 2, 3},
					{1, 2, 3},
					{1, 2, 3},
					{1, 2, 3},
				},
				[][]int{
					{1, 2, 3, 2, 3, 4},
					{1, 2, 3, 2, 3, 4},
					{1, 2, 3, 2, 3, 4},
					{1, 2, 3, 8, 9, 9},
					{1, 2, 3, 8, 9, 9},
					{1, 2, 3, 8, 9, 9},
				},
			},
			90,
			false,
		},
		{
			"2",
			args{
				setting2900,
				[]*core.BaseSymbolInfo{
					{
						[]int{1},
						[][]int{
							{-1, -1, -1, -1, -1, -1},
							{-1, -1, -1, -1, -1, -1},
							{-1, -1, -1, -1, -1, -1},
							{-1, -1, 1, 1, 1, 1},
							{-1, -1, 1, 1, 1, -1},
							{-1, -1, 1, 1, 1, -1}},
						9,
						0, 0, 0,
					},
				},
				[][]int{
					{2, 3, 4, 5, 6, 7},
					{2, 3, 4, 5, 6, 7},
					{2, 3, 4, 5, 6, 7},
					{2, 3, 1, 1, 1, 1},
					{2, 3, 1, 1, 1, 7},
					{2, 3, 1, 1, 1, 7}, //會先往移動
				},
				[][]int{
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
				},
				2,
				1000,
			},
			&Cascading{
				2,
				[]*flow{},
				[][]int{
					{},
					{},
					{},
					{1, 2, 3, 4},
					{1, 2, 3},
					{1, 2, 3},
				},
				[][]int{
					{2, 3, 4, 5, 6, 7},
					{2, 3, 4, 5, 6, 7},
					{2, 3, 4, 5, 6, 7},
					{1, 2, 3, 4, 2, 3},
					{1, 2, 3, 2, 3, 7},
					{1, 2, 3, 2, 3, 7}, //會先往移動
				},
			},
			120,
			false,
		},
		{
			"3",
			args{
				setting2900,
				[]*core.BaseSymbolInfo{
					{
						[]int{1},
						[][]int{
							{1, 1, 1, 1, 1, 1},
							{1, 1, 1, 1, 1, 1},
							{1, 1, 1, 1, 1, 1},
							{1, 1, 1, 1, 1, 1},
							{1, 1, 1, 1, 1, 1},
							{1, 1, 1, 1, 1, 1},
						},
						36,
						0, 0, 0,
					},
				},
				[][]int{
					{2, 3, 4, 5, 6, 7},
					{2, 3, 4, 5, 6, 7},
					{2, 3, 4, 5, 6, 7},
					{2, 3, 1, 1, 1, 1},
					{2, 3, 1, 1, 1, 7},
					{2, 3, 1, 1, 1, 7}, //會先往移動
				},
				[][]int{
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
				},
				1,
				1000,
			},
			&Cascading{
				1,
				[]*flow{},
				[][]int{
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
				},
				[][]int{
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
					{1, 2, 3, 4, 5, 6},
				},
			},
			300,
			false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			gotRetResult, gotRetPayCredit, err := base.getCascadingResult(tt.args.setting, tt.args.allSymbolInfo, tt.args.oldResultReel, tt.args.respinResult, tt.args.multiplier, tt.args.betCredit)
			if (err != nil) != tt.wantErr {
				t.Errorf("getCascadingResult() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			for i, _ := range gotRetResult.Flow {
				t.Logf("flow %d %+v\n", i, *gotRetResult.Flow[i])
			}
			if !reflect.DeepEqual(gotRetResult.NewResult, tt.wantRetResult.NewResult) {
				t.Errorf("getCascadingResult() gotRetResult newResult = %+v, want newResult %+v", gotRetResult.NewResult, tt.wantRetResult.NewResult)
			}

			if !reflect.DeepEqual(gotRetResult.FullResult, tt.wantRetResult.FullResult) {
				t.Errorf("getCascadingResult() gotRetResult FullResult = %+v, want FullResult %+v", gotRetResult.FullResult, tt.wantRetResult.FullResult)
			}
			if gotRetPayCredit != tt.wantRetPayCredit {
				t.Errorf("getCascadingResult() gotRetPayCredit = %v, want %v", gotRetPayCredit, tt.wantRetPayCredit)
			}
		})
	}
}

func TestBase_recycleCascading(t *testing.T) {
	base := &Cascade{}

	type args struct {
		setting       *core.BaseSetting
		respinReel    [][]int
		oriResultReel [][]int
		multiplier    int
		betCredit     float64
	}
	tests := []struct {
		name                  string
		args                  args
		wantRetCas            []*Cascading
		wantRetPayCreditTotal float64
		wantMultiplier        int
		wantErr               bool
	}{
		{
			"0",
			args{
				setting2900,
				respinReel2900,
				[][]int{
					{1, 1, 1, 4, 5, 6},
					{1, 1, 1, 4, 5, 6},
					{1, 1, 1, 4, 5, 6},
					{1, 1, 3, 4, 5, 6},
					{1, 1, 3, 4, 5, 6},
					{1, 1, 3, 4, 5, 6},
				},
				1,
				1000,
			},
			[]*Cascading{},
			1,
			1,
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotRetCas, gotRetPayCreditTotal, gotMultiplier, err := base.recycleCascading(tt.args.setting, tt.args.respinReel, tt.args.oriResultReel, tt.args.multiplier, tt.args.betCredit)
			if (err != nil) != tt.wantErr {
				t.Errorf("recycleCascading() error = %v, wantErr %v", err, tt.wantErr)
				return
			}

			for i, _ := range gotRetCas {
				t.Logf("Cascading %d ****************", i)
				t.Logf("Cascading multiplier %d", gotRetCas[i].Multiplier)
				for j, _ := range gotRetCas[i].Flow {
					t.Logf("Cascading flow %d %+v", j, gotRetCas[i].Flow[j])
				}
				t.Logf("Cascading new result %+v", gotRetCas[i].NewResult)
				t.Logf("Cascading full result %+v", gotRetCas[i].FullResult)
			}
			t.Logf("return multiplier %d", gotMultiplier)
			t.Logf("payCreditTotal %f", gotRetPayCreditTotal)
			//if !reflect.DeepEqual(gotRetCas, tt.wantRetCas) {
			//	t.Errorf("recycleCascading() gotRetCas = %v, want %v", gotRetCas, tt.wantRetCas)
			//}
			//if gotRetPayCreditTotal != tt.wantRetPayCreditTotal {
			//	t.Errorf("recycleCascading() gotRetPayCreditTotal = %v, want %v", gotRetPayCreditTotal, tt.wantRetPayCreditTotal)
			//}
		})
	}
}

func TestBase_GetResult(t *testing.T) {
	base := &Cascade{}
	type args struct {
		setting *core.BaseSetting
		args    *GetResultArgs
	}
	tests := []struct {
		name              string
		args              args
		wantRetResult     *BaseResult
		wantRetMultiplier int
		wantErr           bool
	}{
		{
			"0",
			args{
				setting2900,
				&GetResultArgs{
					baseReel2900,
					respinReel2900,
					50,
					20,
					1,
					1000,
					1,
					-1,
				},
			},
			&BaseResult{},
			1,
			false,
		},
	}

	cascadingTimes := make([]int, 20)

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotRetResult, _, err := base.GetResult(tt.args.setting, tt.args.args)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetResult() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			//if !reflect.DeepEqual(gotRetResult, tt.wantRetResult) {
			//	t.Errorf("GetResult() gotRetResult = %v, want %v", gotRetResult, tt.wantRetResult)
			//}
			//if gotRetMultiplier != tt.wantRetMultiplier {
			//	t.Errorf("GetResult() gotRetMultiplier = %v, want %v", gotRetMultiplier, tt.wantRetMultiplier)
			//}

			for i, _ := range gotRetResult.Cascading {
				llen := len(gotRetResult.Cascading[i].Flow)
				cascadingTimes[llen]++
			}
		})
	}

	t.Logf("%+v", cascadingTimes)
}

// main game 消除次數統計
func TestBase_main_cascading_times(t *testing.T) {

	base := &Cascade{}
	type args struct {
		setting *core.BaseSetting
		args    *GetResultArgs
	}
	tests := struct {
		name              string
		args              args
		wantRetResult     *BaseResult
		wantRetMultiplier int
		wantErr           bool
	}{
		"0",
		args{
			setting2900,
			&GetResultArgs{
				baseReel2900,
				respinReel2900,
				50,
				20,
				1,
				1000,
				1,
				-1,
			},
		},
		&BaseResult{},
		1,
		false,
	}

	spinTimes := 1
	stf := float32(spinTimes)
	cascadingTimes := make([]int, 21)
	multiplierTimesMap := make([]int, 31) //乘倍的次數紀錄

	for i := 0; i < spinTimes; i++ {
		gotRetResult, gotMultiplier, _ := base.GetResult(tests.args.setting, tests.args.args)
		//沒消除

		//fmt.Printf("PayCreditTotal %.0f scatter amount %d cascading amount %d \n",gotRetResult.PayCreditTotal,gotRetResult.ScatterInfo.Amount,len( gotRetResult.Cascading))
		cascadingTimes[len(gotRetResult.Cascading)]++
		multiplierTimesMap[gotMultiplier]++
	}

	t.Logf("Main Game 消除次數統計，總次數 %d\n", spinTimes)
	for i, n := range cascadingTimes {
		t.Logf("消除次數 %d：%d = %.2f%%\n", i, n, float32(n)/stf*100)
	}
	t.Logf("----------------------------")
	for i, n := range multiplierTimesMap {
		t.Logf("乘倍次數 %d：%d = %.2f%%\n", i, n, float32(n)/stf*100)
	}
}

// 算消除次數
func TestBase_freeSpin_cascading_times(t *testing.T) {

	base := &Cascade{}
	type args struct {
		setting *core.BaseSetting
		args    *GetResultArgs
	}

	arg := &GetResultArgs{
		freeSpinBaseReel2900[0],
		freeSpinRespinReel2900,
		50,
		20,
		1,
		1000,
		1,
		-1,
	}

	spinTimes := 10
	stf := float32(spinTimes)
	cascadingTimes := make([]int, 21)
	multiplierTimesMap := make([]int, 31) //乘倍的次數紀錄

	for i := 0; i < spinTimes; i++ {
		baseReel, _ := getFreeSpinBaseReelByWeightTable(freeSpinBaseReelWeightTable2900, freeSpinBaseReel2900)
		arg.Reel = baseReel
		gotRetResult, gotMultiplier, _ := base.GetResult(setting2900, arg)

		cascadingTimes[len(gotRetResult.Cascading)]++
		multiplierTimesMap[gotMultiplier]++
	}

	t.Logf("Free spin 消除次數統計，總次數 %d\n", spinTimes)
	for i, n := range cascadingTimes {
		t.Logf("消除次數 %d：%d = %.2f%%\n", i, n, float32(n)/stf*100)
	}
	t.Logf("----------------------------")
	for i, n := range multiplierTimesMap {
		t.Logf("乘倍次數 %d：%d = %.2f%%\n", i, n, float32(n)/stf*100)
	}
}

func getFreeSpinBaseReelByWeightTable(weightTable []int, baseReelSlice [][][]int) ([][]int, error) {
	r, err := slot.RandomIndexOfWeightTable(weightTable)
	if err != nil {
		return nil, fmt.Errorf("getFreeSpinBaseReel() error %s", err)
	}
	return baseReelSlice[r], nil
}

func TestCascade_DownSymbol(t *testing.T) {
	type fields struct {
		Core core.Core
	}
	type args struct {
		wheel        [][]int
		ignoreSymbol int
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   [][]int
	}{
		{
			"0",
			fields{Core: core.Core{}},
			args{
				[][]int{{7, 8, -1}, {-1, 7, 4}, {6, 6, -1}, {2, 7, 7}, {5, 6, 7}},
				-1,
			},
			[][]int{{-1, 7, 8}, {-1, 7, 4}, {-1, 6, 6}, {2, 7, 7}, {5, 6, 7}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			b := &Cascade{
				Core: tt.fields.Core,
			}
			if got := b.DownSymbol(tt.args.wheel, tt.args.ignoreSymbol); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("DownSymbol() = %v, want %v", got, tt.want)
			}
		})
	}
}
