package cascade

import (
	"github.com/idtksrv/simulator-server/game/core"
	"testing"
)

func BenchmarkGetResult(b *testing.B) {
	base := &Cascade{
	}
	type args struct {
		setting *core.BaseSetting
		args    *GetResultArgs
	}
	tests := struct {
		name              string
		args              args
		wantRetResult     *BaseResult
		wantRetMultiplier int
		wantErr           bool
	}{
		"0",
		args{
			setting2900,
			&GetResultArgs{
				baseReel2900,
				respinReel2900,
				50,
				20,
				1,
				1000,
				1,
				-1,
			},
		},
		&BaseResult{},
		1,
		false,
	}

	cascadingTimes := make([]int, 20)

	for i := 0; i < b.N; i++ {
		gotRetResult, _, _ := base.GetResult(tests.args.setting, tests.args.args)
		for i, _ := range gotRetResult.Cascading {
			llen := len(gotRetResult.Cascading[i].Flow) - 1
			cascadingTimes[llen]++
		}
	}

	b.Logf("%+v", cascadingTimes)

}
