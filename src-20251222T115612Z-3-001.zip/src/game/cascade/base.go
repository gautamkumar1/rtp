package cascade

import (
	"fmt"
	"github.com/idtksrv/simulator-server/game/core"
	"github.com/idtksrv/simulator-server/internal/configuration"
	sliceUtil "github.com/idtksrv/simulator-server/internal/util/slice"
	"github.com/shopspring/decimal"
)

/*
依據 symbol 數量消除

//spin
//第一輪
1 取新輪面
2 scatter info
3 checkAllSymbolInfoPrize
	有消除 / 沒消除結束
    第一個 symbol 有中 -> 消除
    第二個 symbol 有中 ->消除
    .....
4 全部消除完，取新輪面，轉化 cascading 輪面
5 算這個輪面分數
6 乘倍+1
//第二輪消除
7 checkAllSymbolInfoPrize(回3)
*/

/*
1024 way 依據連線消除

//spin
//第一輪
1 取新輪面
2 scatter info
//recycleCascading
3 check 每個 symbol info
4 symbol 有連線，算錢
5 第一個 symbol 連線 ->消除
6 第二個 symbol 連線 ->消除
7 .....
8 全部消除完，黃金 symbol 變 wild
8 symbol 往下掉

//第二輪消除
9 取塞空位輪面
10 check 是否有消除(in simulator)
11 有消除 -> 乘倍提高 , 同上
   沒消除 -> 新 spin
*/

//BaseResult Game base result
type BaseResult struct {
	PayCreditTotal float64              `json:"pay_credit_total"` //總 pay credit
	GameResult     [][]int              `json:"game_result"`
	ScatterInfo    *core.BaseSymbolInfo `json:"scatter_info"`
	Cascading      []*Cascading         `json:"cascading"` //消除資料
}

type Cascading struct {
	Multiplier int     `json:"multiplier"` //乘倍
	Flow       []*flow `json:"flow"`
	NewResult  [][]int `json:"new_result"` //新出的symbol,只有空位的symbol
	//[5,5,1],
	//[5,5,1,1],
	//[],
	//[],
	//[8,7,9,1,2,3],
	//[],
	FullResult [][]int `json:"full_new_result"` //晚整的new result, newResult 補在 oldResult上面，合成 fullResult

}

type flow struct {
	SymbolID  int     `json:"symbol_id"`
	Amount    int     `json:"amount"`
	PayCredit float64 `json:"pay_credit"` //乘倍後的數字
}
type GetResultArgs struct {
	Reel        [][]int
	RespineReel [][]int
	LineBet     float64
	Lines       int
	CoinValue   float64
	BetCredit   float64
	Multiplier  int //贏分乘倍
	//以下 for way game
	UnDeleteSymbol int
}

type Cascade struct {
	core.Core
}

//GetResult 傳入
//main game base reel / respin reel
//free spin base reel(依據 weight table) / respin reel
//GetResult return column x line result
func (b *Cascade) GetResult(setting *core.BaseSetting, args *GetResultArgs) (retResult *BaseResult, retMultiplier int, retErr error) {
	logFunc := "GetResult"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	//get result reel
	resultReel, err := b.Core.RandomWheel(args.Reel, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	//scatter info
	scatterAmount, scatterPosition, _, err := b.Core.CountSymbolInfo(resultReel, setting.Symbol.ScatterID, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	//cascading 消除處理
	cas, casPayCredit, retMultiplier, err := b.recycleCascading(setting, args.RespineReel, resultReel, args.Multiplier, args.BetCredit)

	//算 scatter credit
	//var scatterCredit float64 = 0
	//scatterPayRate := b.Core.GetPayTablePayRate(setting.Symbol.ScatterID[0], scatterAmount, setting.PayTable)
	////scatter pay 乘倍, 套用最新的 multiplier
	//if scatterPayRate > 0 {
	//	scatterCredit, _ = decimal.NewFromFloat(args.BetCredit).Mul(decimal.NewFromFloat(scatterPayRate)).Mul(decimal.NewFromInt(int64(retMultiplier))).Float64()
	//}

	//算 payCreditTotal
	scatterCredit, scatterPayRate := b.Core.CountSymbolPayout(setting.Symbol.ScatterID[0], scatterAmount, setting.PayTable, float64(retMultiplier), args.BetCredit)

	payCreditTotal, _ := decimal.NewFromFloat(casPayCredit).Add(decimal.NewFromFloat(scatterCredit)).Float64()

	//
	retResult = &BaseResult{
		payCreditTotal,
		resultReel,
		&core.BaseSymbolInfo{
			ID:         setting.Symbol.ScatterID,
			Position:   scatterPosition,
			Amount:     scatterAmount,
			PayCredit:  scatterCredit,
			PayRate:    scatterPayRate,
			Multiplier: retMultiplier,
		},
		cas,
	}
	return

}

//checkAllSymbolInfoPrize 是否有 symbol 達到 get prize
func (b *Cascade) checkAllSymbolInfoPrize(symbolInfo []*core.BaseSymbolInfo, getPrizeSymbolMinNumPerLine int) bool {
	for i, _ := range symbolInfo {

		//get payout
		if symbolInfo[i].Amount >= getPrizeSymbolMinNumPerLine {
			return true
		}
	}
	return false
}

//recycleCascading 算完整的 cascading 結果
//oriResultReel 初始輪面
//multiplier 算分倍數
//betCredit 投注額
//1 算出所有 symbol info
//2 複製 ori reel
//3 檢查所有 symbol 是否有中獎

//第一個輪面，每個輪面裡面可能有多次 symbol 消除
//第二個輪面
//.....
// retMultiplier 最後 multiplier 是多少
func (b *Cascade) recycleCascading(setting *core.BaseSetting, respinReel, oriResultReel [][]int, multiplier int, betCredit float64) (retCas []*Cascading, retPayCreditTotal float64, retMultiplier int, retErr error) {

	retCas = []*Cascading{}

	//所有輪面的總金額
	rpc := decimal.NewFromFloat(0)

	//cascading
	allSymbolInfo, _ := b.Core.CountSymbolsInfoByID(oriResultReel, setting.Symbol.SymbolID, setting.ColumnAndLine)
	//
	oldResultReel := sliceUtil.Duplicate2DSlice(oriResultReel)

	//有中才進
	for b.checkAllSymbolInfoPrize(allSymbolInfo, setting.GetPrizeSymbolMinNumPerLine) {
		//reSpin
		reSpinResultReel, _ := b.Core.RandomWheel(respinReel, setting.ColumnAndLine)

		casResult, payCredit, _ := b.getCascadingResult(setting, allSymbolInfo, oldResultReel, reSpinResultReel, multiplier, betCredit)

		retCas = append(retCas, casResult)

		//算每個輪面得總和
		rpc = rpc.Add(decimal.NewFromFloat(payCredit))
		retPayCreditTotal, _ = rpc.Float64()

		oldResultReel = sliceUtil.Duplicate2DSlice(casResult.FullResult) //完整新輪面
		allSymbolInfo, _ = b.Core.CountSymbolsInfoByID(oldResultReel, setting.Symbol.SymbolID, setting.ColumnAndLine)

		multiplier++ //有消除 +1
	}
	return retCas, retPayCreditTotal, multiplier, nil
}

//GetCascadingResult 單次的輪面消除結果，一個輪面有可能消多個 symbol
//cascading result 是繼承原本輪面，只補上被消除的位置
func (b *Cascade) getCascadingResult(setting *core.BaseSetting, allSymbolInfo []*core.BaseSymbolInfo, oldResultReel [][]int, newWheel [][]int, multiplier int, betCredit float64) (retResult *Cascading, retPayCredit float64, retErr error) {

	//這次輪面的總金額
	rpc := decimal.NewFromFloat(0)

	fl := []*flow{}
	bc := decimal.NewFromFloat(betCredit)
	mp := decimal.NewFromInt(int64(multiplier))
	payCredit := 0.0
	//check all symbol info and count pay credit
	for i, _ := range allSymbolInfo {
		info := allSymbolInfo[i]

		id := info.ID[0]
		//get payout
		if info.Amount >= setting.GetPrizeSymbolMinNumPerLine {
			payRate := b.Core.GetPayTablePayRate(id, info.Amount, setting.PayTable)

			pr := decimal.NewFromFloat(payRate) // pay rate
			pc := bc.Mul(pr).Mul(mp)            //betline * pay rate * multiplier
			payCredit, _ = pc.Float64()

			fl = append(fl, &flow{id, info.Amount, payCredit})

			rpc = rpc.Add(pc)
			retPayCredit, _ = rpc.Float64()
		}
	}

	//mark cascading symbol position as -1
	markedWheel := b.MarkCascadingSymbol(oldResultReel, allSymbolInfo, setting.GetPrizeSymbolMinNumPerLine)

	//取得重整的輪面
	downWheel := b.DownSymbol(markedWheel, configuration.SymbolIDNotUse)

	//新 wheel 加到 down wheel 上
	newResult, fullResult := b.Core.ComposeNewWheel(newWheel, downWheel)

	//cascading
	cas := &Cascading{
		Multiplier: multiplier,
		Flow:       fl,
		NewResult:  newResult,
		FullResult: fullResult,
	}

	return cas, retPayCredit, nil
}

//MarkCascadingSymbol 依據 allSymbolInfo 找出數量有中獎的symbol, mark no use
func (b *Cascade) MarkCascadingSymbol(resultReel [][]int, allSymbolInfo []*core.BaseSymbolInfo, getPrizeSymbolMinNumPerLine int) [][]int {

	reel := sliceUtil.Duplicate2DSlice(resultReel)

	for i, _ := range allSymbolInfo {
		info := allSymbolInfo[i]
		if info.Amount >= getPrizeSymbolMinNumPerLine {

			//找出 position 相同位置，都做記號
			for x, _ := range info.Position {
				for y, v := range info.Position[x] {
					if v == configuration.SymbolIDHas {
						reel[x][y] = configuration.SymbolIDNotUse
					}
				}
			}
		}
	}
	return reel
}
