package core

type BaseSetting struct {
	ColumnAndLine               []int       //幾欄幾列 eg. 3x5=[3,5]
	ColumnAndLineMax            []int       //幾欄幾列最大值 eg. 5x9=[5,5]
	Symbol                      *BaseSymbol //symbol id
	GetPrizeSymbolMinNumPerLine int         //最少幾個symbol連線才有獎
	Reel                        [][]int
	PayLine                     [][]int
	PayTable                    []*BasePayTable
}

type BaseSymbol struct {
	WildID    []int
	ScatterID []int
	SymbolID  []int
}

// BasePayTable
// 賠率
// 範例
//
//	payTable = []PayRate{
//		{
//			1,
//			[]int{0, 0, 0, 200, 1000, 5000}, //index 0=0個0倍,1=1個0倍,2=2個0倍,3=3個200倍,4=4個1000..
//		},
//	}
type BasePayTable struct {
	SymbolID int       //Symbol id
	PayRate  []float64 //賠率,index 0=0個0倍,1=1個0倍,2=2個0倍,3=3個200倍,4=4個1000..
}

// BaseResult SLOT game base result 回傳的結果
type BaseResult struct {
	PayCreditTotal float64           `json:"pay_credit_total"` //總 pay credit
	GameResult     [][]int           `json:"game_result"`
	PayLineResult  []*BaseLineResult `json:"pay_line"`
	ScatterInfo    *BaseSymbolInfo   `json:"scatter_info"`
	WildInfo       *BaseSymbolInfo   `json:"wild_info"`
	ScatterExtra   [][]float32       `json:"scatter_extra"`
	//例如算好的 scatter position 再生出一個對應位置的資料,HoldAndSpinScatterOnlySlot有用到
	//用 scatter 出現的順序取 weightTable
	//再用weightTable random 決定取哪個 element
}

// BaseLineResult 每條線的結果
type BaseLineResult struct {
	PayLine    int     `json:"pay_line"`   //pay line id
	SymbolID   int     `json:"symbol_id"`  //這條線的symbol id
	Amount     int     `json:"amount"`     //中幾個symbol
	PayCredit  float64 `json:"pay_credit"` //本條線金額
	Multiplier int     `json:"multiplier"` //倍數
}
type BaseSymbolInfo struct {
	ID         []int   `json:"id"`
	Position   [][]int `json:"position"`
	Amount     int     `json:"amount"`
	Multiplier int     `json:"multiplier"` //這個symbol 賠分乘倍，少數遊戲有
	PayCredit  float64 `json:"pay_credit"` //scatter 自帶陪分，中多少
	PayRate    float64 `json:"pay_rate"`   //這個symbol 自身的賠率，少數遊戲有
}

type ActiveFreeSpinData struct {
	SymbolID      []int
	FreeSpinTimes []int
}

type GetResultArgs struct {
	Reel                     [][]int
	LineBet                  float64
	Lines                    int
	CoinValue                float64
	BetCredit                float64
	IsSpecificThenNormalReel bool  //是否取正常 column x line輪面，或是是否先取特殊輪面，再從特殊輪面取真正的輪面
	SpecificColumnAndLine    []int //指定 column x line 的輪面
}

// BonusData 通用資料
type BonusData struct {
	GrandPayRate int
	MajorPayRate int
	MinorPayRate int
	MiniPayRate  int
}
