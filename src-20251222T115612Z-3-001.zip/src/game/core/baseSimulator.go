package core

import (
	"encoding/json"
	"fmt"

	"github.com/idtksrv/simulator-server/internal/configuration"
	"github.com/idtksrv/simulator-server/internal/jackpot/jackpot800"
	"github.com/idtksrv/simulator-server/internal/util/rand"
)

type BaseSimulator struct {
	Core
	simulatorSetting *configuration.SimulatorSetting
	gameSetting      *GameSetting
}

// GameSetting 包括 baseSetting 還有這個遊戲的setting
type GameSetting struct {
	MainGameSettingID int          //simulator對照id用
	BaseSetting       *BaseSetting //base setting for normal slot
	NormalMode        *Mode
	BuyMode           *Mode
}

type Mode struct {
	ReSpinData                 *reSpinData
	ScatterData                *HoldAndSpinScatterData
	BonusData                  *BonusData
	BaseReel                   [][]int
	RespinReel                 [][]int
	HoldAndSpinScatterOnlyData *HoldAndSpinScatterOnlyData //hold and spin 用
	ActiveFreeSpin             *ActiveFreeSpinData         //3000有用，後來都移到extra
	FreeSpin                   *freeSpinData
	ExtraData                  json.RawMessage
	//ActiveFreeSpinScatterMoreEqual int //棄用
}
type reSpinData struct {
	UpperBound  int
	LowerBound  int //rerun 贏倍邊界
	Probability map[string]float64
}
type freeSpinData struct {
	BaseReel   [][]int
	RespinReel [][]int

	RespinReelB           [][]int
	RespinReelWeightTable []int64
}

// MainGameResult 回傳的結果包括 base result 還有這個遊戲 result
type MainGameResult struct {
	PayCreditTotal float64           `json:"pay_credit_total"` //總 pay credit
	GameResult     [][]int           `json:"game_result"`
	PayLineResult  []*BaseLineResult `json:"pay_line"`
	ScatterInfo    *BaseSymbolInfo   `json:"scatter_info"`
	WildInfo       *BaseSymbolInfo   `json:"wild_info"`
	ScatterExtra   [][]float32       `json:"scatter_extra"` //scatter額外資料(附加倍數)，對應scatterInfo的位置
	Extra          interface{}       `json:"extra"`         //main game 的額外資訊
}

// 整體Result
type Result struct {
	GameID              int                         `json:"game_id"`
	MainGame            *MainGameResult             `json:"main_game"`
	GetSubGame          bool                        `json:"get_sub_game"` //是否中sub game, bool
	SubGame             interface{}                 `json:"sub_game"`
	GetJackpot          bool                        `json:"get_jackpot"`
	Jackpot             *jackpot800.Result          `json:"jackpot"`
	GetJackpotIncrement bool                        `json:"get_jackpot_increment"`
	JackpotIncrement    *jackpot800.IncrementCredit `json:"jackpot_increment"` //此遊戲沒有jackpot所以給空array
	Extra               interface{}                 `json:"extra"`             //每個遊戲的額外資訊
}

func NewSimulator(simSetting *configuration.SimulatorSetting, mainGameSetting *configuration.GameSetting) (*BaseSimulator, error) {

	s := &BaseSimulator{
		simulatorSetting: simSetting,
	}

	var gs []GameSetting
	if err := json.Unmarshal(mainGameSetting.GameSetting, &gs); err != nil {
		return nil, err
	}
	for index, setting := range gs {
		if setting.MainGameSettingID == simSetting.MainGameSettingID {
			s.gameSetting = &gs[index]
			return s, nil
		}
	}
	return nil, fmt.Errorf("main game setting not found id %d", simSetting.MainGameSettingID)
}

func (s *BaseSimulator) GetSimulatorSetting() *configuration.SimulatorSetting {
	return s.simulatorSetting
}
func (s *BaseSimulator) GetGameSetting() *GameSetting {
	return s.gameSetting
}

func (s BaseSimulator) BaseResultToMainGameResult(baseResult *BaseResult) *MainGameResult {

	return &MainGameResult{
		baseResult.PayCreditTotal,
		baseResult.GameResult,
		baseResult.PayLineResult,
		baseResult.ScatterInfo,
		baseResult.WildInfo,
		baseResult.ScatterExtra,
		nil,
	}
}
func (s *BaseSimulator) CreateEmptyResult() (retResult *Result) {

	retResult = &Result{
		GameID:              s.simulatorSetting.GameID,
		MainGame:            nil,
		GetSubGame:          false,
		GetJackpot:          false,
		GetJackpotIncrement: false,
		SubGame:             nil,
		Jackpot:             nil,
		JackpotIncrement:    nil,
		Extra:               nil,
	}
	return
}

func (s *BaseSimulator) GetMode(spinMode int) *Mode {
	if spinMode == configuration.BuySpinYes {
		return s.gameSetting.BuyMode
	}
	return s.gameSetting.NormalMode
}

/*
//GetNormalResult 取最基本的result
func (s *BaseSimulator) GetNormalResult(sd *slotGame.ScatterData, reel [][]int, lineBet float64, lines int, coinValue float64, betCredit float64) (retResult *MainGameResult, retWeightTableIndex int, retErr error) {
	logFunc := "getMainGameResult"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	result, err := s.Base.GetResult(s.gameSetting.BaseSetting, &slotGame.GetResultArgs{
		Reel:                     reel,
		LineBet:                  lineBet,
		Lines:                    lines,
		CoinValue:                coinValue,
		BetCredit:                betCredit,
		IsSpecificThenNormalReel: false,
	})
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	retResult = &MainGameResult{
		result.PayCreditTotal,
		result.GameResult,
		result.PayLineResult,
		result.ScatterInfo,
		result.WildInfo,
		[][]float32{},
		nil,
	}
	return
}
*/

func (s *BaseSimulator) DecideReRun(targetRTP string, reRunTimes int, payout, betCredit float64, lowerBound, upperBound int, probability map[string]float64) bool {

	//no rerun
	if targetRTP == configuration.RTPDefault {
		return false
	}

	//ub := 9999999999
	//if upperBound > 0 {
	//	ub = upperBound
	//}
	//rerun once only
	if reRunTimes < 1 {
		//reRun 設定
		//payout rate >=lowerBound
		mul := payout / betCredit

		if mul >= float64(lowerBound) {
			if rtp, ok := probability[targetRTP]; ok {
				if rand.Float64() < rtp {
					return true
				}
			}
		}
	}
	return false
}
