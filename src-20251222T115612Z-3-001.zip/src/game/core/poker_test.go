package core

import (
	"reflect"
	"testing"
)

func TestCore_Shuffle(t *testing.T) {
	c := &Core{}
	type args struct {
		deck       []int
		cardAmount int
	}
	tests := []struct {
		name string
		args args
	}{
		{
			"0",
			args{
				c.CreateOrderedDeck(),
				7,
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			initLen := len(tt.args.deck)
			t.Logf("%v", tt.args.deck)
			gotRetCards, gotRetDeck := c.Shuffle(tt.args.deck, tt.args.cardAmount)
			t.Logf("got cards %v", gotRetCards)

			//deck 剩餘的數量不對
			if len(gotRetDeck) != initLen-tt.args.cardAmount {
				t.Errorf("Shuffle() left deck len = %d want = %d", len(gotRetDeck), initLen-tt.args.cardAmount)
			}
		})
	}
}

func TestCore_createOrderedDeck(t *testing.T) {
	tests := []struct {
		name string
		want []int
	}{
		{
			"0",
			[]int{101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if got := c.CreateOrderedDeck(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("createOrderedDeck() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCore_removeCard(t *testing.T) {
	type args struct {
		s     []int
		index int
	}
	tests := []struct {
		name string
		args args
		want []int
	}{
		{
			"0",
			args{
				[]int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
				0,
			},
			[]int{10, 2, 3, 4, 5, 6, 7, 8, 9},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if got := c.removeCard(tt.args.s, tt.args.index); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("removeCard() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCore_createPokerMapWithCards(t *testing.T) {
	type args struct {
		cards []int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{
				[]int{101, 201, 303, 313, 413, 405},
			},
			[][]int{
				{101, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
				{201, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
				{-1, -1, 303, -1, -1, -1, -1, -1, -1, -1, -1, -1, 313},
				{-1, -1, -1, -1, 405, -1, -1, -1, -1, -1, -1, -1, 413}},
		},
		{
			"1",
			args{
				[]int{101, 201, 102, 103, 104, 105, 106},
			},
			[][]int{
				{101, 102, 103, 104, 105, 106, -1, -1, -1, -1, -1, -1, -1},
				{201, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
				{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
				{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if got := c.createPokerMapWithCards(tt.args.cards); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("createPokerMapWithCards() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCore_createTheSameNumberCardAmount(t *testing.T) {
	type args struct {
		pokerMap [][]int
	}
	tests := []struct {
		name string
		args args
		want []int
	}{
		{
			"0",
			args{[][]int{
				{101, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
				{201, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
				{-1, -1, 303, -1, -1, -1, -1, -1, -1, -1, -1, -1, 313},
				{-1, -1, -1, -1, 405, -1, -1, -1, -1, -1, -1, -1, 413}},
			},
			[]int{2, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 2},
		},
		{
			"1",
			args{[][]int{
				{101, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
				{201, -1, -1, -1, -1, -1, -1, -1, 209, -1, -1, -1, -1},
				{-1, -1, 303, -1, -1, -1, -1, -1, 309, -1, -1, -1, 313},
				{-1, -1, -1, -1, 405, -1, -1, -1, 409, -1, -1, -1, 413}},
			},
			[]int{2, 0, 1, 0, 1, 0, 0, 0, 3, 0, 0, 0, 2},
		},
		{
			"2",
			args{[][]int{
				{101, -1, -1, -1, -1, 106, -1, -1, -1, -1, 111, -1, -1},
				{201, -1, -1, -1, -1, -1, -1, -1, 209, -1, -1, -1, -1},
				{-1, -1, 303, -1, -1, -1, -1, -1, 309, -1, -1, -1, 313},
				{-1, -1, -1, -1, 405, 406, -1, -1, 409, -1, -1, -1, 413}},
			},
			[]int{2, 0, 1, 0, 1, 2, 0, 0, 3, 0, 1, 0, 2},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if got := c.createTheSameNumberCardAmount(tt.args.pokerMap); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("createTheSameNumberCardAmount() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCore_mergeCardsIntoOneRow(t *testing.T) {
	c := &Core{}
	type args struct {
		pokerMap [][]int
	}
	tests := []struct {
		name string
		args args
		want []int
	}{
		{
			"0",
			args{[][]int{
				{101, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
				{201, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
				{-1, -1, 303, -1, -1, -1, -1, -1, -1, -1, -1, -1, 313},
				{-1, -1, -1, -1, 405, -1, -1, -1, -1, -1, -1, -1, 413}}},
			[]int{201, -1, 303, -1, 405, -1, -1, -1, -1, -1, -1, -1, 413},
		},
		{
			"1",
			args{[][]int{
				{101, -1, -1, -1, -1, -1, 107, -1, -1, -1, -1, -1, -1},
				{201, -1, -1, -1, -1, -1, -1, -1, -1, -1, 211, -1, -1},
				{-1, -1, 303, -1, -1, -1, -1, -1, -1, -1, -1, -1, 313},
				{-1, -1, -1, -1, 405, -1, -1, -1, -1, 410, -1, -1, 413}}},
			[]int{201, -1, 303, -1, 405, -1, 107, -1, -1, 410, 211, -1, 413},
		},
		{
			"2",
			args{[][]int{
				{101, 102, -1, -1, -1, -1, 107, -1, 109, -1, -1, -1, -1},
				{201, -1, -1, -1, -1, 206, -1, -1, 209, -1, 211, -1, -1},
				{-1, 302, 303, -1, -1, -1, -1, -1, -1, -1, -1, -1, 313},
				{-1, -1, -1, -1, 405, -1, -1, -1, -1, 410, -1, -1, 413}}},
			[]int{201, 302, 303, -1, 405, 206, 107, -1, 209, 410, 211, -1, 413},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := c.mergeCardsIntoOneRow(tt.args.pokerMap); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("mergeCardsIntoOneRow() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCore_cardIDToSortNum(t *testing.T) {
	type args struct {
		id int
	}
	tests := []struct {
		name string
		args args
		want int
	}{
		{
			"0",
			args{101},
			106,
		},
		{
			"1",
			args{401},
			109,
		},
		{
			"2",
			args{102},
			11,
		},
		{
			"3",
			args{202},
			12,
		},
		{
			"3",
			args{413},
			69,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if got := c.cardIDToSortNumber(tt.args.id); got != tt.want {
				t.Errorf("cardIDToSortNum() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCore_sortNumToCardID(t *testing.T) {
	type args struct {
		num int
	}
	tests := []struct {
		name string
		args args
		want int
	}{
		{
			"0",
			args{106},
			101,
		},
		{
			"1",
			args{109},
			401,
		},
		{
			"2",
			args{11},
			102,
		},
		{
			"3",
			args{12},
			202,
		},
		{
			"3",
			args{69},
			413,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if got := c.sortNumberToCardID(tt.args.num); got != tt.want {
				t.Errorf("sortNumToCardID() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCore_cardsToSortNumbers(t *testing.T) {
	type args struct {
		cards []int
	}
	tests := []struct {
		name  string
		args  args
		wantS []int
	}{
		{
			"0",
			args{[]int{101, 401, 102, 202, 413}},
			[]int{11, 12, 69, 106, 109},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if gotS := c.cardsToSortNumbers(tt.args.cards); !reflect.DeepEqual(gotS, tt.wantS) {
				t.Errorf("cardsToSortNumbers() = %v, want %v", gotS, tt.wantS)
			}
		})
	}
}

func TestCore_sortNumbersToCards(t *testing.T) {
	type args struct {
		numbers []int
	}
	tests := []struct {
		name  string
		args  args
		wantS []int
	}{
		{
			"0",
			args{[]int{106, 109, 11, 12, 69}},
			[]int{101, 401, 102, 202, 413},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if gotS := c.sortNumbersToCards(tt.args.numbers); !reflect.DeepEqual(gotS, tt.wantS) {
				t.Errorf("sortNumbersToCards() = %v, want %v", gotS, tt.wantS)
			}
		})
	}
}

func TestCore_pickBiggestSortNumbers(t *testing.T) {
	type args struct {
		sortNumbers []int
		amount      int
	}
	tests := []struct {
		name          string
		args          args
		wantPickCards []int
	}{
		{
			"0",
			args{[]int{1, 2, 3, 4, 5},
				5},
			[]int{1, 2, 3, 4, 5},
		},
		{
			"1",
			args{[]int{1, 2, 3, 4, 5},
				3},
			[]int{3, 4, 5},
		},
		{
			"2",
			args{[]int{1, 2, 3, 4, 5, 6, 7, 8},
				5},
			[]int{4, 5, 6, 7, 8},
		},
		{
			"3",
			args{[]int{1, 2, 3, 4, 5, 6, 7, 8},
				1},
			[]int{8},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if gotPickCards := c.pickBiggestSortNumbers(tt.args.sortNumbers, tt.args.amount); !reflect.DeepEqual(gotPickCards, tt.wantPickCards) {
				t.Errorf("pickBiggestSortNumbers() = %v, want %v", gotPickCards, tt.wantPickCards)
			}
		})
	}
}

func TestCore_pickBiggestStraight(t *testing.T) {
	c := &Core{}
	type args struct {
		st [][]int
	}
	tests := []struct {
		name string
		args args
		want []int
	}{
		{
			"0",
			args{
				[][]int{{1, 2, 3, 4, 5}},
			},
			[]int{1, 2, 3, 4, 5},
		},
		{
			"1",
			args{
				[][]int{{1, 2, 3, 4, 5}, {2, 3, 4, 5, 6}},
			},
			[]int{2, 3, 4, 5, 6},
		},
		{
			//最後一張Ace > k
			"2",
			args{
				[][]int{{1, 2, 3, 4, 413}, {2, 3, 4, 5, 101}},
			},
			[]int{2, 3, 4, 5, 101},
		},
		{
			//有一組長度!=5，不考慮
			"3",
			args{
				[][]int{{1, 2, 3, 4, 413}, {2, 3, 4, 5, 313}, {1, 2, 3, 4, 5, 6, 201}},
			},
			[]int{1, 2, 3, 4, 413},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := c.pickBiggestStraight(tt.args.st); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("pickBiggestStraight() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCore_pickBiggestCards(t *testing.T) {
	c := &Core{}

	type args struct {
		cards  []int
		amount int
	}
	tests := []struct {
		name          string
		args          args
		wantPickCards []int
	}{
		{
			"0",
			args{
				[]int{101, 201, 113, 403, 309},
				1,
			},
			[]int{201},
		},
		{
			"1",
			args{
				[]int{101, 201, 113, 403, 309, 203, 204, 310, 411},
				5,
			},
			[]int{310, 411, 113, 101, 201},
		},
		{
			"2",
			args{
				[]int{101, 201, 301, 302, 403, 111, 212, 303, 408, 410, 313},
				5,
			},
			[]int{212, 313, 101, 201, 301},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			if gotPickCards := c.pickBiggestCards(tt.args.cards, tt.args.amount); !reflect.DeepEqual(gotPickCards, tt.wantPickCards) {
				t.Errorf("pickBiggestCards() = %v, want %v", gotPickCards, tt.wantPickCards)
			}
		})
	}
}

func TestCore_processPair(t *testing.T) {
	c := &Core{}

	type args struct {
		cards                   []int
		theSameNumberCardAmount []int
	}
	tests := []struct {
		name          string
		args          args
		wantPickCards []int
		wantCardType  int
		wantYes       bool
	}{
		{
			"0",
			args{
				[]int{101, 201, 302, 402, 111, 212},
				[]int{2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0},
			},
			[]int{101, 201, 302, 402, 212},
			TwoPair,
			true,
		},
		{
			"1",
			args{
				[]int{101, 201, 302, 402, 111, 212, 303, 408, 410},
				[]int{2, 2, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0},
			},
			[]int{101, 201, 302, 402, 212},
			TwoPair,
			true,
		},
		{
			"2",
			args{
				[]int{101, 201, 302, 403, 111, 212, 303, 408, 410, 311, 313},
				[]int{2, 1, 2, 0, 0, 0, 0, 0, 0, 1, 2, 0, 1},
			},
			[]int{101, 201, 111, 311, 313},
			TwoPair,
			true,
		},
		{
			"3",
			args{
				[]int{101, 201, 302, 403, 111, 212, 408, 410, 313},
				[]int{2, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1},
			},
			[]int{101, 201, 111, 212, 313},
			Pair,
			true,
		},
		{
			"4",
			args{
				[]int{101, 201, 301, 302, 403, 111, 212, 303, 408, 410, 313},
				[]int{3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
			},
			[]int{},
			HighCard,
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			gotPickCards, gotCardType, gotYes := c.processPair(tt.args.cards, tt.args.theSameNumberCardAmount)
			if !reflect.DeepEqual(gotPickCards, tt.wantPickCards) {
				t.Errorf("processPair() gotPickCards = %v, want %v", gotPickCards, tt.wantPickCards)
			}
			if gotCardType != tt.wantCardType {
				t.Errorf("processPair() gotCardType = %v, want %v", gotCardType, tt.wantCardType)
			}
			if gotYes != tt.wantYes {
				t.Errorf("processPair() gotYes = %v, want %v", gotYes, tt.wantYes)
			}
		})
	}
}

func TestCore_processThreeOfAKing(t *testing.T) {
	type args struct {
		cards                   []int
		theSameNumberCardAmount []int
	}
	tests := []struct {
		name          string
		args          args
		wantPickCards []int
		wantYes       bool
	}{
		{
			"0",
			args{
				[]int{101, 201, 301, 402, 111, 212},
				[]int{3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0},
			},
			[]int{101, 201, 301, 111, 212},
			true,
		},
		{
			"1",
			args{
				[]int{101, 201, 301, 402, 111, 212, 306, 307},
				[]int{3, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0},
			},
			[]int{101, 201, 301, 111, 212},
			true,
		},
		{
			"2",
			args{
				[]int{101, 201, 301, 401, 402, 111, 212, 306, 307},
				[]int{4, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0},
			},
			[]int{},
			false,
		},
		{
			"3",
			args{
				[]int{101, 201, 402, 111, 212, 306, 307, 407, 107},
				[]int{2, 1, 0, 0, 0, 1, 3, 0, 0, 0, 1, 1, 0},
			},
			[]int{307, 407, 107, 101, 201},
			true,
		},
		{
			"4",
			args{
				[]int{201, 402, 111, 212, 306, 307, 407, 107, 213},
				[]int{2, 1, 0, 0, 0, 1, 3, 0, 0, 0, 1, 1, 0},
			},
			[]int{307, 407, 107, 213, 201},
			true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			gotPickCards, gotYes := c.processThreeOfAKing(tt.args.cards, tt.args.theSameNumberCardAmount)
			if !reflect.DeepEqual(gotPickCards, tt.wantPickCards) {
				t.Errorf("processThreeOfAKing() gotPickCards = %v, want %v", gotPickCards, tt.wantPickCards)
			}
			if gotYes != tt.wantYes {
				t.Errorf("processThreeOfAKing() gotYes = %v, want %v", gotYes, tt.wantYes)
			}
		})
	}
}

func TestCore_processFourOfAKing(t *testing.T) {
	type args struct {
		cards                   []int
		theSameNumberCardAmount []int
	}
	tests := []struct {
		name          string
		args          args
		wantPickCards []int
		wantYes       bool
	}{
		{
			"0",
			args{
				[]int{101, 201, 301, 401, 402, 111, 212},
				[]int{4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0},
			},
			[]int{101, 201, 301, 401, 212},
			true,
		},
		{
			"1",
			args{
				[]int{101, 201, 301, 402, 111, 212, 306, 307, 401},
				[]int{4, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0},
			},
			[]int{101, 201, 301, 401, 212},
			true,
		},
		{
			"2",
			args{
				[]int{101, 201, 301, 402, 111, 212, 306, 307},
				[]int{3, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0},
			},
			[]int{},
			false,
		},
		{
			"3",
			args{
				[]int{207, 101, 201, 402, 111, 212, 306, 307, 407, 107},
				[]int{2, 1, 0, 0, 0, 1, 4, 0, 0, 0, 1, 1, 0},
			},
			[]int{207, 307, 407, 107, 201},
			true,
		},
		{
			"4",
			args{
				[]int{112, 212, 312, 412, 113, 213, 313, 413},
				[]int{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4},
			},
			[]int{113, 213, 313, 413, 412},
			true,
		},
		{
			"5",
			args{
				[]int{101, 201, 301, 401, 103, 203, 303},
				[]int{4, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			},
			[]int{101, 201, 301, 401, 303},
			true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			gotPickCards, gotYes := c.processFourOfAKing(tt.args.cards, tt.args.theSameNumberCardAmount)
			if !reflect.DeepEqual(gotPickCards, tt.wantPickCards) {
				t.Errorf("processFourOfAKing() gotPickCards = %v, want %v", gotPickCards, tt.wantPickCards)
			}
			if gotYes != tt.wantYes {
				t.Errorf("processFourOfAKing() gotYes = %v, want %v", gotYes, tt.wantYes)
			}
		})
	}
}

func TestCore_processStraight(t *testing.T) {
	c := &Core{}

	type args struct {
		cardsInOneRow []int
	}
	tests := []struct {
		name         string
		args         args
		wantStraight []int
		wantYes      bool
	}{
		{
			"0",
			args{
				[]int{201, -1, 303, -1, 405, -1, -1, -1, -1, -1, -1, -1, 413},
			},
			[]int{},
			false,
		},

		{
			//判斷大順跟 9-13,應該是大順
			"1",
			args{
				[]int{201, -1, 303, -1, 405, -1, 107, -1, 209, 410, 211, 112, 413},
			},
			[]int{410, 211, 112, 413, 201},
			true,
		},
		{
			"2",
			args{
				[]int{-1, -1, 303, -1, 405, -1, 107, -1, 209, 410, 211, 112, 413},
			},
			[]int{209, 410, 211, 112, 413},
			true,
		},
		{
			//有A-5, 有大順,應該是大順
			"2",
			args{
				[]int{101, 202, 303, 304, 405, -1, 107, -1, -1, 310, 211, 112, 413},
			},
			[]int{310, 211, 112, 413, 101},
			true,
		},
		{
			"3",
			args{
				[]int{-1, 202, 303, 304, 405, -1, 107, 208, -1, 310, 211, 112, 413},
			},
			[]int{},
			false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			gotStraight, gotYes := c.processStraight(tt.args.cardsInOneRow)
			if !reflect.DeepEqual(gotStraight, tt.wantStraight) {
				t.Errorf("processStraight() gotStraight = %v, want %v", gotStraight, tt.wantStraight)
			}
			if gotYes != tt.wantYes {
				t.Errorf("processStraight() gotYes = %v, want %v", gotYes, tt.wantYes)
			}
		})
	}
}

func TestCore_processFlush(t *testing.T) {
	c := &Core{}
	type args struct {
		cards                 []int
		theSameSuitCardAmount []int
	}
	tests := []struct {
		name          string
		args          args
		wantPickCards []int
		wantYes       bool
	}{
		{
			"0",
			args{
				[]int{101, 201, 301, 401, 402, 111, 212},
				[]int{2, 2, 1, 2},
			},
			[]int{},
			false,
		},
		{
			"1",
			args{
				[]int{101, 201, 301, 401, 402, 111, 212, 102, 103, 104},
				[]int{5, 2, 1, 2},
			},
			[]int{102, 103, 104, 111, 101},
			true,
		},
		{
			//兩組同花，取大的
			"2",
			args{
				[]int{101, 201, 301, 401, 402, 111, 212, 102, 103, 104, 213, 202, 203},
				[]int{5, 5, 1, 2},
			},
			[]int{202, 203, 212, 213, 201},
			true,
		},
		{
			//兩組同花，取大的
			"2",
			args{
				[]int{201, 301, 401, 402, 111, 212, 102, 103, 104, 213, 202},
				[]int{4, 4, 1, 2},
			},
			[]int{},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotPickCards, gotYes := c.processFlush(tt.args.cards, tt.args.theSameSuitCardAmount)
			if !reflect.DeepEqual(gotPickCards, tt.wantPickCards) {
				t.Errorf("processFlush() gotPickCards = %v, want %v", gotPickCards, tt.wantPickCards)
			}
			if gotYes != tt.wantYes {
				t.Errorf("processFlush() gotYes = %v, want %v", gotYes, tt.wantYes)
			}
		})
	}
}

func TestCore_processFullHouse(t *testing.T) {
	type args struct {
		cards                []int
		theSameNumCardAmount []int
	}
	tests := []struct {
		name          string
		args          args
		wantPickCards []int
		wantYes       bool
	}{
		{
			"0",
			args{
				[]int{101, 201, 301, 402, 111, 212, 312},
				[]int{3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0},
			},
			[]int{101, 201, 301, 212, 312},
			true,
		},
		{
			"1",
			args{
				[]int{101, 201, 301, 402, 111, 212, 113, 213},
				[]int{3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2},
			},
			[]int{101, 201, 301, 113, 213},
			true,
		},
		{
			"2",
			args{
				[]int{101, 201, 301, 401, 402, 111, 212, 113, 213},
				[]int{4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2},
			},
			[]int{},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			gotPickCards, gotYes := c.processFullHouse(tt.args.cards, tt.args.theSameNumCardAmount)
			if !reflect.DeepEqual(gotPickCards, tt.wantPickCards) {
				t.Errorf("processFullHouse() gotPickCards = %v, want %v", gotPickCards, tt.wantPickCards)
			}
			if gotYes != tt.wantYes {
				t.Errorf("processFullHouse() gotYes = %v, want %v", gotYes, tt.wantYes)
			}
		})
	}
}

func TestCore_processStraightFlush(t *testing.T) {
	c := &Core{}
	c0 := []int{101, 201, 303, 313, 413, 405}
	pm0 := c.createPokerMapWithCards(c0)

	c1 := []int{101, 201, 303, 313, 413, 405, 406, 407, 408, 409}
	pm1 := c.createPokerMapWithCards(c1)

	c2 := []int{401, 101, 201, 303, 313, 410, 411, 412, 413}
	pm2 := c.createPokerMapWithCards(c2)

	c3 := []int{401, 101, 201, 303, 313, 410, 411, 412, 413, 301, 310, 311, 312, 313}
	pm3 := c.createPokerMapWithCards(c3)

	c4 := []int{401, 101, 201, 303, 313, 411, 412, 413, 202, 203, 204, 205}
	pm4 := c.createPokerMapWithCards(c4)

	type args struct {
		pokerMap [][]int
	}
	tests := []struct {
		name         string
		args         args
		wantStraight []int
		wantCardType int
		wantYes      bool
	}{
		{
			"0",
			args{pm0},
			[]int{},
			HighCard,
			false,
		},
		{
			"1",
			args{pm1},
			[]int{405, 406, 407, 408, 409},
			StraightFlush,
			true,
		},
		{
			"2",
			args{pm2},
			[]int{410, 411, 412, 413, 401},
			RoyalFlush,
			true,
		},
		{
			"3",
			args{pm3},
			[]int{410, 411, 412, 413, 401},
			RoyalFlush,
			true,
		},
		{
			"3",
			args{pm4},
			[]int{201, 202, 203, 204, 205},
			StraightFlush,
			true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			gotStraight, gotCardType, gotYes := c.processStraightFlush(tt.args.pokerMap)
			if !reflect.DeepEqual(gotStraight, tt.wantStraight) {
				t.Errorf("processStraightFlush() gotStraight = %v, want %v", gotStraight, tt.wantStraight)
			}
			if gotCardType != tt.wantCardType {
				t.Errorf("processStraightFlush() gotCardType = %v, want %v", gotCardType, tt.wantCardType)
			}
			if gotYes != tt.wantYes {
				t.Errorf("processStraightFlush() gotYes = %v, want %v", gotYes, tt.wantYes)
			}
		})
	}
}
