package core

import (
	"reflect"
	"testing"
)

func TestHoldAndSpinScatterOnlySlot_RTPTest(t *testing.T) {
	bs := &BaseSetting{
		ColumnAndLine: []int{5, 3},
		Symbol:        &BaseSymbol{ScatterID: []int{9}},
	}

	//**************************************************************
	//2600
	//用random index 取 weightTable
	//再random weightTable 取element
	sd := &HoldAndSpinScatterData{
		0,
		[]int{216, 1000},
		[][]int{
			{1396, 2797, 4197, 5397, 6597, 7697, 8792, 9567, 9865, 9965, 9985, 10000},
			{2299, 4600, 6900, 9200, 9350, 9500, 9650, 9800, 9865, 9965, 9985, 10000},
		},
		[]float32{1, 2, 3, 4, 5, 8, 10, 12, 15, 20, 40, 100},
	}

	bd := &BonusData{
		500,
		100,
		40,
		20,
	}

	weightTableIndex := 0

	//normal
	spinData := &HoldAndSpinScatterOnlyData{
		Times:              3,
		ReelIndexLessEqual: []int{2, 99},
		Reel: [][][]int{
			{{9, 5, 8, 7, 5, 0, 0, 0, 5, 3, 7, 5, 6, 1, 8, 7, 2, 5, 0, 0, 0, 6, 1, 8, 7, 2, 5, 3, 0, 0, 0, 1, 8, 7, 2, 5, 3, 0, 0, 0, 1, 8, 7, 2, 5, 0, 0, 0, 2, 1, 8, 7, 2, 5, 3, 0, 0, 0, 5, 6, 1, 8, 7, 2, 5}},
			{{0, 0, 0, 3, 4, 5, 6, 7, 8, 9, 5, 7, 0, 0, 0, 6, 3, 7, 8, 9, 5, 7, 0, 0, 0, 6, 2, 7, 8, 9, 5, 7, 0, 0, 0, 6, 1, 7, 8, 9, 0, 0, 0, 5, 7, 6, 1, 7, 8, 9}},
		},
	}

	//進入holdAndSpin資料
	originalResultReel := [][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}}
	oriScatterExtra := [][]float32{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {1, 1, 1}, {1, 1, 1}}
	originalScatterAmount := 6


	//**************************************************************
	//2700
	//用scatter出現順序取index
	//再用index 取 weightTable，
	//取random 取 element
	//sd := &ScatterData{
	//	1,
	//	[]int{3, 6, 9, 12, 15},
	//	[][]int{
	//		{6000, 8200, 10000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10000},
	//		{3532, 7595, 8660, 8960, 9260, 9460, 9660, 9710, 9760, 9810, 9860, 9910, 9920, 9930, 9940, 9950, 9955, 9960, 9985, 9995, 10000},
	//		{3000, 5900, 7400, 8360, 9060, 9360, 9660, 9710, 9760, 9810, 9860, 9910, 9920, 9930, 9940, 9950, 9955, 9960, 9985, 9995, 10000},
	//		{1600, 3100, 4600, 6100, 7600, 8200, 8800, 9000, 9200, 9300, 9400, 9450, 9500, 9550, 9600, 9650, 9700, 9750, 9870, 9950, 10000},
	//		{1820, 3020, 4220, 5420, 6920, 7570, 8220, 8420, 8670, 8820, 8970, 9070, 9170, 9270, 9370, 9470, 9570, 9670, 9820, 9920, 10000},
	//	},
	//	[]float32{0.8, 1, 1.2, 1.4, 1.6, 1.8, 2, 2.2, 2.4, 2.6, 2.8, 3, 4, 6, 8, 10, 12, 15, 12, 20, 50},
	//}

	//bd := &BonusData{
	//	500,
	//	50,
	//	20,
	//	12,
	//}

	//bet data
	lineBet := 50.0
	lines := 25
	coinValue := 1.0
	betCredit := lineBet * float64(lines) * coinValue

	betTimes := 100
	betTotal := float64(betTimes) * betCredit
	var payCreditSum float64

	game := &HoldAndSpinScatterOnlySlot{}

	for i := 0; i < betTimes; i++ {

		result, err := game.GetHoldAndSpinScatterOnlyResult(bs, spinData, sd, bd, originalResultReel, originalScatterAmount, oriScatterExtra, weightTableIndex, betCredit)

		if err != nil {
			t.Fatalf("GetResult error %s", err)
		}

		payCreditSum += result.PayCreditTotal
	}

	//freeSpinProbability = float64(freeSpinTimes) / float64(betTimes)
	t.Logf("--- BET DATA\n")
	t.Logf("Bet %.0f", betCredit)
	t.Logf("Bet times %d", betTimes)
	t.Logf("--- GAME\n")
	t.Logf("RTP :%.2f%%", (payCreditSum/betTotal)*100)
	t.Logf("Total bet %.0f ", betTotal)
	t.Logf("Payout %.0f ", payCreditSum)

}

func TestHoldAndSpinScatterOnlySlot_GetResult(t *testing.T) {

	bs := &BaseSetting{
		ColumnAndLine: []int{5, 3},
		Symbol:        &BaseSymbol{ScatterID: []int{9}},
	}
	sd := &HoldAndSpinScatterData{
		0,
		[]int{216, 1000},
		[][]int{
			{1396, 2797, 4197, 5397, 6597, 7697, 8792, 9567, 9865, 9965, 9985, 10000},
			{2299, 4600, 6900, 9200, 9350, 9500, 9650, 9800, 9865, 9965, 9985, 10000},
		},
		[]float32{1, 2, 3, 4, 5, 8, 10, 12, 15, 20, 40, 100},
	}
	bd := &BonusData{
		500,
		100,
		40,
		20,
	}

	spinData := &HoldAndSpinScatterOnlyData{
		Times:              3,
		ReelIndexLessEqual: []int{2, 99},
		Reel: [][][]int{
			{{9, 5, 8, 7, 5, 0, 0, 0, 5, 3, 7, 5, 6, 1, 8, 7, 2, 5, 0, 0, 0, 6, 1, 8, 7, 2, 5, 3, 0, 0, 0, 1, 8, 7, 2, 5, 3, 0, 0, 0, 1, 8, 7, 2, 5, 0, 0, 0, 2, 1, 8, 7, 2, 5, 3, 0, 0, 0, 5, 6, 1, 8, 7, 2, 5}},
			{{0, 0, 0, 3, 4, 5, 6, 7, 8, 9, 5, 7, 0, 0, 0, 6, 3, 7, 8, 9, 5, 7, 0, 0, 0, 6, 2, 7, 8, 9, 5, 7, 0, 0, 0, 6, 1, 7, 8, 9, 0, 0, 0, 5, 7, 6, 1, 7, 8, 9}},
		},
	}

	oriResultReel := [][]int{{9, 1, 1}, {9, 1, 1}, {1, 9, 1}, {9, 9, 1}, {9, 1, 1}}
	oriScatterAmount := 6
	oriScatterExtra := [][]float32{{1, -1, -1}, {1, -1, -1}, {-1, 1, -1}, {1, 1, -1}, {1, -1, -1}}

	type fields struct {
		BaseSlot Core
	}
	type args struct {
		setting                 *BaseSetting
		spinData                *HoldAndSpinScatterOnlyData
		scatterData             *HoldAndSpinScatterData
		bonusData               *BonusData
		originalResultReel      [][]int
		oriScatterAmount        int
		oriScatterExtra         [][]float32
		scatterWeightTableIndex int
		betCredit               float64
	}
	tests := []struct {
		name       string
		fields     fields
		args       args
		wantCredit float64
		wantErr    bool
	}{
		{
			"0",
			fields{BaseSlot: Core{}},
			args{
				bs,
				spinData,
				sd,
				bd,
				oriResultReel,
				oriScatterAmount,
				oriScatterExtra,
				0,
				1250.0,
			},
			7500,
			false,
		},
		{
			"1",
			fields{BaseSlot: Core{}},
			args{
				bs,
				spinData,
				sd,
				bd,
				[][]int{{9, 9, 9}, {1, 9, 9}, {9, 1, 1}, {1, 1, 1}, {9, 1, 1}},
				7,
				[][]float32{{1, 1, 1}, {-1, 1, 1}, {1, -1, -1}, {-1, -1, -1}, {2, -1, -1}},
				1,
				1250.0,
			},
			10000,
			false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &HoldAndSpinScatterOnlySlot{
				Core: tt.fields.BaseSlot,
			}
			gotRet, err := g.GetHoldAndSpinScatterOnlyResult(tt.args.setting, tt.args.spinData, tt.args.scatterData, tt.args.bonusData, tt.args.originalResultReel, tt.args.oriScatterAmount, tt.args.oriScatterExtra, tt.args.scatterWeightTableIndex, tt.args.betCredit)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetResult() error = %v, wantErr %+v", err, tt.wantErr)
				return
			}
			t.Logf("PayCreditTotal %.2f", gotRet.PayCreditTotal)
			//if !reflect.DeepEqual(gotRet.PayCreditTotal, tt.wantCredit) {
			//	t.Errorf("GetResult() gotRet = %+v, want %+v", gotRet, tt.wantCredit)
			//}
		})
	}
}

func TestHoldAndSpinScatterOnlySlot_RandomScatterMultiplier(t *testing.T) {

	hs := &HoldAndSpinScatterOnlySlot{}
	type args struct {
		weightTable  []int
		elementTable []float32
	}
	tests := []struct {
		name    string
		args    args
		want    float32
		wantErr bool
	}{
		{
			"0",
			args{
				[]int{100, 101},
				[]float32{1, 2},
			},
			1,
			false,
		},
		{
			"1",
			args{
				[]int{100, 100},
				[]float32{2, 1},
			},
			2,
			false,
		},
		{
			"2",
			args{
				[]int{100, 100},
				[]float32{2, 1, 2},
			},
			-1,
			true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := hs.RandomScatterMultiplier(tt.args.weightTable, tt.args.elementTable)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetElementByWeightTable() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("GetElementByWeightTable() got = %v, want %v", got, tt.want)
			}
		})
	}
}

/*
func TestHoldAndSpinScatterOnlySlot_getResultInner(t *testing.T) {
	bs := &BaseSetting{
		ColumnAndLine: []int{5, 3},
		Symbol:        &BaseSymbol{ScatterID: []int{9}},
	}

	type fields struct {
		BaseSlot BaseSlot
	}
	type args struct {
		setting               *BaseSetting
		freeSpinData          *HoldAndSpinData
		spinTimes             int
		result                *HoldAndSpinResult
		originalResultReel    [][]int
		originalScatterAmount int
		oriScatterExtra       [][]int
		scatterWeightTable    []int
		scatterElementTable   []int
		betCredit             float64
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantRet *HoldAndSpinResult
		wantErr bool
	}{
		{
			//using another reel
			"0",
			fields{
				BaseSlot{},
			},
			args{
				bs,
				&HoldAndSpinData{
					500,
					3,
					&HoldAndSpinReelData{
						2,
						[][]int{{1}},
						[][]int{{1}},
					},
				},
				1,
				&HoldAndSpinResult{},
				[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
				6,
				[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
				[]int{1, 10000},
				[]int{1, 2},
				1250,
			},
			&HoldAndSpinResult{
				7500,
				[]*HoldAndSpinResultInner{
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
						6,
						[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
					},
				},
			},
			false,
		},
		{
			//using another reel
			"1",
			fields{
				BaseSlot{},
			},
			args{
				bs,
				&HoldAndSpinData{
					500,
					3,
					&HoldAndSpinReelData{
						2,
						[][]int{{1}},
						[][]int{{2}},
					},
				},
				1,
				&HoldAndSpinResult{},
				[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
				6,
				[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
				[]int{1, 10000},
				[]int{1, 2},
				1250,
			},
			&HoldAndSpinResult{
				7500,
				[]*HoldAndSpinResultInner{
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {2, 2, 2}, {2, 2, 2}, {2, 2, 2}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
						6,
						[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
					},
				},
			},
			false,
		},
		{
			//spin times =0
			"2",
			fields{
				BaseSlot{},
			},
			args{
				bs,
				&HoldAndSpinData{
					500,
					3,
					&HoldAndSpinReelData{
						2,
						[][]int{{1}},
						[][]int{{2}},
					},
				},
				0,
				&HoldAndSpinResult{
					7500,
					[]*HoldAndSpinResultInner{
						{
							0,
							[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
							[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
							6,
							[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
						},
					},
				},
				[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
				6,
				[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
				[]int{1, 10000},
				[]int{1, 2},
				1250,
			},
			&HoldAndSpinResult{
				7500,
				[]*HoldAndSpinResultInner{
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
						6,
						[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
					},
				},
			},
			false,
		},
		{
			//scatter amount 15
			"3",
			fields{
				BaseSlot{},
			},
			args{
				bs,
				&HoldAndSpinData{
					500,
					3,
					&HoldAndSpinReelData{
						2,
						[][]int{{1}},
						[][]int{{9}},
					},
				},
				1,
				&HoldAndSpinResult{
					7500,
					[]*HoldAndSpinResultInner{
						{
							0,
							[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
							[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
							6,
							[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
						},
					},
				},
				[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
				6,
				[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
				[]int{1, 10000},
				[]int{1, 1},
				1250,
			},
			&HoldAndSpinResult{
				643750,
				[]*HoldAndSpinResultInner{
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
						6,
						[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
					},
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
						15,
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
					},
				},
			},
			false,
		},
		{
			//scatter amount 13
			"4",
			fields{
				BaseSlot{},
			},
			args{
				bs,
				&HoldAndSpinData{
					500,
					3,
					&HoldAndSpinReelData{
						2,
						[][]int{{1}},
						[][]int{{9}},
					},
				},
				3,
				&HoldAndSpinResult{
					16250,
					[]*HoldAndSpinResultInner{
						{
							0,
							[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 1, 1}},
							[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
							13,
							[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
						},
					},
				},
				[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 1, 1}},
				13,
				[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
				[]int{1, 10000},
				[]int{1, 2},
				1250,
			},
			&HoldAndSpinResult{
				16250,
				[]*HoldAndSpinResultInner{
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 1, 1}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
						13,
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
					},
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 1, 1}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
						13,
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
					},
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 1, 1}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
						13,
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
					},
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 1, 1}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
						13,
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
					},
				},
			},
			false,
		},
		{
			//scatter 15 中 grand
			"5",
			fields{
				BaseSlot{},
			},
			args{
				bs,
				&HoldAndSpinData{
					500,
					3,
					&HoldAndSpinReelData{
						2,
						[][]int{{9}},
						[][]int{{1}},
					},
				},
				1,
				&HoldAndSpinResult{},
				[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 1, 1}},
				13,
				[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, -1, -1}},
				[]int{1, 10000},
				[]int{1, 2},
				1250,
			},
			&HoldAndSpinResult{
				646250,
				[]*HoldAndSpinResultInner{
					{
						0,
						[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}},
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
						15,
						[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 2, 2}},
					},
				},
			},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &HoldAndSpinScatterOnlySlot{
				BaseSlot: tt.fields.BaseSlot,
			}
			gotRet, err := g.getResultInner(tt.args.setting, tt.args.freeSpinData, tt.args.spinTimes, tt.args.result, tt.args.originalResultReel, tt.args.originalScatterAmount, tt.args.oriScatterExtra, tt.args.scatterWeightTable, tt.args.scatterElementTable, tt.args.betCredit)
			if (err != nil) != tt.wantErr {
				t.Errorf("getResultInner() error = %v, wantErr %v", err, tt.wantErr)
				return
			}

			if gotRet == nil {
				t.Errorf("getResultInner() error got nil")
				return
			}

			if !reflect.DeepEqual(gotRet, tt.wantRet) {
				t.Errorf("getResultInner() gotRet = %+v\n", gotRet)
				t.Errorf("getResultInner() gotRet = %+v\n", gotRet.Result[len(gotRet.Result)-1])
				t.Errorf("getResultInner()   want = %+v", tt.wantRet)
				t.Errorf("getResultInner()   want = %+v", tt.wantRet.Result[len(tt.wantRet.Result)-1])
			}
		})
	}
}


func TestHoldAndSpinScatterOnlySlot_getResultOnce(t *testing.T) {
	bs := &BaseSetting{
		ColumnAndLine: []int{5, 3},
		Symbol:        &BaseSymbol{ScatterID: []int{9}},
	}

	type fields struct {
		BaseSlot BaseSlot
	}
	type args struct {
		setting             *BaseSetting
		originalResultReel  [][]int
		reel                [][]int
		oriScatterExtra     [][]int
		scatterWeightTable  []int
		scatterElementTable []int
		betCredit           float64
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantRet *HoldAndSpinResultInner
		wantErr bool
	}{
		{
			"0",
			fields{
				BaseSlot{},
			},
			args{
				bs,
				[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
				[][]int{{9}},
				[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
				[]int{1, 10000},
				[]int{1, 2},
				25.0,
			},
			&HoldAndSpinResultInner{
				0,
				[][]int{{9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}, {9, 9, 9}},
				[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
				15,
				[][]int{{1, 1, 1}, {1, 1, 1}, {2, 2, 2}, {2, 2, 2}, {2, 2, 2}},
			},
			false,
		},
		{
			"1",
			fields{
				BaseSlot{},
			},
			args{
				bs,
				[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
				[][]int{{1}},
				[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
				[]int{1, 10000},
				[]int{1, 2},
				25.0,
			},
			&HoldAndSpinResultInner{
				0,
				[][]int{{9, 9, 9}, {9, 9, 9}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
				[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
				6,
				[][]int{{1, 1, 1}, {1, 1, 1}, {-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}},
			},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &HoldAndSpinScatterOnlySlot{
				BaseSlot: tt.fields.BaseSlot,
			}
			gotRet, err := g.getResultOnce(tt.args.setting, tt.args.originalResultReel, tt.args.reel, tt.args.oriScatterExtra, tt.args.scatterWeightTable, tt.args.scatterElementTable, tt.args.betCredit)
			if (err != nil) != tt.wantErr {
				t.Errorf("getResultOnce() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotRet, tt.wantRet) {
				t.Errorf("getResultOnce() gotRet = %+v, want %+v", gotRet, tt.wantRet)
			}
		})
	}
}

func TestHoldAndSpinScatterOnlySlot_countCredit(t *testing.T) {

	type fields struct {
		BaseSlot BaseSlot
	}
	type args struct {
		scatterExtra [][]int
		betCredit    float64
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   float64
	}{
		{
			"0",
			fields{BaseSlot: BaseSlot{}},
			args{
				[][]int{{1, 1, 1}, {2, 2, 2}},
				10.0,
			},
			90.0,
		},
		{
			"1",
			fields{BaseSlot: BaseSlot{}},
			args{
				[][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}},
				11.0,
			},
			198.0,
		},
		{
			"2",
			fields{BaseSlot: BaseSlot{}},
			args{
				[][]int{{1, 1, 1}, {1, 1, 1}, {2, 2, 2}, {2, 2, 2}, {2, -1, -1}},
				1250,
			},
			25000,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &HoldAndSpinScatterOnlySlot{
				BaseSlot: tt.fields.BaseSlot,
			}
			if got := g.countCredit(tt.args.scatterExtra, tt.args.betCredit); got != tt.want {
				t.Errorf("countCredit() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestHoldAndSpinScatterOnlySlot_insertScatterExtra(t *testing.T) {
	type fields struct {
		BaseSlot BaseSlot
	}
	type args struct {
		scatterID           []int
		oriResultReel       [][]int
		resultReel          [][]int
		oriScatterExtra     [][]int
		scatterWeightTable  []int
		scatterElementTable []int
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   [][]int
	}{
		{
			"0",
			fields{
				BaseSlot{},
			},
			args{
				[]int{9},
				[][]int{{1, 1, 2}, {1, 9, 9}, {1, 1, 9}, {1, 1, 9}, {1, 1, 9}},
				[][]int{{1, 1, 2}, {1, 9, 9}, {1, 9, 9}, {1, 9, 9}, {1, 9, 9}},
				[][]int{{-1, -1, 1}, {-1, 1, 1}, {-1, -1, 1}, {-1, -1, 1}, {-1, -1, 1}},
				[]int{1, 10000},
				[]int{1, 2},
			},
			[][]int{{-1, -1, 1}, {-1, 1, 1}, {-1, 2, 1}, {-1, 2, 1}, {-1, 2, 1}},
		},
		{
			"1",
			fields{
				BaseSlot{},
			},
			args{
				[]int{9},
				[][]int{{1, 9, 9}, {1, 1, 9}, {1, 1, 9}, {1, 1, 9}, {1, 1, 9}},
				[][]int{{1, 9, 9}, {1, 1, 9}, {1, 9, 9}, {1, 1, 9}, {1, 9, 9}},
				[][]int{{-1, 1, 1}, {-1, -1, 1}, {-1, -1, 1}, {-1, -1, 1}, {-1, -1, 1}},
				[]int{1, 2, 10000},
				[]int{1, 2, 3},
			},
			[][]int{{-1, 1, 1}, {-1, -1, 1}, {-1, 3, 1}, {-1, -1, 1}, {-1, 3, 1}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &HoldAndSpinScatterOnlySlot{
				BaseSlot: tt.fields.BaseSlot,
			}
			if got := g.insertScatterExtra(tt.args.scatterID, tt.args.oriResultReel, tt.args.resultReel, tt.args.oriScatterExtra, tt.args.scatterWeightTable, tt.args.scatterElementTable); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("insertScatterExtra() = %v, want %v", got, tt.want)
			}
		})
	}
}
*/

func TestHoldAndSpinScatterOnlySlot_InsertScatterExtraDataByWeightTable(t *testing.T) {
	oriScatterExtra := [][]float32{{1, -1, -1}, {1, -1, -1}, {-1, 1, -1}, {1, 1, -1}, {1, -1, -1}}
	elementLocation := [][]int{{0, 1}, {1, 1}, {4, 2}}

	weightTable := []int{
		1, 10000,
	}
	elementTable := []float32{2, 2}

	type fields struct {
		BaseSlot Core
	}
	type args struct {
		oriScatterExtra [][]float32
		elementLocation [][]int
		weightTable     []int
		elementTable    []float32
	}
	tests := []struct {
		name       string
		fields     fields
		args       args
		wantRetAry [][]float32
	}{
		{
			"0",
			fields{
				BaseSlot: Core{},
			},
			args{oriScatterExtra,
				elementLocation,
				weightTable,
				elementTable,
			},
			[][]float32{{1, 2, -1}, {1, 2, -1}, {-1, 1, -1}, {1, 1, -1}, {1, -1, 2}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &HoldAndSpinScatterOnlySlot{
				Core: tt.fields.BaseSlot,
			}
			if gotRetAry := g.InsertScatterExtraDataByWeightTable(tt.args.oriScatterExtra, tt.args.elementLocation, tt.args.weightTable, tt.args.elementTable); !reflect.DeepEqual(gotRetAry, tt.wantRetAry) {
				t.Errorf("InsertScatterExtraDataByWeightTable() = %v, want %v", gotRetAry, tt.wantRetAry)
			}
		})
	}
}

func TestHoldAndSpinScatterOnlySlot_InsertScatterExtraDataByScatterSequence(t *testing.T) {

	//sd := &ScatterData{
	//	1,
	//	[]int{3, 6, 9, 12, 15},
	//	[][]int{
	//		{6000, 8200, 10000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10000},
	//		{3532, 7595, 8660, 8960, 9260, 9460, 9660, 9710, 9760, 9810, 9860, 9910, 9920, 9930, 9940, 9950, 9955, 9960, 9985, 9995, 10000},
	//		{3000, 5900, 7400, 8360, 9060, 9360, 9660, 9710, 9760, 9810, 9860, 9910, 9920, 9930, 9940, 9950, 9955, 9960, 9985, 9995, 10000},
	//		{1600, 3100, 4600, 6100, 7600, 8200, 8800, 9000, 9200, 9300, 9400, 9450, 9500, 9550, 9600, 9650, 9700, 9750, 9870, 9950, 10000},
	//		{1820, 3020, 4220, 5420, 6920, 7570, 8220, 8420, 8670, 8820, 8970, 9070, 9170, 9270, 9370, 9470, 9570, 9670, 9820, 9920, 10000},
	//	},
	//	[]float32{0.8, 1, 1.2, 1.4, 1.6, 1.8, 2, 2.2, 2.4, 2.6, 2.8, 3, 4, 6, 8, 10, 12, 15, 12, 20, 50},
	//}

	sd := &HoldAndSpinScatterData{
		1,
		[]int{15},
		[][]int{
			{10000},
		},
		[]float32{0.8},
	}

	oriScatterExtra := [][]float32{{1, -1, -1}, {1, -1, -1}, {-1, 1, -1}, {1, 1, -1}, {1, -1, -1}}
	elementLocation := [][]int{{0, 1}, {4, 1}}

	type fields struct {
		BaseSlot Core
	}
	type args struct {
		scData           *HoldAndSpinScatterData
		oriExtra         [][]float32
		oriScatterAmount int
		elementLocation  [][]int
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   [][]float32
	}{
		{
			"0",
			fields{
				BaseSlot: Core{},
			},
			args{
				sd,
				oriScatterExtra,
				6,
				elementLocation,
			},
			[][]float32{{1, 0.8, -1}, {1, -1, -1}, {-1, 1, -1}, {1, 1, -1}, {1, 0.8, -1}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &HoldAndSpinScatterOnlySlot{
				Core: tt.fields.BaseSlot,
			}
			if got := g.InsertScatterExtraDataByScatterSequence(tt.args.scData, tt.args.oriExtra, tt.args.oriScatterAmount, tt.args.elementLocation); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("InsertScatterExtraDataByScatterSequence() = %v, want %v", got, tt.want)
			}
		})
	}
}
