package core

import (
	"fmt"

	"github.com/idtksrv/simulator-server/internal/configuration"
	"github.com/idtksrv/simulator-server/internal/util"
	"github.com/idtksrv/simulator-server/internal/util/rand"
	"github.com/idtksrv/simulator-server/internal/util/slice"
	"github.com/shopspring/decimal"
)

type HoldAndSpinResult struct {
	PayCreditTotal float64                   `json:"pay_credit_total"`
	Result         []*HoldAndSpinResultInner `json:"result"`
	SpinTimes      int                       `json:"spin_times"` //進入 free spin, 總共 spin 幾次
}

type HoldAndSpinResultInner struct {
	PayCredit       float64     `json:"pay_credit"`
	GameResult      [][]int     `json:"game_result"`
	ScatterPosition [][]int     `json:"scatter_position"`
	ScatterAmount   int         `json:"scatter_amount"`
	ScatterExtra    [][]float32 `json:"scatter_extra"` //scatter extra info, 	倍率
}

type HoldAndSpinScatterData struct {
	WeightTableMode           int //0=random決定table, 1=scatter出現順序決定table
	WeightTableIndexLessEqual []int
	WeightTable               [][]int
	Element                   []float32
}
type HoldAndSpinScatterOnlyData struct {
	Times              int
	ReelIndexLessEqual []int
	Reel               [][][]int
	CountCreditMode    int //算錢模式，0=最後結算一次。1=每次中scatter, 就全部加總一次
}

type HoldAndSpinScatterOnlySlot struct {
	Core
}

// GetHoldAndSpinScatterOnlyResult  return hold and spin slot result
func (g *HoldAndSpinScatterOnlySlot) GetHoldAndSpinScatterOnlyResult(setting *BaseSetting, spinData *HoldAndSpinScatterOnlyData, scData *HoldAndSpinScatterData, bonusData *BonusData, originalResultReel [][]int, originalScatterAmount int, oriScatterExtra [][]float32, oriScatterWeightTableIndex int, betCredit float64) (retResult *HoldAndSpinResult, retErr error) {
	logFunc := "GetResult "

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	oriResult := &HoldAndSpinResult{}

	return g.getResultInner(setting, spinData, scData, bonusData, spinData.Times, oriResult, originalResultReel, originalScatterAmount, oriScatterExtra, oriScatterWeightTableIndex, betCredit, 0)

}

// getResultInner
// 算錢方式有兩種， 一種是最後結算一次，一種是每中一次scatter算一次，
// payoutSum 是每次算錢的總金額
// spinTimesSum 本次 free spin, 內部總共 spin 多少次
func (g *HoldAndSpinScatterOnlySlot) getResultInner(setting *BaseSetting, spinData *HoldAndSpinScatterOnlyData, scData *HoldAndSpinScatterData, bonusData *BonusData, spinTimes int, result *HoldAndSpinResult, originalResultReel [][]int, originalScatterAmount int, oriScatterExtra [][]float32, oriScatterWeightTableIndex int, betCredit float64, spinTimesSum int) (ret *HoldAndSpinResult, retErr error) {
	logFunc := "getResultInner "

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("HoldAndSpinScatterOnlySlot %s panic %s", logFunc, r)
		}
	}()

	if spinTimes < 1 {
		return result, nil
	}

	spinTimesSum++
	spinTimes--

	//算spot amount
	leftSpotAmount := g.CountLeftSpotAmount(setting.ColumnAndLine, originalScatterAmount)

	reel := g.getReel(spinData, leftSpotAmount)

	retOnce, _ := g.getResultOnce(setting, originalResultReel, reel, oriScatterExtra, originalScatterAmount, oriScatterWeightTableIndex, scData, scData.WeightTableMode)

	result.Result = append(result.Result, retOnce)

	//重算一次spot amount
	leftSpotAmount = g.CountLeftSpotAmount(setting.ColumnAndLine, retOnce.ScatterAmount)

	//有新的scatter
	if retOnce.ScatterAmount > originalScatterAmount {
		spinTimes = spinData.Times

		//countCreditMode 是每次有 new scatter 算錢
		if spinData.CountCreditMode == configuration.HoldAndSpinScatterOnlyCountCreditModeAccumulate {
			credit := g.countCredit(retOnce.ScatterExtra, betCredit)
			retOnce.PayCredit = credit
			result.PayCreditTotal, _ = decimal.NewFromFloat(result.PayCreditTotal).Add(decimal.NewFromFloat(credit)).Float64()
		}

		//spot滿了 simulator會rerun
		if leftSpotAmount == 0 {

			if spinData.CountCreditMode == configuration.HoldAndSpinScatterOnlyCountCreditModeAccumulate {
				//
			} else if spinData.CountCreditMode == configuration.HoldAndSpinScatterOnlyCountCreditModeFinalCount {
				//如果是最後總結的算錢模式
				credit := g.countCredit(result.Result[len(result.Result)-1].ScatterExtra, betCredit)
				result.PayCreditTotal = credit
			} else {
				//error
			}

			grandCredit, _ := decimal.NewFromFloat(betCredit).Mul(decimal.NewFromFloat(float64(bonusData.GrandPayRate))).Float64()
			result.PayCreditTotal, _ = decimal.NewFromFloat(result.PayCreditTotal).Add(decimal.NewFromFloat(grandCredit)).Float64()
			return result, nil
		}
	}

	if spinTimes > 0 {
		resultReel := slice.Duplicate2DSlice(retOnce.GameResult)
		scatterExtra := slice.Duplicate2DFloatSlice(retOnce.ScatterExtra)
		return g.getResultInner(setting, spinData, scData, bonusData, spinTimes, result, resultReel, retOnce.ScatterAmount, scatterExtra, oriScatterWeightTableIndex, betCredit, spinTimesSum)
	}

	//補上 spinTimesSum
	result.SpinTimes = spinTimesSum

	//最後 count credit
	//都沒出 new scatter，第一次進來的scatter 要算錢
	if spinData.CountCreditMode == configuration.HoldAndSpinScatterOnlyCountCreditModeAccumulate {
		if result.PayCreditTotal == 0 {
			credit := g.countCredit(result.Result[len(result.Result)-1].ScatterExtra, betCredit)
			result.PayCreditTotal, _ = decimal.NewFromFloat(credit).Float64()
		}
	} else if spinData.CountCreditMode == configuration.HoldAndSpinScatterOnlyCountCreditModeFinalCount {
		//取最後一個 result, 就是全部的 scatterExtra
		credit := g.countCredit(result.Result[len(result.Result)-1].ScatterExtra, betCredit)
		//補上 credit
		result.PayCreditTotal = credit
	} else {
		//error
	}

	return result, nil
}

func (g *HoldAndSpinScatterOnlySlot) getResultOnce(setting *BaseSetting, originalResultReel [][]int, reel [][]int, originalScatterExtra [][]float32, originalScatterAmount, originalScatterWeightTableIndex int, scData *HoldAndSpinScatterData, scatterWeightTableMode int) (ret *HoldAndSpinResultInner, retErr error) {
	logFunc := "getResultOnce"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	//從reel, 取獨立輪
	gameResultReel, err := g.Core.GetGameResultReelRandomPerWheel(reel, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	var scatterExtra [][]float32

	scatterWeightTable := scData.WeightTable[originalScatterWeightTableIndex]

	//對比orl result, 找出new result 新的scatter位置
	//newScatterLoc := slice.GetTargetNewElementLocation(setting.Symbol.ScatterID, originalResultReel, gameResultReel)
	//loc := slice.Duplicate2DSlice(newScatterLoc)

	_, newScatterPos, _ := g.Core.CountTargetNewSymbolPosition(originalResultReel, gameResultReel, setting.Symbol.ScatterID)

	//random 方式取 scatter extra，補上 scatter extra
	if scatterWeightTableMode == configuration.ScatterWeightTableModeRandom {
		//scatterExtra = g.insertScatterExtraByRandom(newScatterPos, originalScatterExtra, scatterWeightTable, scData.Element)
		scatterExtra = g.InsertScatterExtraDataByWeightTable(originalScatterExtra, newScatterPos, scatterWeightTable, scData.Element)

	} else if scatterWeightTableMode == configuration.ScatterWeightTableModeSequence {
		//scatter sequence 方式取 extra
		scatterExtra = g.InsertScatterExtraDataByScatterSequence(scData, originalScatterExtra, originalScatterAmount, newScatterPos)
	} else {
		retErr = fmt.Errorf("%s scatterWeightTableMode error got %d", logFunc, scatterWeightTableMode)
		return
	}

	//新的scatter，補到原本的result
	gameResultReel, err = util.CopySpecifyElement(originalResultReel, gameResultReel, setting.Symbol.ScatterID)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	//重抓一次 scatter info
	scatterAmount, scatterPosition, _, err := g.CountSymbolInfo(gameResultReel, setting.Symbol.ScatterID, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	return &HoldAndSpinResultInner{
		0, //最後算一次就好，不然會重複
		gameResultReel,
		scatterPosition,
		scatterAmount,
		scatterExtra,
	}, nil
}

func (g *HoldAndSpinScatterOnlySlot) countCredit(scatterExtra [][]float32, betCredit float64) float64 {

	var credit, totalCredit decimal.Decimal

	for i := range scatterExtra {
		for j := range scatterExtra[i] {
			v := scatterExtra[i][j]
			if v != configuration.SymbolIDNotUse {
				credit = decimal.NewFromFloat32(v).Mul(decimal.NewFromFloat(betCredit))
				totalCredit = totalCredit.Add(credit)
			}
		}
	}
	c, _ := totalCredit.Float64()
	return c
}

// RandomScatterMultiplier
// weightTable []int 是一個權重表，例如 2299,2301,2300,2300,150,150,150,150,65,100,20,15= 總和10000
// elementTable []int 是index對應 weightTable 的element
func (g *HoldAndSpinScatterOnlySlot) RandomScatterMultiplier(weightTable []int, elementTable []float32) (float32, error) {

	wLen := len(weightTable)
	eLen := len(elementTable)
	if wLen != eLen {
		return -1, fmt.Errorf("weight table length not match element length")
	}

	ran := rand.Intn(weightTable[wLen-1]) + 1

	for i := range weightTable {
		if weightTable[i] >= ran {
			return elementTable[i], nil
		}
	}

	return -1, fmt.Errorf("element not found")
}

// InsertScatterExtraDataByWeightTable
// 例如算好的 scatter position 再生出一個對應位置的資料
// 從elementTable取資料
// 用weightTable random 決定取哪個 element
// scatterPosition 格式 [][]int{{1,1,1},{1,-1,-1},{1,-1,-1},{-1,-1,-1},{-1,-1,-1}} 1=有，-1=沒有
func (g *HoldAndSpinScatterOnlySlot) InsertScatterExtraDataByWeightTable(oriScatterExtra [][]float32, newScatterPosition [][]int, weightTable []int, elementTable []float32) (retAry [][]float32) {
	defer func() {
		if r := recover(); r != nil {
			fmt.Printf("panic %s", r)
		}
	}()
	retAry = slice.Duplicate2DFloatSlice(oriScatterExtra)
	for i, ary := range newScatterPosition {
		for j, has := range ary {
			if has == configuration.SymbolIDHas {
				e, _ := g.RandomScatterMultiplier(weightTable, elementTable)
				retAry[i][j] = e
			}
		}

	}
	return
}

// InsertScatterExtraDataByScatterSequence
// 例如算好的 scatter position 再生出一個對應位置的資料
// 用 scatter 出現的順序取 weightTable
// 再用weightTable random 決定取哪個 element
func (g *HoldAndSpinScatterOnlySlot) InsertScatterExtraDataByScatterSequence(scData *HoldAndSpinScatterData, oriScatterExtra [][]float32, oriScatterAmount int, newScatterPosition [][]int) (retAry [][]float32) {

	defer func() {
		if r := recover(); r != nil {
			fmt.Printf("panic %s", r)
		}
	}()

	n := 0
	retAry = slice.Duplicate2DFloatSlice(oriScatterExtra)
	for i := range newScatterPosition {
		for j := range newScatterPosition[i] {
			if newScatterPosition[i][j] == configuration.SymbolIDHas {
				n++ //每找到一個新的，數量+1
				idx, _ := g.getIndexBySpecificNumberOfScatterWeightTable(oriScatterAmount+n, scData.WeightTableIndexLessEqual)
				ele, _ := g.RandomScatterMultiplier(scData.WeightTable[idx], scData.Element)
				retAry[i][j] = ele
			}
		}
	}
	return retAry
}

func (g *HoldAndSpinScatterOnlySlot) getReel(holdAndSpinData *HoldAndSpinScatterOnlyData, leftSpotAmount int) [][]int {

	for i := range holdAndSpinData.ReelIndexLessEqual {

		if leftSpotAmount <= holdAndSpinData.ReelIndexLessEqual[i] {
			return holdAndSpinData.Reel[i]
		}
	}
	return holdAndSpinData.Reel[0]

}

// getIndexBySpecificNumberOfWeightTable
// specificNum 是用來取 index 的基礎
// table 用來跟 targetNum 比較
// specificNum=0, table=[2,5,10]，則 index 返回 =0
// specificNum=3, table=[2,5,10]，則 index 返回 =1
func (g *HoldAndSpinScatterOnlySlot) getIndexBySpecificNumberOfScatterWeightTable(specificNum int, table []int) (int, error) {

	le := len(table)
	if table[le-1] < specificNum {
		return -1, fmt.Errorf("index max number less then target number")
	}

	for i := 0; i < le; i++ {
		if specificNum <= table[i] {
			return i, nil
		}
	}

	return -1, fmt.Errorf("targetNum out of range")
}
