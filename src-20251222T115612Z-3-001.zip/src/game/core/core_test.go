package core

import (
	"reflect"
	"testing"
)

func TestCore_GetBaseResult(t *testing.T) {

	bs := &BaseSetting{
		[]int{3, 5},
		[]int{3, 5},
		&BaseSymbol{[]int{0}, []int{9}, []int{1, 2, 3, 4, 5, 6, 7, 8, 9}},
		3,
		[][]int{{1, 2, 3}, {1, 2, 3}, {1, 2, 3}, {1, 2, 3}, {1, 2, 3}},
		[][]int{
			{1, 1, 1, 1, 1},
			{0, 0, 0, 0, 0},
			{2, 2, 2, 2, 2},
			{0, 1, 2, 1, 0},
			{2, 1, 0, 1, 2},

			{0, 1, 1, 1, 0},
			{2, 1, 1, 1, 2},
			{1, 0, 0, 0, 1},
			{1, 2, 2, 2, 1},
			{0, 0, 1, 2, 2},

			{2, 2, 1, 0, 0},
			{1, 0, 1, 2, 1},
			{1, 2, 1, 0, 1},
			{0, 1, 0, 1, 0},
			{2, 1, 2, 1, 2},

			{1, 1, 0, 1, 1},
			{1, 1, 2, 1, 1},
			{0, 0, 2, 0, 0},
			{2, 2, 0, 2, 2},
			{1, 0, 2, 0, 1},
		},
		[]*BasePayTable{
			{
				1,
				[]float64{0, 0, 0, 200, 1000, 5000},
			},
			{
				2,
				[]float64{0, 0, 0, 100, 500, 1000},
			},
			{
				3,
				[]float64{0, 0, 0, 50, 200, 500},
			},
			{
				4,
				[]float64{0, 0, 0, 10, 50, 100},
			},
			{
				5,
				[]float64{0, 0, 0, 10, 50, 100},
			},
			{
				6,
				[]float64{0, 0, 0, 5, 25, 50},
			},
			{
				7,
				[]float64{0, 0, 0, 5, 20, 50},
			},
			{
				8,
				[]float64{0, 0, 0, 0, 2, 10},
			},
		},
	}

	type args struct {
		setting    *BaseSetting
		resultReel [][]int
		lineBet    float64
		lines      int
		coinValue  float64
		betCredit  float64
	}
	tests := []struct {
		name          string
		args          args
		wantRetResult *BaseResult
		wantErr       bool
	}{
		{
			"0", args{
				bs,
				[][]int{{1, 2, 3}, {1, 2, 3}, {1, 2, 3}, {1, 2, 3}, {1, 2, 3}},
				1,
				10,
				1,
				10,
			},
			&BaseResult{},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			gotRetResult, err := c.GetBaseResult(tt.args.setting, tt.args.resultReel, tt.args.lineBet, tt.args.lines, tt.args.coinValue, tt.args.betCredit)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetBaseResult() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			t.Logf("%v", gotRetResult.GameResult)

			if !reflect.DeepEqual(gotRetResult, tt.wantRetResult) {
				t.Errorf("GetBaseResult() gotRetResult = %v, want %v", gotRetResult, tt.wantRetResult)
			}
		})
	}
}

func TestCore_CountSymbolPayout(t *testing.T) {

	bt := []*BasePayTable{
		{
			1,
			[]float64{0, 0, 0, 200, 1000, 5000},
		},
		{
			2,
			[]float64{0, 0, 0, 100, 500, 1000},
		},
		{
			3,
			[]float64{0, 0, 0, 50, 200, 500},
		},
		{
			4,
			[]float64{0, 0, 0, 10, 50, 100},
		},
		{
			5,
			[]float64{0, 0, 0, 10, 50, 100},
		},
		{
			6,
			[]float64{0, 0, 0, 5, 25, 50},
		},
		{
			7,
			[]float64{0, 0, 0, 5, 20, 50},
		},
		{
			8,
			[]float64{0, 0, 0, 0, 2, 10},
		},
		{
			9,
			[]float64{0, 0, 0, 2, 10, 50},
		},
	}

	type args struct {
		symbolID     int
		symbolAmount int
		payTable     []*BasePayTable
		multiplier   float64
		baseCredit   float64
	}
	tests := []struct {
		name        string
		args        args
		wantPayout  float64
		wantPayRate float64
	}{
		{
			"0",
			args{
				10,
				3,
				bt,
				1,
				10,
			},
			0,
			0,
		},
		{
			"0",
			args{
				9,
				3,
				bt,
				1,
				1000,
			},
			2000,
			2,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			gotPayout, gotPayRate := c.CountSymbolPayout(tt.args.symbolID, tt.args.symbolAmount, tt.args.payTable, tt.args.multiplier, tt.args.baseCredit)
			if gotPayout != tt.wantPayout {
				t.Errorf("CountSymbolPayout() gotPayout = %v, want %v", gotPayout, tt.wantPayout)
			}
			if gotPayRate != tt.wantPayRate {
				t.Errorf("CountSymbolPayout() gotPayRate = %v, want %v", gotPayRate, tt.wantPayRate)
			}
		})
	}
}

func TestCore_DownSymbol(t *testing.T) {
	type args struct {
		wheel        [][]int
		deleteSymbol int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{
				[][]int{{1, -1, 1, 1, 1}, {1, -1, 1, 1, 1}, {1, -1, 1, 1, 1}, {1, -1, 1, 1, 1}},
				-1,
			},
			[][]int{{-1, 1, 1, 1, 1}, {-1, 1, 1, 1, 1}, {-1, 1, 1, 1, 1}, {-1, 1, 1, 1, 1}},
		},
		{
			"1",
			args{
				[][]int{{1, -1, 1, -1, 1}, {1, -1, 1, -1, 1}, {1, -1, 1, -1, 1}, {1, -1, 1, -1, 1}},
				-1,
			},
			[][]int{{-1, -1, 1, 1, 1}, {-1, -1, 1, 1, 1}, {-1, -1, 1, 1, 1}, {-1, -1, 1, 1, 1}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if got := c.DownSymbol(tt.args.wheel, tt.args.deleteSymbol); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("DownSymbol() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCore_DownSymbolWithUnmoved(t *testing.T) {
	type args struct {
		wheel         [][]int
		deleteSymbol  int
		unmovedSymbol int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{
				[][]int{{1, -1, 3, -9, 5}, {1, -1, 3, -9, 5}, {1, -1, 3, 4, 5}, {1, -1, 3, 4, 5}},
				-1,
				-9,
			},
			[][]int{{-1, 1, 3, -9, 5}, {-1, 1, 3, -9, 5}, {-1, 1, 3, 4, 5}, {-1, 1, 3, 4, 5}},
		},
		{
			"1",
			args{
				[][]int{{1, -1, 3, -9, -1}, {1, -1, 3, -9, -1}, {1, -1, 3, 4, 5}, {1, -1, 3, 4, 5}},
				-1,
				-9,
			},
			[][]int{{-1, -1, 1, -9, 3}, {-1, -1, 1, -9, 3}, {-1, 1, 3, 4, 5}, {-1, 1, 3, 4, 5}},
		},
		{
			"2",
			args{
				[][]int{{-1, -9, -9, -9, -1}, {1, 3, -9, -9, -1}, {1, -1, 3, 4, 5}, {1, -1, 3, 4, 5}},
				-1,
				-9,
			},
			[][]int{{-1, -9, -9, -9, -1}, {-1, 1, -9, -9, 3}, {-1, 1, 3, 4, 5}, {-1, 1, 3, 4, 5}},
		},
		{
			"3",
			args{
				[][]int{{3, -9, -1, -9, 1}, {1, 3, -9, -1, -1}, {-9, -1, 3, 4, 5}, {-9, -1, 3, 4, -1}},
				-1,
				-9,
			},
			[][]int{{-1, -9, 3, -9, 1}, {-1, -1, -9, 1, 3}, {-9, -1, 3, 4, 5}, {-9, -1, -1, 3, 4}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if got := c.DownSymbolWithUnmovedSymbol(tt.args.wheel, tt.args.deleteSymbol, tt.args.unmovedSymbol); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("DownSymbolWithUnmoved() = %v, want %v", got, tt.want)
			}
		})
	}
}
