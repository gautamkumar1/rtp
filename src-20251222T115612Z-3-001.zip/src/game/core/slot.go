package core

/*
import (
	"fmt"
	"github.com/idtksrv/simulator-server/internal/configuration"
	runtimeUtil "github.com/idtksrv/simulator-server/internal/util/runtime"
	sliceUtil "github.com/idtksrv/simulator-server/internal/util/slice"
	"github.com/shopspring/decimal"
)



//Base
//取結果
//scatter info
//wild info
//算分
//回傳結果及info
type Base struct {
	Core
}

//GetResult return column x line result
func (g *Base) GetResult(setting *BaseSetting, args *GetResultArgs) (retResult *BaseResult, retErr error) {
	logFunc := runtimeUtil.GetFuncName(1)

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	//get result reel
	gameResultReel, err := g.Core.RandomWheel(args.Reel, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	return g.GetBaseResult(setting, gameResultReel, args.LineBet, args.Lines, args.CoinValue, args.BetCredit)
}

//GetTwoWheelResult 先取指定 column, line 的輪面，再從這個輪面取真正的result
//retResult
//retSpecificResultReel 先取的那個輪面，狀態跟 result一樣，可能合上 wild,scatter
func (g *Base) GetTwoWheelResult(setting *BaseSetting, args *GetResultArgs) (retResult *BaseResult, retSpecificResultReel [][]int, retErr error) {
	logFunc := runtimeUtil.GetFuncName(1)

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	var err error
	//先取指定 column, line 的輪面，再從裡面取真正的result
	retSpecificResultReel, err = g.Core.RandomWheel(args.Reel, args.SpecificColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}
	gameResultReel, err := g.getResultReelFromSpecificReel(retSpecificResultReel, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	retResult, retErr = g.GetBaseResult(setting, gameResultReel, args.LineBet, args.Lines, args.CoinValue, args.BetCredit)
	return retResult, retSpecificResultReel, retErr
}

func (g *Base) GetBaseResult(setting *BaseSetting, resultReel [][]int, lineBet float64, lines int, coinValue float64, betCredit float64) (retResult *BaseResult, retErr error) {
	logFunc := runtimeUtil.GetFuncName(1)

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("BaseSlot %s panic %s", logFunc, r)
		}
	}()

	//compose pay line array from result reel
	plAry, err := g.Core.CreateCombinationOfGameResultReelAndPayLine(resultReel, setting.PayLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	//count pay line result from pay line array
	lineResult, payCreditTotal, _ := g.CountCombinationResult(plAry, setting.Symbol.WildID, setting.GetPrizeSymbolMinNumPerLine, lineBet, coinValue, setting.PayTable)

	//count scatter / wild position and amount
	scatterAmount, scatterPosition, err := g.Core.CountSymbolInfo(resultReel, setting.Symbol.ScatterID, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	wildAmount, wildPosition, err := g.Core.CountSymbolInfo(resultReel, setting.Symbol.WildID, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	retResult = &BaseResult{
		payCreditTotal,
		resultReel,
		lineResult,
		&BaseSymbolInfo{
			setting.Symbol.ScatterID,
			scatterPosition,
			scatterAmount,
			0, 1, 1,
		},
		&BaseSymbolInfo{
			setting.Symbol.WildID,
			wildPosition,
			wildAmount,
			0, 1, 1,
		},
		[][]float32{},
	}
	return
}

//getResultReelFromSpecificReel
//從一個先取好的輪面中，從中間位置，依序取出新輪面
func (g *Base) getResultReelFromSpecificReel(specificReel [][]int, realReelColumnAndLine []int) (retReel [][]int, retErr error) {

	specificColumn := len(specificReel)
	specificLine := len(specificReel[0])

	realColumn := realReelColumnAndLine[0]
	realLine := realReelColumnAndLine[1]

	if specificColumn < realColumn {
		return nil, fmt.Errorf(" specific reel column <= real reel column")
	}

	if specificLine < realLine {
		return nil, fmt.Errorf(" specific reel line <= real reel line")
	}

	retReel = sliceUtil.Make2DSlice(-1, realColumn, realLine)

	for i, _ := range specificReel {
		//reel [0],[1],[2] 對應 specific reel index 1,2,3
		for j, _ := range retReel[i] {
			retReel[i][j] = specificReel[i][j+1]
		}
	}
	return
}

//GetGameResultReelRandomPerWheel
//獨立輪，每一個wheel 獨立 random
func (g *Base) GetGameResultReelRandomPerWheel(gameReel [][]int, columnAndLine []int) (retSpinReel [][]int, retErr error) {

	if len(gameReel) == 0 || len(columnAndLine) != 2 {
		retErr = fmt.Errorf("getGameResultReelRandomPerWheel passed gameReel length==0")
		return
	}

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", "getReelResult", r)
		}
	}()

	retSpinReel = sliceUtil.Make2DSlice(configuration.SymbolIDNotUse, columnAndLine[0], columnAndLine[1])

	for i, content := range retSpinReel {
		for j := 0; j < len(content); j++ {
			ele, _ := sliceUtil.RandomElementIn2DSlice(gameReel)
			retSpinReel[i][j] = ele
		}
	}

	return
}

//CountTargetNewSymbolPosition 從 newResultReel 跟 originalResultReel 比對，
//找出新的 targetSymbol級數量
//retPosition 格式 [][]int{{1,1,1},{1,-1,-1},{1,-1,-1},{-1,-1,-1},{-1,-1,-1}} 1=有，-1=沒有
func (g *Base) CountTargetNewSymbolPosition(originalResultReel, newResultReel [][]int, targetSymbolID []int) (retAmount int, retPosition [][]int, retErr error) {

	retPosition = sliceUtil.Make2DSlice(configuration.SymbolIDNotUse, len(originalResultReel), len(originalResultReel[0]))

	for index, values := range newResultReel {
		for i, value := range values {
			//newResultReel這個位置是targetSymbol
			for _, id := range targetSymbolID {
				if value == id {
					//originalResultReel這個位置不是targetSymbol
					has := false
					for _, rID := range targetSymbolID {
						if originalResultReel[index][i] == rID {
							has = true
						}
					}
					if !has {
						retAmount++
						retPosition[index][i] = configuration.SymbolIDHas
					}
				}

			}

		}
	}
	return
}

//CountCombinationResult 算分
//wild開頭可算連線(設定檔有分數)
//scatter 開頭，不算連線(設定檔裡面沒分數)
//payTable的設定是
//{
//	"SymbolID":0,
//	"PayRate":[0,0,0,25,250,500]  //amount 0,1,2,3,4,5
//	},
func (g *Base) CountCombinationResult(combinationOfReelResultAndPayLine [][]int, wildIDs []int, getPrizeSymbolMinNumPerLine int, lineBet, coinValue float64, payTable []*BasePayTable) (retLineResult []*BaseLineResult, retPayCreditTotal float64, retError error) {

	defer func() {
		if r := recover(); r != nil {
			retError = fmt.Errorf("panic %s", r)
		}
	}()

	lbc := decimal.NewFromFloat(lineBet).Mul(decimal.NewFromFloat(coinValue)) //line bet* coin value
	pcTotal := decimal.NewFromFloat(0)                                        //pay credit total

	//判斷是否有中
	targetSymbolID := -1
	targetAmount := 0
	targetPayCredit := 0.0
	//targetPayCreditDecimal := decimal.NewFromFloat(0)

	for payLineIndex, line := range combinationOfReelResultAndPayLine {

		targetSymbolID = line[0]
		targetAmount = 0
		targetPayCredit = 0.0

		//計算每一條線的payout
		targetSymbolID, targetAmount, targetPayCredit, _ = g.countConnectPayout(targetSymbolID, getPrizeSymbolMinNumPerLine, wildIDs, line, payTable, lbc)

		//實際上有分數，才紀錄
		//因為有可能wild, scatter 連線沒分數/或有分數
		if targetPayCredit > 0 {
			pcTotal = pcTotal.Add(decimal.NewFromFloat(targetPayCredit))

			retLineResult = append(retLineResult, &BaseLineResult{
				payLineIndex,
				targetSymbolID,
				targetAmount,
				targetPayCredit,
			})
		}
	}
	retPayCreditTotal, _ = pcTotal.Float64()
	return
}

//countConnectPayout 算連線陪分
func (g *Base) countConnectPayout(targetSymbolID, getPrizeSymbolMinNumPerLine int, wildIDs, line []int, payTable []*BasePayTable, lbc decimal.Decimal) (retID, retAmount int, retPayCredit float64, retErr error) {

	//第一個symbol id 是 wild
	if g.isFirstWild(targetSymbolID, wildIDs) {

		//先只計算wild 連線
		wildAmount := g.countWildFirstAndOnlyConnectAmount(wildIDs, line)
		_, wildPayCredit := g.countPayRateCredit(targetSymbolID, wildAmount, getPrizeSymbolMinNumPerLine, payTable, lbc)

		//計算wild連線 + 其他symbol 連線
		id, idAmount := g.countWildFirstAndOtherConnectAmount(wildIDs, line)
		_, idPayCredit := g.countPayRateCredit(id, idAmount, getPrizeSymbolMinNumPerLine, payTable, lbc)

		//算哪一個 payout 多
		//一樣多,wild 連線優先
		if wildPayCredit >= idPayCredit {
			retID = targetSymbolID
			retAmount = wildAmount
			retPayCredit = wildPayCredit
		} else {
			retID = id
			retAmount = idAmount
			retPayCredit = idPayCredit
		}
		return
	}

	otherConnectAmount := g.countConnectOtherSymbolAmount(wildIDs, line)
	_, otherPayCredit := g.countPayRateCredit(targetSymbolID, otherConnectAmount, getPrizeSymbolMinNumPerLine, payTable, lbc)

	retID = targetSymbolID
	retAmount = otherConnectAmount
	retPayCredit = otherPayCredit

	return
}

//isFirstWild 第一個 symbol 是否 wild
func (g *Base) isFirstWild(targetSymbolID int, wildIDs []int) bool {
	for _, v := range wildIDs {
		if targetSymbolID == v {
			return true
		}
	}
	return false
}

//countWildFirstAndOnlyConnectAmount 計算 wild 開頭 且只有 wild symbol 的連線有幾顆
func (g *Base) countWildFirstAndOnlyConnectAmount(wildIDs []int, line []int) (retAmount int) {
	//第一個必須是wild
	targetSymbolID := line[0]
	got := false
	for _, v := range wildIDs {
		if targetSymbolID == v {
			got = true
		}
	}
	if !got {
		return
	}

	//從 1 開始
	retAmount = 1
	for j := 1; j < len(line); j++ {
		got = false
		for i, _ := range wildIDs {
			if line[j] == wildIDs[i] {
				retAmount++
				got = true
			}
		}
		if !got {
			break
		}
	}

	return retAmount
}

//countWildFirstAndOtherConnectAmount 計算 wild 開頭 + normal symbol 的連線有幾顆
func (g *Base) countWildFirstAndOtherConnectAmount(wildIDs []int, line []int) (retSymbolID, retAmount int) {
	//第一個必須是wild
	targetSymbolID := line[0]
	if !g.symbolIDInSlice(targetSymbolID, wildIDs) {
		return
	}

	retSymbolID = -1
	retAmount = 1
	for j := 1; j < len(line); j++ {

		//wild
		if g.symbolIDInSlice(line[j], wildIDs) {
			retAmount++
		} else {
			//取中間的symbol, 類似 0202
			//第一次碰到非wild
			if retSymbolID == -1 {
				retSymbolID = line[j]
				retAmount++

				//後續碰到非wild
			} else if line[j] == retSymbolID {
				retAmount++
			} else {
				break
			}
		}
	}

	return
}

//countConnectOtherSymbolAmount 計算 normal symbol 開頭的連線有幾顆(normal symbol + wild)
func (g *Base) countConnectOtherSymbolAmount(wildID []int, line []int) (retAmount int) {
	//第一個不能是wild
	targetSymbolID := line[0]
	if g.symbolIDInSlice(targetSymbolID, wildID) {
		return
	}

	retAmount = 1
	for j := 1; j < len(line); j++ {

		if line[j] == targetSymbolID {
			retAmount++
		} else {
			//是否wild
			if g.symbolIDInSlice(line[j], wildID) {
				retAmount++
			} else {
				break
			}
		}
	}
	return retAmount
}

//lbc = line bet * coin value
func (g *Base) countPayRateCredit(symbolID, amount, getPrizeSymbolMinNumPerLine int, payTable []*BasePayTable, lbc decimal.Decimal) (retPayRate float64, retPayCredit float64) {

	if amount >= getPrizeSymbolMinNumPerLine {
		for i, _ := range payTable {
			if payTable[i].SymbolID == symbolID {
				retPayRate = payTable[i].PayRate[amount]
				pr := decimal.NewFromFloat(retPayRate) // pay rate
				pc := lbc.Mul(pr)                      //lineBet * coinValue * pay rate
				retPayCredit, _ = pc.Float64()
				break
			}
		}
	}

	return
}

func (g *Base) CountLeftSpotAmount(columnAndLine []int, scatterAmount int) int {

	return (columnAndLine[0] * columnAndLine[1]) - scatterAmount
}

func (g *Base) symbolIDInSlice(symbolID int, IDSlice []int) bool {
	for i, _ := range IDSlice {
		if symbolID == IDSlice[i] {
			return true
		}
	}
	return false
}

//modifyReelSymbol 把position的symbol 改成指定的symbol
func (g *Base) modifyReelSymbol(targetReel [][]int, modifySymbol int, modifySymbolPosition [][]int, targetIsLonger bool) [][]int {
	if len(targetReel) < len(modifySymbolPosition) || len(targetReel[0]) < len(modifySymbolPosition[0]) {
		return targetReel
	}

	for i, v := range modifySymbolPosition {
		for j, mv := range v {
			if mv != -1 {
				if targetIsLonger {
					targetReel[i][j+1] = modifySymbol
				} else {
					targetReel[i][j] = modifySymbol
				}
			}
		}
	}
	return targetReel
}
*/
