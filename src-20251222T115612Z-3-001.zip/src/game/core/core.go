package core

import (
	"fmt"
	"runtime/debug"

	"github.com/idtksrv/simulator-server/internal/configuration"
	"github.com/idtksrv/simulator-server/internal/util/rand"
	sliceUtil "github.com/idtksrv/simulator-server/internal/util/slice"
	"github.com/idtksrv/simulator-server/internal/util/slot"
	"github.com/shopspring/decimal"
)

type Core struct {
}

// RandomWheel 傳入遊戲的 reels ,random 回傳一個盤面，回傳結構
// {{1,2,3} client的第1輪 1=上面，2=中間，3=下面
// {1,1,1}  client的第2輪
// {1,1,1}
// {1,1,1}
// {1,1,1}}
func (c *Core) RandomWheel(reels [][]int, columnAndLine []int) (retWheel [][]int, retErr error) {

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("RandomWheel() panic %s", r)
		}
	}()

	column := columnAndLine[0] //直
	line := columnAndLine[1]   //橫

	//game reel 的 column >= columnAndLine
	if len(reels) < column {
		retErr = fmt.Errorf("game reel column %d < columnAndLine %d", len(reels), columnAndLine)
		return
	}

	retWheel = sliceUtil.Make2DSlice(-1, column, line)

	var max int64

	for i := 0; i < column; i++ {
		max = int64(len(reels[i]))
		r := rand.Int63n(max)
		retIndex := slot.GetReelIndex(int(r), int(max), line)
		for j := 0; j < line; j++ {
			retWheel[i][j] = reels[i][retIndex[j]]
		}
	}

	return
}

// GetWheelFromSpecificWheel 從一個預先取好的輪面中，從中間位置，取出新輪面
func (c *Core) GetWheelFromSpecificWheel(specificWheel [][]int, targetWheelColumnAndLine []int) (retWheel [][]int, retErr error) {

	specificColumn := len(specificWheel)
	specificLine := len(specificWheel[0])

	realColumn := targetWheelColumnAndLine[0]
	realLine := targetWheelColumnAndLine[1]

	if specificColumn < realColumn {
		return nil, fmt.Errorf(" specific reel column <= real reel column")
	}

	if specificLine < realLine {
		return nil, fmt.Errorf(" specific reel line <= real reel line")
	}

	retWheel = sliceUtil.Make2DSlice(-1, realColumn, realLine)

	for i := range specificWheel {
		//reel [0],[1],[2] 對應 specific reel index 1,2,3
		for j := range retWheel[i] {
			retWheel[i][j] = specificWheel[i][j+1]
		}
	}
	return
}

func (c *Core) CountSymbolInfo(wheel [][]int, targetSymbolID []int, columnAndLine []int) (retAmount int, retPosition [][]int, retInfo *BaseSymbolInfo, retErr error) {
	if len(wheel) < 0 || len(targetSymbolID) < 0 {
		return 0, nil, &BaseSymbolInfo{}, fmt.Errorf("passed reel or symbol id len less 1")
	}

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("panic %s msg: %s", r, string(debug.Stack()))
		}
	}()

	retPosition = sliceUtil.Make2DSlice(configuration.SymbolIDNotUse, columnAndLine[0], columnAndLine[1])

	for index, values := range wheel {
		for i, value := range values {
			for _, id := range targetSymbolID {
				if value == id {
					retAmount++
					retPosition[index][i] = configuration.SymbolIDHas
				}
			}
		}
	}

	retInfo = &BaseSymbolInfo{
		ID:         targetSymbolID,
		Position:   retPosition,
		Amount:     retAmount,
		Multiplier: 1,
		PayRate:    0,
		PayCredit:  0,
	}

	return
}

// 計算指定 symbol 的 info (根據傳入的 wheel, 來產生同樣大小的 2D slice, 並標記座標位置)
func (c *Core) CountSymbolInfo2(wheel [][]int, targetSymbolID []int) (retAmount int, retPosition [][]int, retInfo *BaseSymbolInfo, retErr error) {
	if len(wheel) == 0 || len(wheel[0]) == 0 || len(targetSymbolID) == 0 {
		return 0, nil, &BaseSymbolInfo{}, fmt.Errorf("passed reel or symbol id len less 1")
	}

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("panic %s msg: %s", r, string(debug.Stack()))
		}
	}()

	// 根據 wheel 的大小，建立一個相同大小的 2D slice, 預設值是 -1
	retPosition = sliceUtil.Make2DSlice(configuration.SymbolIDNotUse, len(wheel), len(wheel[0]))

	for index, values := range wheel {
		for i, value := range values {
			for _, id := range targetSymbolID {
				if value == id {
					// 找到 targetSymbolID, 標記座標位置
					retAmount++
					retPosition[index][i] = configuration.SymbolIDHas
				}
			}
		}
	}

	retInfo = &BaseSymbolInfo{
		ID:         targetSymbolID,
		Position:   retPosition,
		Amount:     retAmount,
		Multiplier: 1,
		PayRate:    0,
		PayCredit:  0,
	}

	return
}

func (c *Core) CountSymbolInfoByID(gameResultReel [][]int, symbolID int, columnAndLine []int) (retAmount int, retPosition [][]int, retErr error) {
	if len(gameResultReel) < 0 {
		return 0, nil, fmt.Errorf("passed reel or symbol id len less 1")
	}

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("panic %s", r)
		}
	}()

	retPosition = sliceUtil.Make2DSlice(configuration.SymbolIDNotUse, columnAndLine[0], columnAndLine[1])

	for index, values := range gameResultReel {
		for i, value := range values {
			if value == symbolID {
				retAmount++
				retPosition[index][i] = configuration.SymbolIDHas
			}
		}
	}
	return
}

// CountSymbolsInfoByID 計算多個 symbol 的 info
func (c *Core) CountSymbolsInfoByID(resultReel [][]int, symbolID []int, columnAndLine []int) (retSymbolInfo []*BaseSymbolInfo, retErr error) {
	retSymbolInfo = []*BaseSymbolInfo{}
	for _, sid := range symbolID {
		amount, position, _ := c.CountSymbolInfoByID(resultReel, sid, columnAndLine)
		retSymbolInfo = append(retSymbolInfo, &BaseSymbolInfo{[]int{sid}, position, amount, 0, 0, 0})
	}
	return
}

// CreateCombinationOfGameResultReelAndPayLine
// 用 result 取跟payLine同位置的的symbol,取成一筆,
// 用這筆去判斷是否有中
// 總筆數跟payLine設定筆數相同，用來判斷中哪幾條線
// reel result 可能中好幾條線
// [1,1,1,8,9]	//取出來是這樣
func (c *Core) CreateCombinationOfGameResultReelAndPayLine(reelResult, payLine [][]int) (retCompose [][]int, retErr error) {
	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("panic %s", r)
		}
	}()

	if len(reelResult) == 0 || len(payLine) == 0 {
		return nil, fmt.Errorf("reelResult length =0 || payLine length =0")
	}
	//todo
	var le = len(payLine[0])
	for _, line := range payLine {
		var r = make([]int, le, le)
		for i, v := range line {
			r[i] = reelResult[i][v]
		}

		retCompose = append(retCompose, r)
	}
	return
}

// CountSymbolPayout 算指定 symbol 的 payout,通常是 scatter，因為scatter 是用 betCredit 去算，不是 line bet * coin value
// multiplier 倍數，沒有就傳 1
// putCredit 可能是總投注 betCredit =lineBet*coinValue*lineNum, 或是一般的 lineBet * coin value
func (c *Core) CountSymbolPayout(symbolID int, symbolAmount int, payTable []*BasePayTable, multiplier float64, baseCredit float64) (payout, payRate float64) {
	//算 scatter credit
	if payRate := c.GetPayTablePayRate(symbolID, symbolAmount, payTable); payRate > 0 {
		//scatter pay 乘倍, 套用最新的 multiplier
		payCredit, _ := decimal.NewFromFloat(baseCredit).Mul(decimal.NewFromFloat(payRate)).Mul(decimal.NewFromFloat(multiplier)).Float64()
		return payCredit, payRate
	}
	return 0, 0
}

// GetPayTablePayRate 取得某個 symbol pay table 上的倍數
func (c *Core) GetPayTablePayRate(symbolID int, amount int, payTable []*BasePayTable) float64 {
	for i := range payTable {
		if payTable[i].SymbolID == symbolID {
			lLen := len(payTable[i].PayRate)
			if amount >= lLen {
				//取最後一個
				return payTable[i].PayRate[lLen-1]
			} else {
				return payTable[i].PayRate[amount]
			}
		}
	}
	return 0
}

// GetSpecificColumnAndLine  5,3 => 5,5 上下各多一 line
func (c *Core) GetSpecificColumnAndLine(columnAndLine []int) []int {
	ret := make([]int, 2)
	ret[0] = columnAndLine[0]     //5
	ret[1] = columnAndLine[1] + 2 //多上下兩個
	return ret
}

/*
FOR cascade game
*/

func (c *Core) hasTargetSymbol(reel []int, symbol int) bool {
	for _, v := range reel {
		if v == symbol {
			return true
		}
	}
	return false
}

func (c *Core) getNextWriteIndex(reel []int, deleteSymbol int) int {

	for i := len(reel) - 1; i >= 0; i-- {
		if reel[i] == deleteSymbol {
			return i
		}
	}
	return -1
}

// ComposeNewWheel
// newWheel 新取得的 wheel
// downWheel 已經下降過的 wheel
// retNewAddWheel 新加入的 symbol 的 wheel
// retFullWheel 晚整的新 wheel
func (c *Core) ComposeNewWheel(spinReel, downWheel [][]int) (retNewAddWheel [][]int, retFullWheel [][]int) {

	retFullWheel = sliceUtil.Duplicate2DSlice(downWheel)

	retNewAddWheel = [][]int{}

	for i := range downWheel {
		rr := []int{}
		//從前面開始處理
		//取arrange 同位置 reSpineResultReel
		for j, id := range downWheel[i] {
			if id == configuration.SymbolIDNotUse {
				rr = append(rr, spinReel[i][j])
				retFullWheel[i][j] = spinReel[i][j]
			}
		}
		retNewAddWheel = append(retNewAddWheel, rr)
	}
	return
}

// CheckNearWin checks if scatter presents near win
// 前n輪已出現n顆(含以上)Scatter
// firstReelNum 統計前幾輪
// 0= none ,1= yes
func (c *Core) CheckNearWin(scatterInfo *BaseSymbolInfo, firstNReel, symbolGreaterOrEqualAmount int) (retSymbolID, retNearWin int, retErr error) {
	if scatterInfo == nil {
		return -1, 0, fmt.Errorf("scatterInfo is nil")
	}
	if scatterInfo.Amount < symbolGreaterOrEqualAmount {
		return -1, 0, nil
	}

	scatterID := scatterInfo.ID[0] //這個遊戲只有一個 scatter

	scatterAmount := 0
	//算前n輪 scatter 數量
	for i := 0; i < firstNReel; i++ {
		for _, id := range scatterInfo.Position[i] {
			if id == configuration.SymbolIDHas {
				scatterAmount++
			}
		}

	}
	//前n輪數量 >= 要求數量
	if scatterAmount >= symbolGreaterOrEqualAmount {
		return scatterID, 1, nil
	}
	return -1, 1, nil
}

/*
for slot
*/

// GetResult return column x line result
func (c *Core) GetResult(setting *BaseSetting, args *GetResultArgs) (retResult *BaseResult, retErr error) {
	logFunc := "GetResult"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	//get result reel
	gameResultReel, err := c.RandomWheel(args.Reel, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	return c.GetBaseResult(setting, gameResultReel, args.LineBet, args.Lines, args.CoinValue, args.BetCredit)
}

// GetTwoWheelResult 先取指定 column, line 的輪面，再從這個輪面取真正的result
// retResult
// retSpecificResultReel 先取的那個輪面，狀態跟 result一樣，可能合上 wild,scatter
func (c *Core) GetTwoWheelResult(setting *BaseSetting, args *GetResultArgs) (retResult *BaseResult, retSpecificResultReel [][]int, retErr error) {
	logFunc := "GetTwoWheelResult"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	var err error
	//先取指定 column, line 的輪面，再從裡面取真正的result
	retSpecificResultReel, err = c.RandomWheel(args.Reel, args.SpecificColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}
	gameResultReel, err := c.getResultReelFromSpecificReel(retSpecificResultReel, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	retResult, retErr = c.GetBaseResult(setting, gameResultReel, args.LineBet, args.Lines, args.CoinValue, args.BetCredit)
	return retResult, retSpecificResultReel, retErr
}

func (c *Core) GetBaseResult(setting *BaseSetting, resultReel [][]int, lineBet float64, lines int, coinValue float64, betCredit float64) (retResult *BaseResult, retErr error) {
	logFunc := "GetBaseResult"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("BaseSlot %s panic %s", logFunc, r)
		}
	}()

	//compose pay line array from result reel
	plAry, err := c.CreateCombinationOfGameResultReelAndPayLine(resultReel, setting.PayLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	//count pay line result from pay line array
	lineResult, payCreditTotal, _ := c.CountCombinationResult(plAry, setting.Symbol.WildID, setting.GetPrizeSymbolMinNumPerLine, lineBet, coinValue, setting.PayTable)

	//count scatter / wild position and amount
	scatterAmount, scatterPosition, _, err := c.CountSymbolInfo(resultReel, setting.Symbol.ScatterID, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	wildAmount, wildPosition, _, err := c.CountSymbolInfo(resultReel, setting.Symbol.WildID, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	retResult = &BaseResult{
		payCreditTotal,
		resultReel,
		lineResult,
		&BaseSymbolInfo{
			setting.Symbol.ScatterID,
			scatterPosition,
			scatterAmount,
			0, 0, 0,
		},
		&BaseSymbolInfo{
			setting.Symbol.WildID,
			wildPosition,
			wildAmount,
			0, 0, 0,
		},
		[][]float32{},
	}
	return
}

func (c *Core) GetTwoWheelResultByBetCredit(setting *BaseSetting, args *GetResultArgs) (retResult *BaseResult, retSpecificResultReel [][]int, retErr error) {
	logFunc := "GetTwoWheelResultByBetCredit"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	var err error
	//先取指定 column, line 的輪面，再從裡面取真正的result
	retSpecificResultReel, err = c.RandomWheel(args.Reel, args.SpecificColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}
	gameResultReel, err := c.getResultReelFromSpecificReel(retSpecificResultReel, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	retResult, retErr = c.getBaseResultByBetCredit(setting, gameResultReel, args.BetCredit)
	return retResult, retSpecificResultReel, retErr
}
func (c *Core) getBaseResultByBetCredit(setting *BaseSetting, resultReel [][]int, betCredit float64) (retResult *BaseResult, retErr error) {
	logFunc := "GetBaseResult"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("BaseSlot %s panic %s", logFunc, r)
		}
	}()

	//compose pay line array from result reel
	plAry, err := c.CreateCombinationOfGameResultReelAndPayLine(resultReel, setting.PayLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	//count pay line result from pay line array
	lineResult, payCreditTotal, _ := c.CountCombinationResult(plAry, setting.Symbol.WildID, setting.GetPrizeSymbolMinNumPerLine, 1, betCredit, setting.PayTable)

	//count scatter / wild position and amount
	scatterAmount, scatterPosition, _, err := c.CountSymbolInfo(resultReel, setting.Symbol.ScatterID, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	wildAmount, wildPosition, _, err := c.CountSymbolInfo(resultReel, setting.Symbol.WildID, setting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	retResult = &BaseResult{
		payCreditTotal,
		resultReel,
		lineResult,
		&BaseSymbolInfo{
			setting.Symbol.ScatterID,
			scatterPosition,
			scatterAmount,
			0, 0, 0,
		},
		&BaseSymbolInfo{
			setting.Symbol.WildID,
			wildPosition,
			wildAmount,
			0, 0, 0,
		},
		[][]float32{},
	}
	return
}

// getResultReelFromSpecificReel
// 從一個先取好的輪面中，從中間位置，依序取出新輪面
func (c *Core) getResultReelFromSpecificReel(specificReel [][]int, realReelColumnAndLine []int) (retReel [][]int, retErr error) {

	specificColumn := len(specificReel)
	specificLine := len(specificReel[0])

	realColumn := realReelColumnAndLine[0]
	realLine := realReelColumnAndLine[1]

	if specificColumn < realColumn {
		return nil, fmt.Errorf(" specific reel column <= real reel column")
	}

	if specificLine < realLine {
		return nil, fmt.Errorf(" specific reel line <= real reel line")
	}

	retReel = sliceUtil.Make2DSlice(-1, realColumn, realLine)

	for i := range specificReel {
		//reel [0],[1],[2] 對應 specific reel index 1,2,3
		for j := range retReel[i] {
			retReel[i][j] = specificReel[i][j+1]
		}
	}
	return
}

// GetGameResultReelRandomPerWheel
// 獨立輪，每一個wheel 獨立 random
func (c *Core) GetGameResultReelRandomPerWheel(gameReel [][]int, columnAndLine []int) (retSpinReel [][]int, retErr error) {

	if len(gameReel) == 0 || len(columnAndLine) != 2 {
		retErr = fmt.Errorf("getGameResultReelRandomPerWheel passed gameReel length==0")
		return
	}

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", "getReelResult", r)
		}
	}()

	retSpinReel = sliceUtil.Make2DSlice(configuration.SymbolIDNotUse, columnAndLine[0], columnAndLine[1])

	for i, content := range retSpinReel {
		for j := 0; j < len(content); j++ {
			ele, _ := sliceUtil.RandomElementIn2DSlice(gameReel)
			retSpinReel[i][j] = ele
		}
	}

	return
}

// CountTargetNewSymbolPosition 從 newResultReel 跟 originalResultReel 比對，
// 找出新的 targetSymbol級數量
// retPosition 格式 [][]int{{1,1,1},{1,-1,-1},{1,-1,-1},{-1,-1,-1},{-1,-1,-1}} 1=有，-1=沒有
func (c *Core) CountTargetNewSymbolPosition(originalResultReel, newResultReel [][]int, targetSymbolID []int) (retAmount int, retPosition [][]int, retErr error) {

	retPosition = sliceUtil.Make2DSlice(configuration.SymbolIDNotUse, len(originalResultReel), len(originalResultReel[0]))

	for index, values := range newResultReel {
		for i, value := range values {
			//newResultReel這個位置是targetSymbol
			for _, id := range targetSymbolID {
				if value == id {
					//originalResultReel這個位置不是targetSymbol
					has := false
					for _, rID := range targetSymbolID {
						if originalResultReel[index][i] == rID {
							has = true
						}
					}
					if !has {
						retAmount++
						retPosition[index][i] = configuration.SymbolIDHas
					}
				}

			}

		}
	}
	return
}

// CountCombinationResult 算分
// wild開頭可算連線(設定檔有分數)
// scatter 開頭，不算連線(設定檔裡面沒分數)
// payTable的設定是
//
//	{
//		"SymbolID":0,
//		"PayRate":[0,0,0,25,250,500]  //amount 0,1,2,3,4,5
//		},
func (c *Core) CountCombinationResult(combinationOfReelResultAndPayLine [][]int, wildIDs []int, getPrizeSymbolMinNumPerLine int, lineBet, coinValue float64, payTable []*BasePayTable) (retLineResult []*BaseLineResult, retPayCreditTotal float64, retError error) {

	defer func() {
		if r := recover(); r != nil {
			retError = fmt.Errorf("panic %s", r)
		}
	}()

	lbc := decimal.NewFromFloat(lineBet).Mul(decimal.NewFromFloat(coinValue)) //line bet* coin value
	pcTotal := decimal.NewFromFloat(0)                                        //pay credit total

	//判斷是否有中
	targetSymbolID := -1
	targetAmount := 0
	targetPayCredit := 0.0
	//targetPayCreditDecimal := decimal.NewFromFloat(0)

	for payLineIndex, line := range combinationOfReelResultAndPayLine {

		targetSymbolID = line[0]
		targetAmount = 0
		targetPayCredit = 0.0

		//計算每一條線的payout
		targetSymbolID, targetAmount, targetPayCredit, _ = c.countConnectPayout(targetSymbolID, getPrizeSymbolMinNumPerLine, wildIDs, line, payTable, lbc)

		//實際上有分數，才紀錄
		//因為有可能wild, scatter 連線沒分數/或有分數
		if targetPayCredit > 0 {
			pcTotal = pcTotal.Add(decimal.NewFromFloat(targetPayCredit))

			retLineResult = append(retLineResult, &BaseLineResult{
				payLineIndex,
				targetSymbolID,
				targetAmount,
				targetPayCredit,
				0,
			})
		}
	}
	retPayCreditTotal, _ = pcTotal.Float64()
	return
}

// countConnectPayout 算連線陪分
func (c *Core) countConnectPayout(targetSymbolID, getPrizeSymbolMinNumPerLine int, wildIDs, line []int, payTable []*BasePayTable, lbc decimal.Decimal) (retID, retAmount int, retPayCredit float64, retErr error) {

	//第一個symbol id 是 wild
	if c.isFirstWild(targetSymbolID, wildIDs) {

		//先只計算wild 連線
		wildAmount := c.countWildFirstAndOnlyConnectAmount(wildIDs, line)
		_, wildPayCredit := c.countPayRateCredit(targetSymbolID, wildAmount, getPrizeSymbolMinNumPerLine, payTable, lbc)

		//計算wild連線 + 其他symbol 連線
		id, idAmount := c.countWildFirstAndOtherConnectAmount(wildIDs, line)
		_, idPayCredit := c.countPayRateCredit(id, idAmount, getPrizeSymbolMinNumPerLine, payTable, lbc)

		//算哪一個 payout 多
		//一樣多,wild 連線優先
		if wildPayCredit >= idPayCredit {
			retID = targetSymbolID
			retAmount = wildAmount
			retPayCredit = wildPayCredit
		} else {
			retID = id
			retAmount = idAmount
			retPayCredit = idPayCredit
		}
		return
	}

	otherConnectAmount := c.countConnectOtherSymbolAmount(wildIDs, line)
	_, otherPayCredit := c.countPayRateCredit(targetSymbolID, otherConnectAmount, getPrizeSymbolMinNumPerLine, payTable, lbc)

	retID = targetSymbolID
	retAmount = otherConnectAmount
	retPayCredit = otherPayCredit

	return
}

// isFirstWild 第一個 symbol 是否 wild
func (c *Core) isFirstWild(targetSymbolID int, wildIDs []int) bool {
	for _, v := range wildIDs {
		if targetSymbolID == v {
			return true
		}
	}
	return false
}

// countWildFirstAndOnlyConnectAmount 計算 wild 開頭 且只有 wild symbol 的連線有幾顆
func (c *Core) countWildFirstAndOnlyConnectAmount(wildIDs []int, line []int) (retAmount int) {
	//第一個必須是wild
	targetSymbolID := line[0]
	got := false
	for _, v := range wildIDs {
		if targetSymbolID == v {
			got = true
		}
	}
	if !got {
		return
	}

	//從 1 開始
	retAmount = 1
	for j := 1; j < len(line); j++ {
		got = false
		for i := range wildIDs {
			if line[j] == wildIDs[i] {
				retAmount++
				got = true
			}
		}
		if !got {
			break
		}
	}

	return retAmount
}

// countWildFirstAndOtherConnectAmount 計算 wild 開頭 + normal symbol 的連線有幾顆
func (c *Core) countWildFirstAndOtherConnectAmount(wildIDs []int, line []int) (retSymbolID, retAmount int) {
	//第一個必須是wild
	targetSymbolID := line[0]
	if !c.symbolIDInSlice(targetSymbolID, wildIDs) {
		return
	}

	retSymbolID = -1
	retAmount = 1
	for j := 1; j < len(line); j++ {

		//wild
		if c.symbolIDInSlice(line[j], wildIDs) {
			retAmount++
		} else {
			//取中間的symbol, 類似 0202
			//第一次碰到非wild
			if retSymbolID == -1 {
				retSymbolID = line[j]
				retAmount++

				//後續碰到非wild
			} else if line[j] == retSymbolID {
				retAmount++
			} else {
				break
			}
		}
	}

	return
}

// countConnectOtherSymbolAmount 計算 normal symbol 開頭的連線有幾顆(normal symbol + wild)
func (c *Core) countConnectOtherSymbolAmount(wildID []int, line []int) (retAmount int) {
	//第一個不能是wild
	targetSymbolID := line[0]
	if c.symbolIDInSlice(targetSymbolID, wildID) {
		return
	}

	retAmount = 1
	for j := 1; j < len(line); j++ {

		if line[j] == targetSymbolID {
			retAmount++
		} else {
			//是否wild
			if c.symbolIDInSlice(line[j], wildID) {
				retAmount++
			} else {
				break
			}
		}
	}
	return retAmount
}

// lbc = line bet * coin value
func (c *Core) countPayRateCredit(symbolID, amount, getPrizeSymbolMinNumPerLine int, payTable []*BasePayTable, lbc decimal.Decimal) (retPayRate float64, retPayCredit float64) {

	if amount >= getPrizeSymbolMinNumPerLine {
		for i := range payTable {
			if payTable[i].SymbolID == symbolID {
				retPayRate = payTable[i].PayRate[amount]
				pr := decimal.NewFromFloat(retPayRate) // pay rate
				pc := lbc.Mul(pr)                      //lineBet * coinValue * pay rate
				retPayCredit, _ = pc.Float64()
				break
			}
		}
	}

	return
}

func (c *Core) CountLeftSpotAmount(columnAndLine []int, scatterAmount int) int {

	return (columnAndLine[0] * columnAndLine[1]) - scatterAmount
}

func (c *Core) symbolIDInSlice(symbolID int, IDSlice []int) bool {
	for i := range IDSlice {
		if symbolID == IDSlice[i] {
			return true
		}
	}
	return false
}

// modifyReelSymbol 把position的symbol 改成指定的symbol
func (c *Core) modifyReelSymbol(targetReel [][]int, modifySymbol int, modifySymbolPosition [][]int, targetIsLonger bool) [][]int {
	if len(targetReel) < len(modifySymbolPosition) || len(targetReel[0]) < len(modifySymbolPosition[0]) {
		return targetReel
	}

	for i, v := range modifySymbolPosition {
		for j, mv := range v {
			if mv != -1 {
				if targetIsLonger {
					targetReel[i][j+1] = modifySymbol
				} else {
					targetReel[i][j] = modifySymbol
				}
			}
		}
	}
	return targetReel
}
