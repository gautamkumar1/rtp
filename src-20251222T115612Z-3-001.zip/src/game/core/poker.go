package core

import (
	"fmt"
	"sort"

	"github.com/idtksrv/simulator-server/internal/util/rand"
	sliceUtil "github.com/idtksrv/simulator-server/internal/util/slice"
)

/*
花色 suit
牌型 hand type

牌資料定義：
suit 1=club,2=diamond,3=heart,4=spade
number 1-13

CardID
club 1-13=101,102,103,104 ~ 113
diamond 1-13=201,202,203,204 ...
heart 1-13=301,302,303,304 ...
spade 1-13=401,402,403,404 ...


利用四種資料判斷牌型：
pokerMap
  []int{-1,102,-1,-1,-1,-1,-1,-1,109,110,-1,-1,-1}   //有102,109,110三張牌
  []int{201,-1,-1,204,-1,-1,207,-1,-1,-1,-1,212,-1}   //有201,204,207,212四張牌
  []int{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}
  []int{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}
theSameNumberCardAmount {1,0,2,0,0,0,0,0,0,0,0,0,3} index 0= A有1張、 index 2=3號2張、K有3張
theSameSuitCardAmount {1,0,2,0} index 0 =club 1張、index 1 =diamond 0張、heart、spade 0張
cardsInOneRow {-1,-1,-1,-1,-1,319,-1,-1,-1,-1,111,-1,403}	有牌的位置不為 -1
*/

const (
	HighCard      = iota //散牌
	Pair                 // 對子
	TwoPair              // 兩對
	ThreeOfAKind         //三條
	Straight             //順子
	Flush                //同花
	FullHouse            //葫蘆
	FourOfAKind          //鐵支
	StraightFlush        //同花順
	RoyalFlush           //皇家同花順

	noUse = -1 // pokerMap中沒使用的element

	PokerAce = 1
	Poker2   = 2
	Poker3   = 3
	Poker4   = 4
	Poker5   = 5
	Poker6   = 6
	Poker7   = 7
	Poker8   = 8
	Poker9   = 9
	Poker10  = 10
	PokerJ   = 11
	PokerQ   = 12
	PokerK   = 13

	club    = 1
	diamond = 2
	heart   = 3
	spade   = 4 //花色

)

// cardContent 取牌的號碼、花色
func (c *Core) cardContent(cardID int) (suit, num int) {
	return cardID / 100, cardID % 100
}

// Shuffle 傳入 dock (牌組)及要發出的張數，
// 從 deck中發出指定張數的牌
func (c *Core) Shuffle(deck []int, cardAmount int) (retCards, retDeck []int) {

	retCards = []int{}

	if len(deck) < cardAmount {
		return retCards, deck
	}
	for i := cardAmount; i > 0; i-- {
		r := rand.Intn(len(deck))
		retCards = append(retCards, deck[r]) //random的 card id 加到 retDeck
		deck = c.removeCard(deck, r)         //remove index card id
	}
	return retCards, deck
}

func (c *Core) removeCard(s []int, index int) []int {
	s[index] = s[len(s)-1] //最後一個數字改成index數字
	return s[:len(s)-1]    //回傳陣列，排除最後一個
}

// CreateOrderedDeck 建立有順序的 deck
// 101,102,103... 113, 201,202,203....,301,302...413
func (c *Core) CreateOrderedDeck() []int {

	deck := []int{}
	for i := 1; i < 5; i++ {
		for j := 1; j < 14; j++ {
			deck = append(deck, 100*i+j)
		}
	}
	return deck
}

/*
以下準備判斷牌型用的資料
*/
//createPokerMap 建立二維陣列 pokerMap 都 -1
//[
//   []int{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}
//   []int{}   //牌編號 1-13
//   []int{}   //牌編號 1-13
//   []int{}   //牌編號 1-13
//]
func (c *Core) createEmptyPokerMap() [][]int {
	return sliceUtil.Make2DSlice(noUse, 4, 13)
}

// createPokerMapWithCards 建立 2維陣列的 pokerMap , 正確位置填入 cardID，沒有的是 -1
// [
// []int{-1,102,-1,-1,-1,-1,-1,-1,109,110,-1,-1,-1}   //有102,109,110三張牌
// []int{201,-1,-1,204,-1,-1,207,-1,-1,-1,-1,212,-1}   //有201,204,207,212四張牌
// []int{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}
// []int{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}
// ]
func (c *Core) createPokerMapWithCards(cards []int) [][]int {
	deck := c.createEmptyPokerMap()
	for _, v := range cards {
		var suit, num = c.cardContent(v)
		deck[suit-1][num-1] = v //apply cardID to deck
	}
	return deck
}

// createTheSameNumberCardAmount 同號有幾張
// {1,0,2,0,0,0,0,0,0,0,0,0,3} A有1張、3號2張、K有3張
func (c *Core) createTheSameNumberCardAmount(pokerMap [][]int) []int {

	//建立長度13,內容0的陣列
	dLen := 13
	s := sliceUtil.MakeSlice(0, dLen)

	for i := 0; i < dLen; i++ {
		s[i] = c.calCardAmountOfTheSameNumber(pokerMap, i+1) //number = index +1
	}
	return s
}

// createTheSameSuitCardAmount 同花色有幾張
// {1,0,2,0} spade有1張、heart 0張、diamond有2張、club 0張
func (c *Core) createTheSameSuitCardAmount(pokerMap [][]int) []int {

	//建立長度4,內容0的陣列
	dLen := 4
	s := sliceUtil.MakeSlice(0, dLen)
	//suit 1-4
	for i := 0; i < dLen; i++ {
		s[i] = c.calCardAmountOfTheSameSuit(pokerMap, i+1) //suit = 1-4=index +1
	}
	return s
}

// calCardAmountOfTheSameNumber 算 poker map 裡指定數字有幾張(element!=noUse)
// [[101,-1,...]
// [201,-1,...]
// [301,-1,...]
// [401,-1,...]]
func (c *Core) calCardAmountOfTheSameNumber(pokerMap [][]int, cardNum int) int {
	if cardNum < 1 || cardNum > 13 {
		return 0
	}
	index := c.cardNumToTheSameNumberCardAmountIndex(cardNum)
	amount := 0
	for i := 0; i < 4; i++ {
		if pokerMap[i][index] != noUse {
			amount++
		}
	}
	return amount
}

// calCardAmountOfTheSameSuit 計算 poker map 裡指定花色有幾張(element!=noUse)
func (c *Core) calCardAmountOfTheSameSuit(pokerMap [][]int, suit int) int {
	if suit < 1 || suit > 4 {
		return 0
	}
	amount := 0
	index := c.cardSuitToTheSameSuitCardAmountIndex(suit)
	s := pokerMap[index] //取指定花色這列
	for i := 0; i < len(s); i++ {
		if s[i] != noUse {
			amount++
		}
	}
	return amount
}

func (c *Core) cardNumToTheSameNumberCardAmountIndex(cardNum int) int {
	return cardNum - 1
}
func (c *Core) cardSuitToTheSameSuitCardAmountIndex(suit int) int {
	return suit - 1
}
func (c *Core) theSameNumberCardAmountIndexToCardNum(index int) int {
	return index + 1
}
func (c *Core) theSameSuitCardAmountIndexToCardSuit(index int) int {
	return index + 1
}

func (c *Core) cardsToSortNumbers(cards []int) (s []int) {
	for _, v := range cards {
		s = append(s, c.cardIDToSortNumber(v))
	}
	sort.Ints(s)
	return s
}

func (c *Core) sortNumbersToCards(numbers []int) (s []int) {
	for _, v := range numbers {
		s = append(s, c.sortNumberToCardID(v))
	}
	return s
}

// 將 cardID 轉排序用的 number
func (c *Core) cardIDToSortNumber(id int) int {
	var x int = id / 100
	var y int = id % 100
	x = x + (y * 5)
	//Ace
	if y == 1 {
		x += 100 //超過100=Ace
	}
	return x
}

// 將排序用的 number 轉 cardID
func (c *Core) sortNumberToCardID(num int) int {
	if num > 100 {
		num -= 100 //超過100=Ace,先扣掉
	}
	var x int = num / 5
	var y int = num % 5
	return (y * 100) + x
}

// 四種花色 pokerMap 四種花色合成一列
// 如果有重複的號碼，保留大的那張 {101,201} 保留 201
// 用來判斷是否有順
func (c *Core) mergeCardsIntoOneRow(pokerMap [][]int) []int {

	temp := sliceUtil.MakeSlice(noUse, 13)

	pl := len(pokerMap)
	sl := 0
	for i := 0; i < pl; i++ {
		sl = len(pokerMap[i])
		for j := 0; j < sl; j++ {
			p := pokerMap[i][j]
			if p > temp[j] {
				temp[j] = p
			}
		}
	}
	return temp
}

// 傳入的5張牌，最後一張是否 Ace
func (c *Core) isBiggestCardAce(cards []int) (yes bool) {

	if _, n := c.cardContent(cards[len(cards)-1]); n == PokerAce {
		return true
	}
	return false
}

// 傳入的5張牌，是否形成同花
func (c *Core) isFlushByCards(cards []int) (yes bool) {

	suit, _ := c.cardContent(cards[0]) //取第一個suit
	for _, v := range cards {
		s, _ := c.cardContent(v)
		if s != suit {
			return false
		}
	}
	return true
}

/*
以下判斷是否有牌型
*/
//determineStraightFlush 傳入定好規格的13張牌，是否同花順
//有的話回傳同花順
func (c *Core) determineStraightFlush(cardsInOnRow []int) (straightFlush [][]int, yes bool) {
	if len(cardsInOnRow) != 13 {
		return
	}
	//取出所有的順
	if straights, y := c.determineStraight(cardsInOnRow); y {
		for j := 0; j < len(straights); j++ {
			//判斷取出的順，是否同花
			if c.isFlushByCards(straights[j]) {
				yes = true
				straightFlush = append(straightFlush, straights[j])
			}
		}
	}
	return
}

// 傳入定好規格的13張牌，是否有順
func (c *Core) determineStraight(cardsInOneRow []int) (straights [][]int, yes bool) {
	if len(cardsInOneRow) != 13 {
		return straights, false
	}
	for i, v := range cardsInOneRow {
		if i < 9 && (v^noUse) != 0 &&
			(cardsInOneRow[i+1]^noUse) != 0 &&
			(cardsInOneRow[i+2])^noUse != 0 &&
			(cardsInOneRow[i+3])^noUse != 0 &&
			(cardsInOneRow[i+4])^noUse != 0 {
			yes = true
			straights = append(straights, []int{v, cardsInOneRow[i+1], cardsInOneRow[i+2], cardsInOneRow[i+3], cardsInOneRow[i+4]})
		} else if i == 9 && (v^noUse) != 0 &&
			(cardsInOneRow[i+1]^noUse) != 0 &&
			(cardsInOneRow[i+2])^noUse != 0 &&
			(cardsInOneRow[i+3])^noUse != 0 &&
			(cardsInOneRow[0])^noUse != 0 {
			yes = true
			straights = append(straights, []int{v, cardsInOneRow[i+1], cardsInOneRow[i+2], cardsInOneRow[i+3], cardsInOneRow[0]})
		}
	}
	return straights, yes
}

// 是否有同花，且回傳最大的同花
func (c *Core) determineFlush(theSameSuitCardAmount []int) (suit int, yes bool) {
	suit = 0
	got := false
	for i, v := range theSameSuitCardAmount {
		if v >= 5 {
			got = true
			suit = c.pickBigSuit(suit, c.theSameSuitCardAmountIndexToCardSuit(i))
		}
	}

	return suit, got
}

// determineFourOfAKind，如果有鐵支，返回最大的鐵支
func (c *Core) determineFourOfAKind(theSameNumCardAmount []int) (num int, yes bool) {
	if n, y := c.pickBiggestNumberOfSpecificAmountCard(theSameNumCardAmount, 4); y {
		return n, true
	}
	return -1, false
}

// determineThreeOfAKind，如果有3條，返回最大的3條
func (c *Core) determineThreeOfAKind(theSameNumCardAmount []int) (num int, yes bool) {
	if n, y := c.pickBiggestNumberOfSpecificAmountCard(theSameNumCardAmount, 3); y {
		return n, true
	}
	return -1, false
}

// determinePairs，返回最多兩個最大的 pair，有可能沒有或只有一個
func (c *Core) determinePairs(cards []int, theSameNumCardAmount []int) (card0, card1 []int, pairType int) {

	pairType = HighCard //散牌
	//num0, num1 = -1, -1

	//複製一份
	temp := make([]int, len(theSameNumCardAmount))
	copy(temp, theSameNumCardAmount)

	//先選第一個pair
	if n, y := c.pickBiggestNumberOfSpecificAmountCard(temp, 2); y {
		temp[n-1] = 0 //剛選的num,數量改成0，之後不會被選到
		//選出同號碼的牌
		card0 = c.pickTheSameNumberCards(cards, n)
	}
	//再選第二個最大的
	if n, y := c.pickBiggestNumberOfSpecificAmountCard(temp, 2); y {
		temp[n-1] = 0
		card1 = c.pickTheSameNumberCards(cards, n)
	}

	if len(card0) > 0 {
		if len(card1) > 0 {
			pairType = TwoPair // 對子
		} else {
			pairType = Pair
		}
	}
	return card0, card1, pairType
}

/*
以下處裡牌型
*/
//處理同花順，回傳最大的同花順5張
func (c *Core) processStraightFlush(pokerMap [][]int) (straight []int, handType int, yes bool) {
	handType = HighCard
	straight = []int{}

	var ss [][]int
	for i := 0; i < len(pokerMap); i++ {
		straightFlush, y := c.determineStraightFlush(pokerMap[i])
		if y {
			ss = append(ss, straightFlush...)
		}
	}
	//有同花順,如果超過1 組，取最大的
	sLen := len(ss)
	if sLen > 0 {
		handType = StraightFlush
		yes = true
		if sLen > 1 {
			straight = c.pickBiggestStraight(ss)
		} else {
			straight = ss[0]
		}

		if c.isBiggestCardAce(straight) {
			handType = RoyalFlush
		}
	}

	return straight, handType, yes
}
func (c *Core) processFourOfAKing(cards, theSameNumberCardAmount []int) (pickCards []int, yes bool) {
	//判斷鐵支
	if num, y := c.determineFourOfAKind(theSameNumberCardAmount); y {
		//挑出這四張牌
		pickCards = c.pickTheSameNumberCards(cards, num)
		//取cards，不包括這幾張
		temp := c.deleteTargetCards(cards, pickCards)
		//挑出最大的幾張
		pc := c.pickBiggestCards(temp, 1)

		pickCards = append(pickCards, pc[0])
		return pickCards, true
	}
	return []int{}, false
}

func (c *Core) processFullHouse(cards, theSameNumCardAmount []int) (pickCards []int, yes bool) {
	//判斷3條
	if num3k, y := c.determineThreeOfAKind(theSameNumCardAmount); y {

		//判斷pair
		if p0, _, pt := c.determinePairs(cards, theSameNumCardAmount); pt == TwoPair || pt == Pair {
			//挑出3條3張
			num3kCards := c.pickTheSameNumberCards(cards, num3k)

			pickCards = append(num3kCards, p0...)
			return pickCards, true
		}
	}
	return []int{}, false
}

func (c *Core) processFlush(cards, theSameSuitCardAmount []int) (pickCards []int, yes bool) {
	//判斷同花
	if suit, y := c.determineFlush(theSameSuitCardAmount); y {

		//挑出所有同花色
		s := c.pickTheSameSuitCards(cards, suit)

		//轉 sort num
		temp := c.cardsToSortNumbers(s)

		//取最大5張
		nums := c.pickBiggestSortNumbers(temp, 5)

		//轉回 cardID
		pickCards = c.sortNumbersToCards(nums)

		return pickCards, true
	}
	return []int{}, false
}
func (c *Core) processStraight(cardsInOneRow []int) (straight []int, yes bool) {
	if st, y := c.determineStraight(cardsInOneRow); y {
		s := c.pickBiggestStraight(st)
		return s, true
	}
	return []int{}, false
}

func (c *Core) processThreeOfAKing(cards, theSameNumberCardAmount []int) (pickCards []int, yes bool) {
	//判斷鐵支
	if num, y := c.determineThreeOfAKind(theSameNumberCardAmount); y {
		//挑出這幾張牌
		pickCards = c.pickTheSameNumberCards(cards, num)
		//取cards，不包括這幾張
		temp := c.deleteTargetCards(cards, pickCards)
		//取最大的幾張
		pc := c.pickBiggestCards(temp, 2)

		pickCards = append(pickCards, pc...)
		return pickCards, true
	}
	return []int{}, false
}

// 處理two pair or pair
func (c *Core) processPair(cards []int, theSameNumberCardAmount []int) (pickCards []int, handType int, yes bool) {

	pickCards = []int{}
	c0, c1, pairType := c.determinePairs(cards, theSameNumberCardAmount)

	//判斷 two pair
	if pairType == TwoPair {
		temp := c.deleteTargetCards(cards, c0)
		temp = c.deleteTargetCards(temp, c1)

		//取一張最大的，不包括這幾張
		pc := c.pickBiggestCards(temp, 1)

		pickCards = append(c0, c1...)
		pickCards = append(pickCards, pc[0])
		return pickCards, TwoPair, true
	}

	//盼對 pair
	if pairType == Pair {
		temp := c.deleteTargetCards(cards, c0)

		//取3張最大的，不包括這幾張
		pc := c.pickBiggestCards(temp, 3)
		pickCards = append(c0, pc...)

		return pickCards, Pair, true
	}

	return pickCards, HighCard, false
}

// 判斷 cardID0 大於 cardID1, 先比數字再比花色
func (c *Core) isCard0BigCard1(cardID0, cardID1 int) bool {
	//同 id
	if cardID0 == cardID1 {
		return true
	}

	s0, num0 := c.cardContent(cardID0)
	s1, num1 := c.cardContent(cardID1)

	//數字相同
	if num0 == num1 {
		//比花色
		if s0 > s1 {
			return true
		}
		return false
	}

	//數字不同，比數字
	if num0 == 1 || (num0 > num1) {
		return true
	}

	return false
}

// pickBiggestNumberOfSpecificAmountCard 找出最大的、指定數量張數的牌號碼
// targetAmount=4, 找出最大的四條
// targetAmount=3 找出最大的三條，只能3張，不能是 4張
// targetAmount=2 找出最大的pair，只能2張，不能是 3張
func (c *Core) pickBiggestNumberOfSpecificAmountCard(theSameNumCardAmount []int, targetAmount int) (number int, yes bool) {

	//先找A
	if theSameNumCardAmount[0] == targetAmount {
		return c.theSameNumberCardAmountIndexToCardNum(0), true
	}
	//然後從後往前找
	for i := len(theSameNumCardAmount) - 1; i > 0; i-- {
		if theSameNumCardAmount[i] == targetAmount {
			return c.theSameNumberCardAmountIndexToCardNum(i), true
		}
	}
	return -1, false
}

// 選出大的花色，suit 大，花色大。
func (c *Core) pickBigSuit(suit0, suit1 int) int {
	if suit1 > suit0 {
		return suit1
	}
	return suit0
}

// 挑出相同 num 的牌
func (c *Core) pickTheSameNumberCards(cards []int, num int) (pickCard []int) {
	for _, id := range cards {
		if _, n := c.cardContent(id); n == num {
			pickCard = append(pickCard, id)
		}
	}
	return pickCard
}
func (c *Core) pickTheSameSuitCards(cards []int, suit int) (pickCard []int) {
	for _, id := range cards {
		if s, _ := c.cardContent(id); s == suit {
			pickCard = append(pickCard, id)
		}
	}
	return pickCard
}

// 從 sort numbers 選最大的 n 張牌
func (c *Core) pickBiggestSortNumbers(sortNumbers []int, amount int) (pickCards []int) {

	sl := len(sortNumbers)
	if amount > sl || amount == sl {
		return sortNumbers
	}

	return sortNumbers[sl-amount:]
}

// 從傳入的 cards 中 挑出選大的 amount 張
func (c *Core) pickBiggestCards(cards []int, amount int) (pickCards []int) {

	//轉 sort num
	nums := c.cardsToSortNumbers(cards)

	pc := c.pickBiggestSortNumbers(nums, amount)

	for _, v := range pc {
		pickCards = append(pickCards, c.sortNumberToCardID(v))
	}

	return pickCards
}

// pickBiggestStraight 取最大的 straight。
// 傳入的 st 長度是5。傳入的 st 牌已經從 increasing 排序
// 回傳最大的 straight 5張牌
func (c *Core) pickBiggestStraight(st [][]int) []int {

	if len(st) == 0 {
		return []int{}
	}

	bigIndex := -1
	bigID := 0
	got := false
	for i := 0; i < len(st); i++ {
		if len(st[i]) == 5 {
			got = true
			id := st[i][4] //取最後一張牌
			if bigID == 0 || c.isCard0BigCard1(id, bigID) {
				bigIndex = i
				bigID = id
			}
		}
	}
	if got {
		return st[bigIndex]
	}
	return []int{}
}

func (c *Core) deleteTargetCards(cards, targetCards []int) []int {
	temp := make([]int, len(cards))
	copy(temp, cards)

	for _, id := range targetCards {
		for j := 0; j < len(temp); j++ {
			if id == temp[j] {
				temp = c.removeCard(temp, j)
				j = 0 //reset
			}
		}

	}
	return temp
}

func (c *Core) copyPokerMapWithoutTargetCards(pokerMap [][]int, targetCards []int) [][]int {

	d0 := len(pokerMap)
	d1 := len(pokerMap[0])
	temp := sliceUtil.Make2DSlice(noUse, d0, d1)

	//複製 pokerMap 到 temp
	//targetCards裡面的不複製
	isTarget := false
	for i := 0; i < d0; i++ {
		for j := 0; j < d1; j++ {
			isTarget = false
			t := pokerMap[i][j]
			for _, v := range targetCards {
				if t == v {
					isTarget = true
					break
				}
			}
			if isTarget {
				break
			} else {
				temp[i][j] = t
			}
		}
	}
	return temp
}

// 檢查牌id 是否合法
func (c *Core) checkCards(cards []int) bool {
	//先排序
	sort.Ints(cards)

	max := len(cards) - 2
	for i, v := range cards {
		s, n := c.cardContent(v)
		if s < club || s > spade || n < PokerAce || n > PokerK {
			return false
		}

		//重複
		if i <= max && v == cards[i+1] {
			return false
		}
	}

	return true
}

// GetPokerResult 回傳5張牌，及牌型
func (c *Core) GetPokerResult(cards []int) (match []int, handType int, err error) {
	//傳入cards數量有錯
	if len(cards) < 5 || len(cards) > 13 {
		return cards, HighCard, fmt.Errorf("GetPokerResult cards len error %d", len(cards))
	}

	//檢查傳入的 card id
	if !c.checkCards(cards) {
		return cards, HighCard, fmt.Errorf("GetPokerResult cards content error")
	}

	//依據傳入的 cards 建立基本資料
	pokerMap := c.createPokerMapWithCards(cards)

	//用 pokerMap 去判斷同花順
	if sf, handType, yes := c.processStraightFlush(pokerMap); yes {
		return sf, handType, nil
	}

	//建立基本資料
	theSameNumberCardAmount := c.createTheSameNumberCardAmount(pokerMap)
	theSameSuitCardAmount := c.createTheSameSuitCardAmount(pokerMap)
	cardsInOneRow := c.mergeCardsIntoOneRow(pokerMap)

	//處理鐵支
	if pickCards, yes := c.processFourOfAKing(cards, theSameNumberCardAmount); yes {
		return pickCards, FourOfAKind, nil
	}

	//處理fullHouse
	if pickCards, yes := c.processFullHouse(cards, theSameNumberCardAmount); yes {
		return pickCards, FullHouse, nil
	}

	//處理同花
	if pickCards, yes := c.processFlush(cards, theSameSuitCardAmount); yes {
		return pickCards, Flush, nil
	}

	//處理順子
	if straight, yes := c.processStraight(cardsInOneRow); yes {
		return straight, Straight, nil
	}

	//處理3條
	if king3, yes := c.processThreeOfAKing(cards, theSameNumberCardAmount); yes {
		return king3, ThreeOfAKind, nil
	}

	if pair, handType, yes := c.processPair(cards, theSameNumberCardAmount); yes {
		return pair, handType, nil
	}

	//highCard 選五張最大的
	pc := c.pickBiggestCards(cards, 5)
	return pc, HighCard, nil
}
