package core

import (
	"encoding/json"
	"fmt"
	"github.com/idtksrv/simulator-server/internal/configuration"
	"github.com/shopspring/decimal"
	"reflect"
	"testing"
)

var (

	//bet data
	//betTimes  = 1
	lineBet   = 50.0
	lines     = 25
	coinValue = 1.0
	betCredit = lineBet * float64(lines) * coinValue

	//FXT=5x3
	fxtBaseReel = [][]int{
		{1, 5, 6, 3, 7, 8, 4, 6, 8, 9, 9, 9, 7, 6, 3, 5, 6, 4, 6, 8, 1, 8, 5, 0, 0, 0, 5, 7, 9, 9, 6, 7, 8, 2, 6, 5, 1, 7, 6, 4, 5, 8, 2, 5, 7, 2, 5, 7, 8, 2, 6, 5, 1, 7, 6, 4, 5, 8},
		{2, 5, 7, 3, 7, 8, 1, 6, 8, 9, 9, 9, 5, 6, 1, 8, 6, 4, 6, 7, 3, 8, 8, 9, 9, 7, 5, 3, 5, 8, 3, 7, 8, 2, 6, 5, 0, 0, 0, 4, 5, 8, 2, 5, 7, 2, 5, 7, 1, 7, 6, 4, 5, 8, 2, 5, 6, 4, 5, 8, 2, 5, 7, 2, 5, 7, 2},
		{1, 5, 6, 3, 7, 8, 4, 6, 8, 9, 9, 9, 5, 6, 0, 0, 0, 7, 6, 4, 5, 8, 2, 5, 7, 2, 5, 7, 9, 9, 5, 7, 8, 3, 6, 5, 1, 7, 6, 4, 5, 8, 2, 7, 5, 3, 5, 7, 2, 6, 5, 1, 7, 6, 2, 5, 7, 2, 5, 7, 1, 7, 6, 7, 1, 7, 6},
		{1, 5, 6, 3, 5, 8, 2, 6, 8, 9, 9, 9, 5, 8, 0, 0, 0, 5, 6, 4, 5, 8, 3, 5, 7, 2, 5, 7, 9, 9, 3, 7, 8, 2, 6, 5, 1, 7, 6, 5, 1, 7, 6, 4, 5, 8, 2, 5, 7, 2, 5, 7, 1, 7, 7, 1, 7, 6, 1, 7, 6, 4, 5, 8, 8, 2, 5},
		{1, 5, 6, 2, 7, 8, 1, 6, 8, 9, 9, 9, 5, 7, 0, 0, 0, 0, 7, 4, 5, 8, 2, 5, 7, 3, 5, 7, 9, 9, 3, 7, 8, 3, 6, 5, 1, 7, 6, 4, 5, 8, 2, 5, 7, 0, 0, 0, 8, 7, 1, 7, 6, 4, 5, 8, 2, 5, 6, 4, 5, 8, 2, 5, 6},
	}

	fxtPayLine = [][]int{
		{1, 1, 1, 1, 1},
		{0, 0, 0, 0, 0},
		{2, 2, 2, 2, 2},
		{0, 1, 2, 1, 0},
		{2, 1, 0, 1, 2},

		{0, 1, 1, 1, 0},
		{2, 1, 1, 1, 2},
		{1, 0, 0, 0, 1},
		{1, 2, 2, 2, 1},
		{0, 1, 0, 1, 0},

		{2, 1, 2, 1, 2},
		{1, 0, 1, 0, 1},
		{1, 2, 1, 2, 1},
		{2, 2, 1, 0, 0},
		{0, 0, 1, 2, 2},

		{0, 0, 1, 0, 0},
		{2, 2, 1, 2, 2},
		{1, 1, 0, 1, 1},
		{1, 1, 0, 1, 1},
		{1, 0, 2, 0, 1},

		{1, 2, 0, 2, 1},
		{0, 0, 2, 0, 0},
		{2, 2, 0, 2, 2},
		{1, 0, 1, 2, 1},
		{1, 2, 1, 0, 1},
	}

	fxtPayTable = []*BasePayTable{
		{
			SymbolID: 0,
			PayRate:  []float64{0, 0, 0, 25, 250, 500},
		},
		{
			SymbolID: 1,
			PayRate:  []float64{0, 0, 0, 25, 250, 500},
		},
		{
			SymbolID: 2,
			PayRate:  []float64{0, 0, 0, 20, 150, 400},
		},
		{
			SymbolID: 3,
			PayRate:  []float64{0, 0, 0, 15, 100, 300},
		},
		{
			SymbolID: 4,
			PayRate:  []float64{0, 0, 0, 10, 50, 200},
		},
		{
			SymbolID: 5,
			PayRate:  []float64{0, 0, 0, 10, 20, 50},
		},
		{
			SymbolID: 6,
			PayRate:  []float64{0, 0, 0, 5, 20, 50},
		},
		{
			SymbolID: 7,
			PayRate:  []float64{0, 0, 0, 5, 20, 50},
		},
		{
			SymbolID: 8,
			PayRate:  []float64{0, 0, 0, 5, 20, 50},
		},
		{
			SymbolID: 9,
			PayRate:  []float64{0, 0, 0, 0, 0, 0},
		},
	}

	ActiveFreeSpinScatterMoreEqual = 6

	//3x3
	//tXT=5x3
	baseReel3Column = [][]int{
		{1, 5, 6, 3, 7, 8, 4, 6, 8, 9, 9, 9, 7, 6, 3, 5, 6, 4, 6, 8, 1, 8, 5, 0, 0, 0, 5, 7, 9, 9, 6, 7, 8, 2, 6, 5, 1, 7, 6, 4, 5, 8, 2, 5, 7, 2, 5, 7, 8, 2, 6, 5, 1, 7, 6, 4, 5, 8},
		{2, 5, 7, 3, 7, 8, 1, 6, 8, 9, 9, 9, 5, 6, 1, 8, 6, 4, 6, 7, 3, 8, 8, 9, 9, 7, 5, 3, 5, 8, 3, 7, 8, 2, 6, 5, 0, 0, 0, 4, 5, 8, 2, 5, 7, 2, 5, 7, 1, 7, 6, 4, 5, 8, 2, 5, 6, 4, 5, 8, 2, 5, 7, 2, 5, 7, 2},
		{1, 5, 6, 3, 7, 8, 4, 6, 8, 9, 9, 9, 5, 6, 0, 0, 0, 7, 6, 4, 5, 8, 2, 5, 7, 2, 5, 7, 9, 9, 5, 7, 8, 3, 6, 5, 1, 7, 6, 4, 5, 8, 2, 7, 5, 3, 5, 7, 2, 6, 5, 1, 7, 6, 2, 5, 7, 2, 5, 7, 1, 7, 6, 7, 1, 7, 6},
	}
	payLine3x3 = [][]int{
		{1, 1, 1},
		{0, 0, 0},
		{2, 2, 2},
		{0, 1, 2},
		{2, 1, 0},
	}
	//5x4
	baseReel5Column = [][]int{
		{1, 1, 1, 1, 5, 6, 5, 6, 0, 0, 0, 0, 8, 7, 8, 5, 10, 6, 7, 5, 8, 8, 2, 2, 5, 6, 5, 6, 3, 3, 5, 6, 4, 4, 8, 5, 10, 7, 6, 6, 4, 4, 7, 8, 7, 5, 8, 5, 3, 3, 5, 5, 7, 2, 2, 2, 2, 6, 7, 6, 4, 4, 8, 7, 0, 0, 8, 7, 3, 3, 7, 7, 8, 8, 4, 4, 4, 4},
		{1, 1, 1, 1, 5, 8, 5, 8, 0, 0, 0, 0, 5, 5, 6, 6, 10, 6, 7, 7, 6, 8, 2, 2, 2, 2, 8, 6, 3, 3, 5, 5, 4, 4, 8, 5, 10, 7, 6, 6, 4, 4, 7, 7, 5, 10, 8, 5, 3, 3, 5, 5, 7, 4, 4, 4, 4, 6, 7, 6, 4, 4, 8, 7, 3, 3, 3, 3, 6, 8, 8, 5, 5, 3, 3, 7, 7, 8, 8, 6, 6},
		{1, 1, 1, 1, 5, 8, 5, 8, 0, 0, 0, 0, 5, 5, 8, 8, 2, 2, 2, 2, 6, 8, 0, 0, 0, 0, 6, 8, 3, 3, 5, 5, 4, 4, 8, 5, 10, 7, 6, 6, 4, 4, 7, 7, 5, 10, 8, 5, 3, 3, 5, 5, 7, 4, 4, 4, 4, 6, 7, 6, 4, 4, 8, 7, 3, 3, 3, 3, 6, 8, 8, 5, 5, 3, 3, 5, 5, 7, 7, 5, 5},
		{1, 1, 1, 1, 5, 7, 5, 7, 0, 0, 0, 0, 5, 5, 8, 8, 2, 2, 2, 2, 6, 8, 0, 0, 0, 0, 6, 8, 3, 3, 5, 5, 4, 4, 8, 8, 10, 7, 6, 6, 4, 4, 7, 7, 8, 10, 5, 5, 3, 3, 5, 5, 7, 4, 4, 4, 4, 6, 7, 6, 4, 4, 8, 7, 3, 3, 3, 3, 5, 8, 8, 5, 5, 3, 3, 7, 7, 6, 6, 5, 5},
		{1, 1, 1, 1, 5, 7, 5, 7, 0, 0, 0, 0, 5, 5, 8, 8, 2, 2, 2, 2, 6, 8, 0, 0, 0, 0, 6, 8, 3, 3, 5, 5, 4, 4, 8, 8, 10, 7, 6, 6, 4, 4, 7, 7, 8, 10, 5, 5, 3, 3, 5, 5, 7, 4, 4, 4, 4, 7, 6, 6, 4, 4, 8, 7, 3, 3, 3, 3, 5, 8, 8, 5, 5, 3, 7, 5, 0, 0, 7, 5, 5},
	}

	payLine5x4 = [][]int{
		{1, 1, 1, 1, 1},
		{2, 2, 2, 2, 2},
		{0, 0, 0, 0, 0},
		{3, 3, 3, 3, 3},

		{1, 2, 3, 2, 1},
		{2, 1, 0, 2, 1},
		{0, 0, 1, 2, 3},
		{3, 3, 2, 1, 0},

		{1, 0, 0, 0, 1},
		{2, 3, 3, 3, 2},
		{0, 1, 2, 3, 3},
		{3, 2, 1, 0, 0},

		{1, 0, 1, 2, 1},
		{2, 3, 2, 1, 2},
		{0, 1, 0, 1, 0},
		{3, 2, 3, 2, 3},

		{1, 2, 1, 0, 1},
		{2, 1, 2, 3, 2},
		{0, 1, 1, 1, 0},
		{3, 2, 2, 2, 3},

		{1, 1, 2, 3, 3},
		{2, 2, 1, 0, 0},
		{1, 1, 0, 1, 1},
		{2, 2, 3, 2, 2},

		{1, 2, 2, 2, 3},
		{2, 1, 1, 1, 0},
		{0, 0, 1, 0, 0},
		{3, 3, 2, 3, 3},

		{0, 1, 2, 2, 3},
		{3, 2, 1, 1, 0},
		{0, 0, 0, 1, 2},
		{3, 3, 3, 2, 1},

		{1, 0, 0, 1, 2},
		{2, 3, 3, 2, 1},
		{0, 1, 1, 2, 3},
		{3, 2, 2, 1, 0},

		{1, 0, 1, 2, 3},
		{2, 3, 2, 1, 0},
		{0, 1, 2, 3, 2},
		{3, 2, 1, 0, 1},

		{1, 0, 1, 0, 1},
		{2, 3, 2, 3, 2},
		{0, 1, 0, 1, 2},
		{3, 2, 3, 2, 1},

		{2, 1, 0, 0, 1},
		{1, 2, 3, 3, 2},
		{2, 1, 0, 0, 0},
		{1, 2, 3, 3, 3},

		{0, 0, 2, 2, 2},
		{3, 3, 2, 1, 1},
	}
)

func UnmarshalBaseSetting(st json.RawMessage, gameSettingID int) (*BaseSetting, error) {
	var gs []struct {
		MainGameSettingID int
		BaseSetting       *BaseSetting
	}

	if err := json.Unmarshal(st, &gs); err != nil {
		return nil, err
	}
	for _, setting := range gs {
		if setting.MainGameSettingID == gameSettingID {
			return setting.BaseSetting, nil
		}
	}
	return nil, fmt.Errorf("not found")
}

func TestBaseSlot_RTPTest(t *testing.T) {
	mainGameType := 2700
	mainGameSettingID := 1

	betTimes := 1
	betTotal := float64(betTimes) * betCredit
	var payCreditTotal float64
	freeSpinTimes := 0
	freeSpinProbability := 0.0

	configurator, err := configuration.NewConfigurator("config.json")
	if err != nil {
		t.Fatalf("err=%s\n", err.Error())
	}

	gs, err := configurator.GetMainGameSetting(mainGameType, mainGameSettingID)
	if err != nil {
		t.Fatalf("GetMainGameSetting %s", err)
	}

	game := &Core{}

	bs, err := UnmarshalBaseSetting(gs.GameSetting, mainGameSettingID)
	if err != nil {
		t.Fatalf("unmarshalBaseSetting error %s", err)
	}
	args := &GetResultArgs{
		Reel:                     fxtBaseReel,
		LineBet:                  lineBet,
		Lines:                    lines,
		CoinValue:                coinValue,
		BetCredit:                betCredit,
		IsSpecificThenNormalReel: false,
	}

	for i := 0; i < betTimes; i++ {
		result, err := game.GetResult(bs, args)
		if err != nil {
			t.Fatalf("GetResult error %s", err)
		}

		if result.ScatterInfo.Amount >= ActiveFreeSpinScatterMoreEqual {
			freeSpinTimes++
		}
		payCreditTotal += result.PayCreditTotal
	}

	freeSpinProbability = float64(freeSpinTimes) / float64(betTimes)
	t.Logf("--- BET DATA\n")
	t.Logf("Bet %.0f", betCredit)
	t.Logf("Bet times %d", betTimes)
	t.Logf("--- GAME\n")
	t.Logf("RTP :%.2f%%", (payCreditTotal/betTotal)*100)
	t.Logf("Total bet %.0f ", betTotal)
	t.Logf("Payout %.0f ", payCreditTotal)
	t.Logf("Free spin times %d probability %0.3f%%", freeSpinTimes, freeSpinProbability*100)

}

func TestBaseSlot_GetResult(t *testing.T) {

	bs := &BaseSetting{
		ColumnAndLine:               []int{5, 3},
		GetPrizeSymbolMinNumPerLine: 3,
		Symbol: &BaseSymbol{
			ScatterID: []int{9},
			WildID:    []int{0},
		},
		PayLine: fxtPayLine,
	}

	game := &Core{}

	_, err := game.GetResult(bs, &GetResultArgs{
		Reel:                     fxtBaseReel,
		LineBet:                  lineBet,
		Lines:                    lines,
		CoinValue:                coinValue,
		BetCredit:                betCredit,
		IsSpecificThenNormalReel: false,
		SpecificColumnAndLine:    []int{3, 5},
	})
	if err != nil {
		t.Fatalf("GetResult error %s", err)
	}
}

func TestBaseSlot_GetTwoWheelResult(t *testing.T) {

	game := &Core{}

	//result 3x3
	//specific result 3x5
	bs2 := &BaseSetting{
		ColumnAndLine:               []int{3, 3},
		GetPrizeSymbolMinNumPerLine: 3,
		Symbol: &BaseSymbol{
			ScatterID: []int{9},
			WildID:    []int{0},
		},
		PayLine: payLine3x3,
	}

	bs2r := &GetResultArgs{
		Reel:                     baseReel3Column,
		LineBet:                  lineBet,
		Lines:                    lines,
		CoinValue:                coinValue,
		BetCredit:                betCredit,
		IsSpecificThenNormalReel: true,
		SpecificColumnAndLine:    []int{3, 5},
	}

	result, specificResult, err := game.GetTwoWheelResult(bs2, bs2r)
	if err != nil {
		t.Fatalf("GetTwoWheelResult error %s", err)
	}

	t.Logf("result %v specific result %v", result, specificResult)

	bs3 := &BaseSetting{
		ColumnAndLine:               []int{5, 4},
		GetPrizeSymbolMinNumPerLine: 3,
		Symbol: &BaseSymbol{
			ScatterID: []int{9},
			WildID:    []int{0},
		},
		PayLine: payLine5x4,
	}

	bs3r := &GetResultArgs{
		Reel:                     baseReel5Column,
		LineBet:                  lineBet,
		Lines:                    lines,
		CoinValue:                coinValue,
		BetCredit:                betCredit,
		IsSpecificThenNormalReel: true,
		SpecificColumnAndLine:    []int{5, 6},
	}

	result, specificResult, err = game.GetTwoWheelResult(bs3, bs3r)
	if err != nil {
		t.Fatalf("GetTwoWheelResult error %s", err)
	}

	t.Logf("result %v specific result %v", result, specificResult)
}

/*
func TestBaseSlot_getResultReel(t *testing.T) {

	c := &core.Core{}
	type args struct {
		gameReel      [][]int
		columnAndLine []int
	}
	tests := []struct {
		name            string
		args            args
		wantRetSpinReel [][]int
		wantErr         bool
	}{
		{
			"0",
			args{
				[][]int{{1, 1, 1, 1}, {2, 2, 2}, {3}, {4, 4, 4, 4}, {5, 5, 5, 5}},
				[]int{5, 3}, //企劃 3x5, 程式 5x3
			},
			[][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}, {4, 4, 4}, {5, 5, 5}},
			false,
		},
		{
			"1",
			args{
				[][]int{{1}, {2}, {3}, {4}, {5}},
				[]int{5, 3},
			},
			[][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}, {4, 4, 4}, {5, 5, 5}},
			false,
		},
		{
			"2",
			args{
				[][]int{{1, 1, 1}, {2, 2, 2}, {2, 2, 2}, {3, 3, 3}, {4, 4, 4}},
				[]int{5, 3},
			},
			[][]int{{1, 1, 1}, {2, 2, 2}, {2, 2, 2}, {3, 3, 3}, {4, 4, 4}},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			//g := &BaseSlot{}
			gotRetResultReel, err := c.GetResultReel(tt.args.gameReel, tt.args.columnAndLine)
			if (err != nil) != tt.wantErr {
				t.Errorf("getResultReel() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			//t.Logf("%+v", gotRetResultReel)
			if !reflect.DeepEqual(gotRetResultReel, tt.wantRetSpinReel) {
				t.Errorf("getGameResultReel() gotRetSpinReel = %v, want %v", gotRetResultReel, tt.wantRetSpinReel)
			}
		})
	}
}
*/

func TestBaseSlot_createCombinationOfGameResultReelAndPayLine(t *testing.T) {

	type args struct {
		reelResult [][]int
		payLine    [][]int
	}
	tests := []struct {
		name           string
		args           args
		wantRetCompose [][]int
		wantErr        bool
	}{
		{
			"0",
			args{
				[][]int{{1, 2, 3}, {1, 2, 3}, {1, 2, 3}, {1, 2, 3}, {1, 2, 3}},
				[][]int{{0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}, {0, 1, 2, 1, 0}},
			},
			[][]int{{1, 1, 1, 1, 1}, {2, 2, 2, 2, 2}, {1, 2, 3, 2, 1}},
			false,
		},
		{
			"1",
			args{
				[][]int{{1, 2, 3}, {1, 2, 3}, {1, 2, 3}, {1, 2, 3}, {1, 2, 3}},
				[][]int{{0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}, {0, 1, 2, 1, 0}, {2, 2, 2, 2, 2}},
			},
			[][]int{{1, 1, 1, 1, 1}, {2, 2, 2, 2, 2}, {1, 2, 3, 2, 1}, {3, 3, 3, 3, 3}},
			false,
		},
		{
			"2",
			args{
				[][]int{{1, 2, 4}, {1, 2, 4}, {1, 2, 4}, {1, 2, 4}, {1, 2, 4}},
				[][]int{{0, 0, 0, 0, 0}, {1, 1, 1, 1, 1}, {0, 1, 2, 1, 0}, {2, 2, 2, 2, 2}},
			},
			[][]int{{1, 1, 1, 1, 1}, {2, 2, 2, 2, 2}, {1, 2, 4, 2, 1}, {4, 4, 4, 4, 4}},
			false,
		},
		{
			"3",
			args{
				[][]int{{6, 5, 1}, {2, 5, 7}, {5, 7, 2}, {5, 8, 2}, {5, 7, 3}},
				fxtPayLine,
			},
			[][]int{
				{5, 5, 7, 8, 7}, {6, 2, 5, 5, 5}, {1, 7, 2, 2, 3}, {6, 5, 2, 8, 5}, {1, 5, 5, 8, 3},
				{6, 5, 7, 8, 5}, {1, 5, 7, 8, 3}, {5, 2, 5, 5, 7}, {5, 7, 2, 2, 7}, {6, 5, 5, 8, 5},
				{1, 5, 2, 8, 3}, {5, 2, 7, 5, 7}, {5, 7, 7, 2, 7}, {1, 7, 7, 5, 5}, {6, 2, 7, 2, 3},
				{6, 2, 7, 5, 5}, {1, 7, 7, 2, 3}, {5, 5, 5, 8, 7}, {5, 5, 5, 8, 7}, {5, 2, 2, 5, 7},
				{5, 7, 5, 2, 7}, {6, 2, 2, 5, 5}, {1, 7, 5, 2, 3}, {5, 2, 7, 2, 7}, {5, 7, 7, 5, 7}},
			false,
		},
		{
			"4",
			args{
				[][]int{{1, 2, 3}, {1, 2, 3}, {1, 2, 3}, {4, 5, 6}, {4, 5, 6}},
				fxtPayLine,
			},
			[][]int{
				{2, 2, 2, 5, 5}, {1, 1, 1, 4, 4}, {3, 3, 3, 6, 6}, {1, 2, 3, 5, 4}, {3, 2, 1, 5, 6},
				{1, 2, 2, 5, 4}, {3, 2, 2, 5, 6}, {2, 1, 1, 4, 5}, {2, 3, 3, 6, 5}, {1, 2, 1, 5, 4},
				{3, 2, 3, 5, 6}, {2, 1, 2, 4, 5}, {2, 3, 2, 6, 5}, {3, 3, 2, 4, 4}, {1, 1, 2, 6, 6},
				{1, 1, 2, 4, 4}, {3, 3, 2, 6, 6}, {2, 2, 1, 5, 5}, {2, 2, 1, 5, 5}, {2, 1, 3, 4, 5},
				{2, 3, 1, 6, 5}, {1, 1, 3, 4, 4}, {3, 3, 1, 6, 6}, {2, 1, 2, 6, 5}, {2, 3, 2, 4, 5}},
			false,
		},
		{
			"5",
			args{
				[][]int{{0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}},
				fxtPayLine,
			},
			[][]int{
				{0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0},
			},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &Core{}
			gotRetCompose, err := g.CreateCombinationOfGameResultReelAndPayLine(tt.args.reelResult, tt.args.payLine)
			if (err != nil) != tt.wantErr {
				t.Errorf("createPayLineArray() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotRetCompose, tt.wantRetCompose) {
				t.Errorf("createPayLineArray() gotRetCompose = %v, want %v", gotRetCompose, tt.wantRetCompose)
			}
		})
	}
}

func TestBaseSlot_getGameResultReelRandomPerWheel(t *testing.T) {
	g := &Core{}

	type args struct {
		gameReel      [][]int
		columnAndLine []int
	}
	tests := []struct {
		name            string
		args            args
		wantRetSpinReel [][]int
		wantErr         bool
	}{
		{
			"0",
			args{
				[][]int{{}},
				[]int{1},
			},
			nil,
			true,
		},
		{
			"1",
			args{
				[][]int{{1, 1, 1, 1, 1}, {1, 1}},
				[]int{5, 3},
			},
			[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
			false,
		},
		{
			"2",
			args{
				[][]int{{2}},
				[]int{5, 3},
			},
			[][]int{{2, 2, 2}, {2, 2, 2}, {2, 2, 2}, {2, 2, 2}, {2, 2, 2}},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			gotRetSpinReel, err := g.GetGameResultReelRandomPerWheel(tt.args.gameReel, tt.args.columnAndLine)
			if (err != nil) != tt.wantErr {
				t.Errorf("getGameResultReelRandomPerWheel() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotRetSpinReel, tt.wantRetSpinReel) {
				t.Errorf("getGameResultReelRandomPerWheel() gotRetSpinReel = %v, want %v", gotRetSpinReel, tt.wantRetSpinReel)
			}
		})
	}
}

func TestBaseSlot_countCombinationResult(t *testing.T) {

	type args struct {
		combinationOfReelResultAndPayLine [][]int
		wildIDs                           []int
		getPrizeSymbolMinNumPerLine       int
		lineBet                           float64
		coinValue                         float64
		payTable                          []*BasePayTable
	}
	tests := []struct {
		name string
		args args
		//wantRetLineResult     []*BaseLineResult
		wantRetPayCreditTotal float64
	}{
		{
			"0",
			args{
				[][]int{{0, 0, 0, 0, 0}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			25000,
		},

		{
			"1",
			args{
				[][]int{{1, 1, 1, 1, 1}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			25000,
		},
		{
			"2",
			args{
				[][]int{{2, 2, 2, 2, 2}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			20000,
		},
		{
			"3",
			args{
				[][]int{{9, 9, 9, 9, 9}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			0,
		},
		{
			"4",
			args{
				[][]int{{0, 2, 2, 2, 2}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			20000,
		},
		{
			"5",
			args{
				[][]int{{4, 4, 4, 0, 0}}, //444,wild,wild
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			10000,
		},
		{
			"6",
			args{
				[][]int{{4, 4, 4, 1, 1}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			500,
		},
		{
			"7",
			args{
				[][]int{{5, 0, 5, 7, 6}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			500,
		},
		{
			"8",
			args{
				[][]int{{6, 0, 0, 7, 6}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			250,
		},
		{
			"9",
			args{
				[][]int{{7, 0, 0, 1, 6}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			250,
		},
		{
			"10",
			args{
				[][]int{{8, 0, 0, 7, 6}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			250,
		},

		{
			"11",
			args{
				[][]int{{7, 0, 0, 1, 6}, {8, 0, 0, 7, 6}, {9, 0, 0, 7, 6}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			500,
		},
		{
			"12",
			args{
				[][]int{{4, 0, 0, 1, 6}, {8, 0, 0, 7, 6}, {9, 0, 0, 7, 6}, {0, 0, 0, 1, 1}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			25750,
		},

		{
			"12",
			args{
				[][]int{{2, 2, 0, 2, 6}, {4, 4, 4, 0, 0}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			17500,
		},

		{
			"14",
			args{
				[][]int{
					{2, 2, 2, 5, 5}, {1, 1, 1, 4, 4}, {3, 3, 3, 6, 6}, {1, 2, 3, 5, 4}, {3, 2, 1, 5, 6},
					{1, 2, 2, 5, 4}, {3, 2, 2, 5, 6}, {2, 1, 1, 4, 5}, {2, 3, 3, 6, 5}, {1, 2, 1, 5, 4},
					{3, 2, 3, 5, 6}, {2, 1, 2, 4, 5}, {2, 3, 2, 6, 5}, {3, 3, 2, 4, 4}, {1, 1, 2, 6, 6},
					{1, 1, 2, 4, 4}, {3, 3, 2, 6, 6}, {2, 2, 1, 5, 5}, {2, 2, 1, 5, 5}, {2, 1, 3, 4, 5},
					{2, 3, 1, 6, 5}, {1, 1, 3, 4, 4}, {3, 3, 1, 6, 6}, {2, 1, 2, 6, 5}, {2, 3, 2, 4, 5}},
				[]int{0},
				3,
				lineBet,
				coinValue,
				fxtPayTable,
			},
			3000,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &Core{}
			gotRetLineResult, gotRetPayCreditTotal, _ := g.CountCombinationResult(tt.args.combinationOfReelResultAndPayLine, tt.args.wildIDs, tt.args.getPrizeSymbolMinNumPerLine, tt.args.lineBet, tt.args.coinValue, tt.args.payTable)
			//if !reflect.DeepEqual(gotRetLineResult, tt.wantRetLineResult) {
			//	t.Errorf("countPayLineResult() gotRetLineResult = %v, want %v", gotRetLineResult, tt.wantRetLineResult)
			//}
			for _, v := range gotRetLineResult {
				t.Logf("got %+v", v)
			}
			if gotRetPayCreditTotal != tt.wantRetPayCreditTotal {
				t.Errorf("countPayLineResult() gotRetPayCreditTotal = %v, want %v", gotRetPayCreditTotal, tt.wantRetPayCreditTotal)
			}
		})
	}
}

func TestBaseSlot_countConnectPayout(t *testing.T) {
	lbc := decimal.NewFromFloat(50).Mul(decimal.NewFromFloat(1)) //line bet* coin value

	type args struct {
		targetSymbolID              int
		wildIDs                     []int
		getPrizeSymbolMinNumPerLine int
		line                        []int
		payTable                    []*BasePayTable
		lbc                         decimal.Decimal
	}
	tests := []struct {
		name             string
		args             args
		wantRetID        int
		wantRetAmount    int
		wantRetPayCredit float64
		wantErr          bool
	}{
		{
			"0",
			args{
				1,
				[]int{0},
				3,
				[]int{1, 1, 1, 2, 3},
				fxtPayTable,
				lbc,
			},
			1,
			3,
			1250,
			false,
		},
		{
			"1",
			args{
				2,
				[]int{0},
				3,
				[]int{2, 1, 0, 2, 3},
				fxtPayTable,
				lbc,
			},
			2,
			1,
			0,
			false,
		},
		{
			"2",
			args{
				2,
				[]int{0},
				3,
				[]int{2, 2, 0, 2, 3},
				fxtPayTable,
				lbc,
			},
			2,
			4,
			7500,
			false,
		},
		{
			"3",
			args{
				0,
				[]int{0},
				3,
				[]int{0, 0, 0, 0, 1},
				fxtPayTable,
				lbc,
			},
			1,
			5,
			25000,
			false,
		},
		{
			"4",
			args{
				0,
				[]int{0},
				3,
				[]int{0, 2, 2, 2, 1},
				fxtPayTable,
				lbc,
			},
			2,
			4,
			7500,
			false,
		},
		{
			"5",
			args{
				0,
				[]int{0},
				3,
				[]int{0, 2, 0, 2, 1},
				fxtPayTable,
				lbc,
			},
			2,
			4,
			7500,
			false,
		},
		{
			"6",
			args{
				0,
				[]int{0},
				3,
				[]int{0, 2, 2, 0, 0},
				fxtPayTable,
				lbc,
			},
			2,
			5,
			20000,
			false,
		},
		{
			"7",
			args{
				0,
				[]int{0, 100},
				3,
				[]int{0, 0, 0, 5, 1},
				fxtPayTable,
				lbc,
			},
			0,
			3,
			1250,
			false,
		},
		{
			"8",
			args{
				0,
				[]int{0, 100},
				3,
				[]int{0, 0, 0, 5, 5},
				fxtPayTable,
				lbc,
			},
			5,
			5,
			2500,
			false,
		},
		{
			"9",
			args{
				5,
				[]int{0, 100},
				3,
				[]int{5, 0, 0, 5, 5},
				fxtPayTable,
				lbc,
			},
			5,
			5,
			2500,
			false,
		},
		{
			"10",
			args{
				5,
				[]int{0, 100},
				3,
				[]int{5, 0, 100, 5, 5},
				fxtPayTable,
				lbc,
			},
			5,
			5,
			2500,
			false,
		},
		{
			"11",
			args{
				5,
				[]int{0, 100},
				3,
				[]int{5, 0, 100, 3, 5},
				fxtPayTable,
				lbc,
			},
			5,
			3,
			500,
			false,
		},
		{
			//wild 3連線x25, 5 四連線 x20，更少
			"12",
			args{
				0,
				[]int{0, 100},
				3,
				[]int{0, 0, 100, 5, 3},
				fxtPayTable,
				lbc,
			},
			0,
			3,
			1250,
			false,
		},
		{
			//wild 3連線x25, 4 四連線 x50
			"13",
			args{
				0,
				[]int{0, 100},
				3,
				[]int{0, 0, 100, 4, 3},
				fxtPayTable,
				lbc,
			},
			4,
			4,
			2500,
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &Core{}
			gotRetID, gotRetAmount, gotRetPayCredit, err := g.countConnectPayout(tt.args.targetSymbolID, tt.args.getPrizeSymbolMinNumPerLine, tt.args.wildIDs, tt.args.line, tt.args.payTable, tt.args.lbc)
			if (err != nil) != tt.wantErr {
				t.Errorf("countConnectPayout() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotRetID != tt.wantRetID {
				t.Errorf("countConnectPayout() gotRetID = %v, want %v", gotRetID, tt.wantRetID)
			}
			if gotRetAmount != tt.wantRetAmount {
				t.Errorf("countConnectPayout() gotRetAmount = %v, want %v", gotRetAmount, tt.wantRetAmount)
			}
			if gotRetPayCredit != tt.wantRetPayCredit {
				t.Errorf("countConnectPayout() gotRetPayCredit = %v, want %v", gotRetPayCredit, tt.wantRetPayCredit)
			}
		})
	}
}

func TestBaseSlot_CountTargetNewSymbolPosition(t *testing.T) {
	type args struct {
		originalResultReel [][]int
		newResultReel      [][]int
		targetSymbolID     []int
	}
	tests := []struct {
		name            string
		args            args
		wantRetAmount   int
		wantRetPosition [][]int
		wantErr         bool
	}{
		{
			"0",
			args{
				[][]int{{9, 1, 1}, {9, 1, 1}, {9, 1, 1}, {1, 1, 1}, {1, 1, 1}},
				[][]int{{9, 1, 1}, {1, 1, 9}, {1, 1, 8}, {1, 8, 9}, {1, 1, 1}},
				[]int{8, 9},
			},
			4,
			[][]int{{-1, -1, -1}, {-1, -1, 1}, {-1, -1, 1}, {-1, 1, 1}, {-1, -1, -1}},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &Core{}
			gotRetAmount, gotRetPosition, err := g.CountTargetNewSymbolPosition(tt.args.originalResultReel, tt.args.newResultReel, tt.args.targetSymbolID)
			if (err != nil) != tt.wantErr {
				t.Errorf("CountTargetNewSymbolPosition() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotRetAmount != tt.wantRetAmount {
				t.Errorf("CountTargetNewSymbolPosition() gotRetAmount = %v, want %v", gotRetAmount, tt.wantRetAmount)
			}
			if !reflect.DeepEqual(gotRetPosition, tt.wantRetPosition) {
				t.Errorf("CountTargetNewSymbolPosition() gotRetPosition = %v, want %v", gotRetPosition, tt.wantRetPosition)
			}
		})
	}
}

func TestBaseSlot_getRealResultReelFromSpecificReel(t *testing.T) {
	type args struct {
		specificReel          [][]int
		realReelColumnAndLine []int
	}
	tests := []struct {
		name        string
		args        args
		wantRetReel [][]int
		wantErr     bool
	}{
		{
			"0",
			args{
				[][]int{{1, 2, 3, 4, 5}, {1, 2, 3, 4, 5}, {1, 2, 3, 4, 5}},
				[]int{3, 3},
			},
			[][]int{{2, 3, 4}, {2, 3, 4}, {2, 3, 4}},
			false,
		},
		{
			"1",
			args{
				[][]int{{2, 1, 1, 1, 2}, {1, 2, 2, 2, 1}, {1, 3, 3, 3, 1}},
				[]int{3, 3},
			},
			[][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &Core{}
			gotRetReel, err := g.getResultReelFromSpecificReel(tt.args.specificReel, tt.args.realReelColumnAndLine)
			if (err != nil) != tt.wantErr {
				t.Errorf("getResultReelFromSpecificReel() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotRetReel, tt.wantRetReel) {
				t.Errorf("getResultReelFromSpecificReel() gotRetReel = %v, want %v", gotRetReel, tt.wantRetReel)
			}
		})
	}
}

func TestBase_modifyReelSymbol(t *testing.T) {
	type args struct {
		targetReel           [][]int
		modifySymbol         int
		modifySymbolPosition [][]int
		targetIsLonger       bool
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{
				[][]int{{1, 1, 1, 1}, {1, 1, 1, 1}, {1, 1, 1, 1}, {1, 1, 1, 1}, {1, 1, 1, 1}},
				0,
				[][]int{{1, -1, -1, -1}, {1, -1, -1, -1}, {1, -1, -1, -1}, {1, -1, -1, -1}, {1, -1, -1, -1}},
				false,
			},
			[][]int{{0, 1, 1, 1}, {0, 1, 1, 1}, {0, 1, 1, 1}, {0, 1, 1, 1}, {0, 1, 1, 1}},
		},
		{
			"1",
			args{
				[][]int{{1, 1, 1, 1, 1, 1}, {1, 1, 1, 1, 1, 1}, {1, 1, 1, 1, 1, 1}, {1, 1, 1, 1, 1, 1}, {1, 1, 1, 1, 1, 1}},
				0,
				[][]int{{1, -1, -1, -1}, {1, -1, -1, -1}, {1, -1, -1, -1}, {1, -1, -1, -1}, {1, -1, -1, -1}},
				true,
			},
			[][]int{{1, 0, 1, 1, 1, 1}, {1, 0, 1, 1, 1, 1}, {1, 0, 1, 1, 1, 1}, {1, 0, 1, 1, 1, 1}, {1, 0, 1, 1, 1, 1}},
		},
		{
			"2",
			args{
				[][]int{{1, 1, 1, 1, 1, 1}, {1, 1, 1, 1, 1, 1}, {1, 1, 1, 1, 1, 1}, {1, 1, 1, 1, 1, 1}, {1, 1, 1, 1, 1, 1}},
				0,
				[][]int{{1, -1, -1, 1}, {1, -1, -1, 1}, {1, -1, -1, 1}, {1, -1, -1, 1}, {1, -1, -1, 1}},
				true,
			},
			[][]int{{1, 0, 1, 1, 0, 1}, {1, 0, 1, 1, 0, 1}, {1, 0, 1, 1, 0, 1}, {1, 0, 1, 1, 0, 1}, {1, 0, 1, 1, 0, 1}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := &Core{}
			if got := g.modifyReelSymbol(tt.args.targetReel, tt.args.modifySymbol, tt.args.modifySymbolPosition, tt.args.targetIsLonger); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("modifyReelSymbol() = %v, want %v", got, tt.want)
			}
		})
	}
}
