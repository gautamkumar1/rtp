package core

import "testing"

func BenchmarkShuffle(b *testing.B) {
	//與性能測試無關的code
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		//測試的code
	}
	b.StopTimer()
	//與性能測試無關的code
}
