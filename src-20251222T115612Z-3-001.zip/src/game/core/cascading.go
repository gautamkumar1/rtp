package core

import (
	"fmt"

	"github.com/idtksrv/simulator-server/internal/configuration"
	sliceUtil "github.com/idtksrv/simulator-server/internal/util/slice"
)

type Flow struct {
	SymbolID int `json:"symbol_id"`
	Amount   int `json:"amount"`
}

type CascadingResult struct {
	InitResult [][]int `json:"init_result"` //初始輪面
	Flow       []*Flow `json:"flow"`
	AddResult  [][]int `json:"add_result"` //下落的symbol,只有空位的symbol
	NewResult  [][]int `json:"new_result"` //消除後補上 add result, 最後的新輪面
	//[5,5,1],
	//[5,5,1,1],
	//[],
	//[],
	//[8,7,9,1,2,3],
	//[],
}

func (c *Core) GetEmptyCascadingResult() *CascadingResult {
	return &CascadingResult{
		[][]int{},
		[]*Flow{},
		[][]int{},
		[][]int{},
	}
}

// CascadingRecursive 掉落消除循環
func (c *Core) CascadingRecursive(setting *BaseSetting, oriResultReels, reSpinReels [][]int) (retCascadingResult []*CascadingResult, retErr error) {

	logPrefix := "Core CascadingRecursive"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logPrefix, r)
			return
		}
	}()

	retCascadingResult = []*CascadingResult{}

	var allSymbolInfo []*BaseSymbolInfo
	tempResultReel := sliceUtil.Duplicate2DSlice(oriResultReels)

LOOP:
	//計算每個symbol的數量及位置
	allSymbolInfo, _ = c.CountSymbolsInfoByID(tempResultReel, setting.Symbol.SymbolID, setting.ColumnAndLine)
	//是否有消除
	if c.IsCascading(allSymbolInfo, setting.GetPrizeSymbolMinNumPerLine) {
		//reSpin
		reSpinResultReel, _ := c.RandomWheel(reSpinReels, setting.ColumnAndLine)
		casResult, err := c.getCascadingResult(setting.GetPrizeSymbolMinNumPerLine, allSymbolInfo, tempResultReel, reSpinResultReel)
		casResult.InitResult = sliceUtil.Duplicate2DSlice(tempResultReel)

		if err != nil {
			retErr = fmt.Errorf("%s err=%s", logPrefix, err)
			return
		}
		retCascadingResult = append(retCascadingResult, casResult)

		tempResultReel = sliceUtil.Duplicate2DSlice(casResult.NewResult)
		goto LOOP
	}
	return retCascadingResult, nil

}

// IsCascading 是否有消除，
// 是否有某個 symbol 達到 get prize min num
func (c *Core) IsCascading(symbolInfo []*BaseSymbolInfo, getPrizeSymbolMinNumPerLine int) bool {
	for i, _ := range symbolInfo {
		if symbolInfo[i].Amount >= getPrizeSymbolMinNumPerLine {
			return true
		}
	}
	return false
}

// GetCascadingResult 計算這個輪面的消除結果。一個輪面有可能消多個 symbol
// cascading result 是繼承原本輪面，只補上被消除的位置
func (c *Core) getCascadingResult(getPrizeSymbolMinNumPerLine int, allSymbolInfo []*BaseSymbolInfo, oldResultWheel [][]int, reSpinReel [][]int) (retResult *CascadingResult, retErr error) {

	fl := []*Flow{}
	//check all symbol info and count pay credit
	for i, _ := range allSymbolInfo {
		info := allSymbolInfo[i]
		id := info.ID[0]
		if info.Amount >= getPrizeSymbolMinNumPerLine {
			fl = append(fl, &Flow{id, info.Amount})
		}
	}

	//沒消除
	if len(fl) == 0 {
		//cascading
		return &CascadingResult{
			InitResult: oldResultWheel,
			Flow:       fl,
			AddResult:  [][]int{},
			NewResult:  [][]int{},
		}, nil
	}
	//mark cascading symbol position as -1
	markedReels := c.MarkCascadingSymbol(oldResultWheel, allSymbolInfo, getPrizeSymbolMinNumPerLine)

	//取得重整的輪面
	downReels := c.DownSymbol(markedReels, configuration.SymbolIDNotUse)

	//新 wheel 加到 down wheel 上
	addResult, newResult := c.ComposeNewWheel(reSpinReel, downReels)

	//cascading
	cas := &CascadingResult{
		Flow:      fl,
		AddResult: addResult,
		NewResult: newResult,
	}

	return cas, nil
}

// MarkCascadingSymbol 依據 allSymbolInfo 找出數量有中獎的symbol, mark no use
func (c *Core) MarkCascadingSymbol(resultReel [][]int, allSymbolInfo []*BaseSymbolInfo, getPrizeSymbolMinNumPerLine int) [][]int {

	reel := sliceUtil.Duplicate2DSlice(resultReel)

	for i, _ := range allSymbolInfo {
		info := allSymbolInfo[i]
		if info.Amount >= getPrizeSymbolMinNumPerLine {

			//找出 position 相同位置，都做記號
			for x, _ := range info.Position {
				for y, v := range info.Position[x] {
					if v == configuration.SymbolIDHas {
						reel[x][y] = configuration.SymbolIDNotUse
					}
				}
			}
		}
	}
	return reel
}

// DownSymbol 輪面落下
// 非 delete symbol 往下移, 空位 -1
// 回傳已經往下移過的輪面
// [-1,-1,7,8,9] -1=空位
func (c *Core) DownSymbol(reels [][]int, deleteSymbol int) [][]int {

	column := len(reels)
	line := len(reels[0])
	//建立一個新的 wheel, 預設 symbol -1
	ret := sliceUtil.Make2DSlice(configuration.SymbolIDNotUse, column, line)
	var writeIndex, nowSymbol int

	for i := 0; i < column; i++ {
		reel := reels[i]
		bottom := len(reel) - 1

		//檢查是否有需要刪掉的symbol
		writeIndex = bottom //從reel 最下面開始改
		//從 reel 最下方往上找
		for j := bottom; j >= 0; j-- {
			nowSymbol = reel[j]
			if nowSymbol != deleteSymbol {
				//填入到回傳的 wheel
				ret[i][writeIndex] = nowSymbol
				writeIndex--
			}
		}
	}
	return ret
}

func (c *Core) DownSymbolWithUnmovedSymbol(wheel [][]int, deleteSymbol, unmovedSymbol int) [][]int {

	column := len(wheel)
	line := len(wheel[0])
	ret := sliceUtil.Make2DSlice(configuration.SymbolIDNotUse, column, line) //有中的symbol位置,預設-1
	var writeIndex, nowSymbol int

	//先把 unmovedSymbol複製過去
	for i := 0; i < column; i++ {
		for j := 0; j < line; j++ {
			if wheel[i][j] == unmovedSymbol {
				ret[i][j] = unmovedSymbol
			}
		}
	}

	for i := 0; i < column; i++ {
		reel := wheel[i]
		bottom := len(reel) - 1

		//檢查是否有需要刪掉的symbol
		writeIndex = bottom //從reel 最下面開始改
		//從 reel 最下方往上找
		for j := bottom; j >= 0; j-- {
			nowSymbol = reel[j]
			if nowSymbol != deleteSymbol && nowSymbol != unmovedSymbol {
				//填入到回傳的 wheel
				if writeIndex = c.getNextWriteIndex(ret[i], deleteSymbol); writeIndex != -1 {
					ret[i][writeIndex] = nowSymbol
				} else {
					//沒有 deleteSymbol
					break
				}
			}
		}
	}
	return ret
}

// ChangeTargetSymbolInDownedReelsWithGivenReels
// 把 downed reels 中的 target symbol (-1), 改成 given reels 同位置 symbol
// downed reels 從下往上找空位; givenReels 是要從最下方開始補，從下往上找
// 假設 downed reels  [[-1,-1,3],[-1,-1,3]]
// 假設 given reels [[4,5,6],[4,5,6]]
// 新輪面 [[5,6,3],[5,6,3]]
// 回傳新輪面及補充輪面
func (c *Core) ChangeTargetSymbolInDownedReelsWithGivenReels(downedReels, givenReels [][]int, targetSymbolID int) (newReels, addReels [][]int) {

	addReels = [][]int{} //補充的symbol
	id := 0
	column := len(downedReels)

	//從最下面一個開始補
	for i := 0; i < column; i++ {
		reel := downedReels[i]
		s := []int{}

		//dowWheel 從下往上找
		max := len(reel) - 1
		reSpinWheelIdx := max //從最下面一個開始補
		for j := max; j > -1; j-- {
			if reel[j] == targetSymbolID {
				id = givenReels[i][reSpinWheelIdx]
				reel[j] = id
				s = append([]int{id}, s...)
				reSpinWheelIdx--
			}
		}
		addReels = append(addReels, s) //這個reel 沒有落下，就是空的 [[1],[],[1,3],[3]]
	}

	return downedReels, addReels
}

// ChangeTargetSymbolInDownedReelsWithGivenReels
// 把 downed reels 中的 target symbol (-1), 改成 given reels 同位置 symbol
// downed reels 從下往上找空位; givenReels 是要從最下方開始補，從下往上找
// 假設 downed reels  [[-1,-1,3],[-1,-1,3]]
// 假設 given reels [[4,5,6],[4,5,6]]
// 新輪面 [[5,6,3],[5,6,3]]
// 回傳新輪面及補充輪面
func (c *Core) ChangeTargetSymbolInDownedReelsWithGivenReelsV2(downedReels, givenReels [][]int, targetSymbolID int) (newReels, addReels [][]int, reSpinWheelIdxList []int) {

	addReels = [][]int{}         //補充的symbol
	reSpinWheelIdxList = []int{} //記錄目前使用到多少wheel
	id := 0
	column := len(downedReels)

	// fmt.Printf("v2 downedReels=%v\n", downedReels)
	// fmt.Printf("v2 givenReels=%v\n", givenReels)
	//從最下面一個開始補
	for i := 0; i < column; i++ {
		reel := downedReels[i]
		s := []int{}

		//dowWheel 從下往上找
		max := len(reel) - 1
		givenMax := len(givenReels[i]) - 1
		reSpinWheelIdx := givenMax //從最下面一個開始補
		for j := max; j > -1; j-- {
			if reel[j] == targetSymbolID {
				if reSpinWheelIdx < 0 {
					fmt.Printf("reSpinWheelIdx=%v, givenMax=%v\n", reSpinWheelIdx, givenMax)
					continue
				}
				id = givenReels[i][reSpinWheelIdx]
				reel[j] = id
				s = append([]int{id}, s...)
				reSpinWheelIdx--
			}
		}
		addReels = append(addReels, s)                                  //這個reel 沒有落下，就是空的 [[1],[],[1,3],[3]]
		reSpinWheelIdxList = append(reSpinWheelIdxList, reSpinWheelIdx) //記錄目前使用到多少wheel
	}

	return downedReels, addReels, reSpinWheelIdxList
}

// 將 newReels 盤面, 每中獎一次，輪軸向上拓展一行，最多拓展四行
func (c *Core) AppendRowPerRow(newReels, addReels, reSpinReels [][]int, reSpinWheelIdxList []int, downCount int) {

	if downCount == 0 {
		return // 滿足9個 row, 就不用在處理額外掉落
	}
	id := 0
	column := len(newReels)

	// fmt.Printf("newReels=%v\n", newReels)
	// fmt.Printf("addReels=%v\n", addReels)
	// fmt.Printf("reSpinReels=%v\n", reSpinReels)
	// fmt.Printf("downCount=%v, reSpinWheelIdxList=%v\n", downCount, reSpinWheelIdxList)
	//從最下面一個開始補
	for i := 0; i < column; i++ {

		s := []int{}

		reSpinWheelIdx := reSpinWheelIdxList[i] //從最下面一個開始補
		//fmt.Printf("i=%d, reSpinWheelIdx=%v\n", i, reSpinWheelIdx)
		for j := 0; j < downCount; j++ {

			if reSpinWheelIdx < 0 {
				fmt.Printf("負數 reSpinWheelIdx=%v\n", reSpinWheelIdx)
				break
			}
			// 取得要掉落的symbol
			id = reSpinReels[i][reSpinWheelIdx]
			//fmt.Printf("要掉落的symbol=%d, i=%d, reSpinWheelIdx=%v\n", id, i, reSpinWheelIdx)
			// 將掉落的symbol加到盤面上
			s = append([]int{id}, s...)
			newReels[i] = append([]int{id}, newReels[i]...) // 從上面開始補
			addReels[i] = append([]int{id}, addReels[i]...)
			reSpinWheelIdx--

		}

	}

	// fmt.Printf("newReels=%v\n", newReels)
	// fmt.Printf("addReels=%v\n", addReels)
}

// 切割出一個 column (列) 並返回指向該列元素的指標切片
func getColumn(downedReels [][]int, colIndex int) []*int {
	var column []*int
	// 遍歷每一行，提取指定列的元素指標
	for i := range downedReels {
		column = append(column, &downedReels[i][colIndex])
	}
	return column
}

// CreateNewReelsFromGivenReelsTheSamePosition
// 依據give reels 每個reel ，找出 ori reels 相對位置的 symbol, 建立成新 reels
// givenReel       [1,2]
// oriReel   [1,2,3,4,5]
// 這時候要找到的是  [4,5]
func (c *Core) CreateNewReelsFromGivenReelsTheSamePosition(oriReels, givenReels [][]int) (addReels [][]int) {

	addReels = [][]int{} //補充的symbol
	id := 0
	column := len(givenReels)

	for i := 0; i < column; i++ {
		reel := givenReels[i]
		oReel := oriReels[i]
		s := []int{}

		rLen := len(reel) - 1
		oLen := len(oReel) - 1
		ex := oLen - rLen //兩個長度有可能一樣，或是 reel 比較短， 不會 reels 比較長

		//依據 give reel 長度，從上往下找
		//oReel 要加上差距
		//reel [1,2]
		//oReel[1,2,3,4,5]
		//這時候要找到的是 [4,5]
		// reel[0] -> oReel[0+ex]
		for j := 0; j <= rLen; j++ {
			id = oReel[j+ex]
			s = append(s, id)
		}
		addReels = append(addReels, s)
	}
	return addReels

}
