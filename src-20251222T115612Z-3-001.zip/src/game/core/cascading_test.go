package core

import (
	"reflect"
	"testing"
)

func TestCore_PrintCascadingRecursive(t *testing.T) {
	type args struct {
		setting         *BaseSetting
		oriResultWheel  [][]int
		reSpinReel      [][]int
		cascadingResult []*CascadingResult
	}

	baseReel := [][]int{
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
	}
	reSpinReel := [][]int{
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
		{1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9},
	}

	c := &Core{}
	resultWheel, _ := c.RandomWheel(baseReel, []int{6, 5})

	args0 := args{
		&BaseSetting{
			ColumnAndLine:               []int{6, 5},
			Symbol:                      &BaseSymbol{SymbolID: []int{1, 2, 3, 4, 5, 6, 7, 8, 9}},
			GetPrizeSymbolMinNumPerLine: 5},
		resultWheel,
		reSpinReel,
		[]*CascadingResult{},
	}

	tests := []struct {
		name string
		args args
	}{

		{
			"0",
			args0,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			gotRetCascadingResult, _ := c.CascadingRecursive(tt.args.setting, tt.args.oriResultWheel, tt.args.reSpinReel)

			for i := 0; i < len(gotRetCascadingResult); i++ {
				t.Logf("RecycleCascading %d =======", i)
				t.Logf("InitResult= %v", gotRetCascadingResult[i].InitResult)
				for _, v := range gotRetCascadingResult[i].Flow {
					t.Logf("Flow= symbolID=%d, amount=%d", v.SymbolID, v.Amount)
				}
				t.Logf("AddResult= %v", gotRetCascadingResult[i].AddResult)
				t.Logf("NewResult= %v", gotRetCascadingResult[i].NewResult)

			}

		})
	}
}

func TestCore_CascadingRecursive(t *testing.T) {
	type args struct {
		setting        *BaseSetting
		oriResultWheel [][]int
		reSpinReel     [][]int
	}
	tests := []struct {
		name                   string
		args                   args
		wantRetCascadingResult []*CascadingResult
		wantErr                bool
	}{
		{
			"0",
			args{
				&BaseSetting{
					ColumnAndLine:               []int{3, 3},
					Symbol:                      &BaseSymbol{SymbolID: []int{1, 2, 3, 4, 5}},
					GetPrizeSymbolMinNumPerLine: 4},
				[][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}},
				[][]int{{7, 7, 7}, {8, 8, 8}, {9, 9, 9}},
			},
			[]*CascadingResult{},
			false,
		},
		{
			"1",
			args{
				&BaseSetting{
					ColumnAndLine:               []int{3, 4},
					Symbol:                      &BaseSymbol{SymbolID: []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19}},
					GetPrizeSymbolMinNumPerLine: 4},
				[][]int{{1, 1, 1, 5}, {2, 2, 2, 4}, {3, 3, 3, 2}},
				[][]int{{9, 10, 11, 12}, {13, 13, 13, 13}, {16, 16, 16, 16}},
			},
			[]*CascadingResult{
				{
					InitResult: [][]int{{1, 1, 1, 5}, {2, 2, 2, 4}, {3, 3, 3, 2}},
					Flow:       []*Flow{{2, 4}},
					AddResult:  [][]int{{}, {13, 13, 13}, {16}},
					NewResult:  [][]int{{1, 1, 1, 5}, {13, 13, 13, 4}, {16, 3, 3, 3}},
				},
			},
			false,
		},
		{
			"2",
			args{
				&BaseSetting{
					ColumnAndLine:               []int{3, 3},
					Symbol:                      &BaseSymbol{SymbolID: []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19}},
					GetPrizeSymbolMinNumPerLine: 3},
				[][]int{{1, 7, 1}, {2, 2, 3}, {4, 4, 2}},
				[][]int{{8, 8, 8}, {13, 13, 13}, {1, 1, 1}},
			},
			[]*CascadingResult{
				{
					InitResult: [][]int{{1, 7, 1}, {2, 2, 3}, {4, 4, 2}},
					Flow:       []*Flow{{2, 3}},
					AddResult:  [][]int{{}, {13, 13}, {1}},
					NewResult:  [][]int{{1, 7, 1}, {13, 13, 3}, {1, 4, 4}},
				},
				{
					InitResult: [][]int{{1, 7, 1}, {13, 13, 3}, {1, 4, 4}},
					Flow:       []*Flow{{1, 3}},
					AddResult:  [][]int{{8, 8}, {}, {1}},
					NewResult:  [][]int{{8, 8, 7}, {13, 13, 3}, {1, 4, 4}},
				},
			},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			gotRetCascadingResult, err := c.CascadingRecursive(tt.args.setting, tt.args.oriResultWheel, tt.args.reSpinReel)
			if (err != nil) != tt.wantErr {
				t.Errorf("CascadingRecursive() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			//if !reflect.DeepEqual(gotRetCascadingResult, tt.wantRetCascadingResult) {
			//	t.Errorf("CascadingRecursive() gotRetCascadingResult = %v, want %v", gotRetCascadingResult, tt.wantRetCascadingResult)
			//}

			for i := 0; i < len(gotRetCascadingResult); i++ {
				if !reflect.DeepEqual(gotRetCascadingResult[i].InitResult, tt.wantRetCascadingResult[i].InitResult) ||
					!reflect.DeepEqual(gotRetCascadingResult[i].Flow, tt.wantRetCascadingResult[i].Flow) ||
					!reflect.DeepEqual(gotRetCascadingResult[i].AddResult, tt.wantRetCascadingResult[i].AddResult) ||
					!reflect.DeepEqual(gotRetCascadingResult[i].NewResult, tt.wantRetCascadingResult[i].NewResult) {
					t.Errorf("RecycleCascading() gotRetCascadingResult InitResult= %v, want %v", gotRetCascadingResult[i].InitResult, tt.wantRetCascadingResult[i].InitResult)
					t.Errorf("RecycleCascading() gotRetCascadingResult AddResult= %v, want %v", gotRetCascadingResult[i].AddResult, tt.wantRetCascadingResult[i].AddResult)
					t.Errorf("RecycleCascading() gotRetCascadingResult NewResult= %v, want %v", gotRetCascadingResult[i].NewResult, tt.wantRetCascadingResult[i].NewResult)
					t.Errorf("RecycleCascading() gotRetCascadingResult Flow= %v, want %v", gotRetCascadingResult[i].Flow[0], tt.wantRetCascadingResult[i].Flow[0])
				}
			}
		})
	}
}

func TestCore_createNewReelsFromBottomToTopFromGivenReels(t *testing.T) {

	oriReels0 := [][]int{{1, 2, 3, 4, 5, 6}, {1, 2, 3, 4, 5, 6}}
	givenReels0 := [][]int{{1, 2, 1}, {1, 2, 1}}
	want0 := [][]int{{4, 5, 6}, {4, 5, 6}}

	type args struct {
		oriReels   [][]int
		givenReels [][]int
	}
	tests := []struct {
		name         string
		args         args
		wantAddReels [][]int
	}{
		{
			"0",
			args{
				oriReels0,
				givenReels0,
			},
			want0,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &Core{}
			if gotAddReels := c.CreateNewReelsFromGivenReelsTheSamePosition(tt.args.oriReels, tt.args.givenReels); !reflect.DeepEqual(gotAddReels, tt.wantAddReels) {
				t.Errorf("createNewReelsFromBottomToTopFromGivenReels() = %v, want %v", gotAddReels, tt.wantAddReels)
			}
		})
	}
}
