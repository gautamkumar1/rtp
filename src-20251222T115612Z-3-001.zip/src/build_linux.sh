#!/usr/bin/env bash
output_program=build/simulator-server

GOOS=linux GOARCH=amd64 \
    go build -v -trimpath \
    -o "$output_program" cmd/main.go

echo "$output_program saved"