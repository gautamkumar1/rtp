#!/usr/bin/env bash

#check data race
CGO_ENABLED=1 GOOS=linux GOARCH=amd64 \
go build -race -mod=vendor -v \
-o "build/simulator-server"
echo "simulator-server saved in build"