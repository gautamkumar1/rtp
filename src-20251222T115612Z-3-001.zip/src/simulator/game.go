package simulator

import (
	"fmt"
	"math/rand"
	"sync"

	"github.com/idtksrv/simulator-server/internal/util/slotkit"
)

var game = Game{}

type Game struct {
	start sync.Once

	// 滾輪配置 ex. 5x5x5x5x5
	reelsLayout []int

	// 圖騰列表 (id -> symbol)
	symbols slotkit.SymbolMap

	// 空白圖騰
	emptySymbol slotkit.Symbol

	// 無倍數 wild id
	baseWildId int

	// 圖騰類型 (使用 mask 來判斷)
	maskNormal  uint32
	maskScatter uint32
	maskWild    uint32

	// 賠付線
	paylines []slotkit.Payline

	// 賠付表
	paytable PayTable
}

type PayTable map[int][]float64

type PaylineResult struct {
	Id          int
	Symbol      slotkit.Symbol
	EffectGrids slotkit.Grids
}

type PaylineResults []PaylineResult

// GetEffectivePositions: 返回中獎的圖騰格位置 (不重複)
func (p PaylineResults) GetEffectivePositions() []int {
	data := map[int]struct{}{}
	for _, payline := range p {
		for p, grid := range payline.EffectGrids {
			if grid.Symbol.Match(game.maskNormal) {
				data[game.paylines[payline.Id].Positions()[p]] = struct{}{}
			}
		}
	}

	pos := []int{}
	for p := range data {
		pos = append(pos, p)
	}
	return pos
}

func (pt PayTable) GetPayout(symbol slotkit.Symbol, comb int) float64 {
	if symbol == nil || comb < 0 {
		return 0
	}
	if tb, ok := pt[symbol.Id()]; !ok || comb >= len(tb) {
		return 0
	}
	return pt[symbol.Id()][comb]
}

// 初始化遊戲
//
//	這裡會初始化滾輪配置, 圖騰, 圖騰類型, 賠付線... 等靜態資訊
//	這些資訊在遊戲中是不會變動的, 所以只需初始化一次
func (g *Game) init(setting *GameSetting) {

	g.start.Do(func() {

		// 初始化
		g.symbols = make(map[int]slotkit.Symbol)
		g.paylines = []slotkit.Payline{}

		// 建立 reels 資訊
		for reel := 0; reel < setting.BaseSetting.ColumnAndLine[1]; reel++ {
			g.reelsLayout = append(g.reelsLayout, setting.BaseSetting.ColumnAndLine[0])
		}

		// 建立 symbol map
		flag := uint32(0x0001)
		for i, id := range setting.BaseSetting.Symbol.SymbolID {
			g.symbols[id] = slotkit.NewSymbol(id, flag, fmt.Sprintf("m%d", i))
			g.maskNormal |= flag
			flag <<= 1
		}

		for i, id := range setting.BaseSetting.Symbol.ScatterID {
			g.symbols[id] = slotkit.NewSymbol(id, flag, fmt.Sprintf("S%d", i))
			g.maskScatter |= flag
			flag <<= 1
		}

		for i, id := range setting.BaseSetting.Symbol.WildID {
			g.symbols[id] = slotkit.NewSymbol(id, flag, fmt.Sprintf("W%d", i))
			g.maskWild |= flag
			flag <<= 1
		}

		// 建立空白圖騰
		g.emptySymbol = slotkit.NewSymbol(-1, flag, "__")

		// 無倍數 wild id
		g.baseWildId = setting.BaseSetting.Symbol.WildID[0]

		// 建立 pay line map
		// BaseSetting.PayLine 使用的是滾輪的位置
		// slotkit.Payline 使用的是盤面上的位置
		lines := setting.BaseSetting.PayLine
		for _, line := range lines {

			idx := 0
			dim := []int{}
			for reel, pos := range line {
				dim = append(dim, idx+pos)
				idx += g.reelsLayout[reel]
			}

			g.paylines = append(g.paylines, *slotkit.NewPayline(dim...))
		}

		// 建立 pay table
		g.paytable = make(map[int][]float64)
		for _, pay := range setting.BaseSetting.PayTable {
			g.paytable[pay.SymbolID] = pay.PayRate
		}
	})
}

func (g *Game) NewSlot(feature Feature, respin bool) *Slot {

	slot := slotkit.NewSlot(g.reelsLayout...)

	// 取得滾輪配置
	strips := feature.ReelStrips(respin)

	dbg := []int64{}
	for i, reel := range slot.Reels() {
		strip := strips[i]

		// 隨機取得滾輪的位置
		rnd := rand.Int63n(int64(len(strip)))
		dbg = append(dbg, rnd)

		symbols := g.symbols.GetSymbolsByRange(strip, int(rnd), len(reel))
		reel.SetSymbols(0, symbols...)
	}
	// fmt.Println("RNG:", dbg)

	// 賦予 wild 的倍數 (extra 設為倍數)
	for _, pos := range slot.Grids() {
		if pos.Symbol.Id() == g.baseWildId {
			id, mul := feature.RandomMultiplier()
			pos.Symbol = g.symbols[id]
			pos.Param = mul
		}
	}

	return &Slot{slot, feature}
}

// 取得圖騰連線的賠率
//
//	symbol : 圖騰
//	comb : 連線數量
func (g *Game) GetPayout(symbol slotkit.Symbol, comb int) float64 {
	if symbol == nil || symbol.Id() >= len(game.paytable) || comb >= len(game.paytable[symbol.Id()]) {
		return 0
	}
	return game.paytable[symbol.Id()][comb]
}

type Slot struct {
	*slotkit.Slot
	feature Feature
}

func (s *Slot) RandomMultiplier(id int) {
	for _, pos := range s.Grids() {
		if pos.Symbol.Id() == id {
			id, mul := s.feature.RandomMultiplier()
			pos.Symbol = game.symbols[id]
			pos.Param = mul
		}
	}
}

func (s *Slot) AddExtraWild(count int) {
	// 建立一個表格, 用來記錄每個圖騰格的索引位置
	table := make([]int, len(s.Grids()))
	for i := range s.Grids() {
		table[i] = i
	}

	for i := 0; i < count; i++ {
		// 亂數選取一個空白位置
		rnd := rand.Int63n(int64(len(table)))

		// 取得 wild 圖騰
		id, mul := s.feature.RandomMultiplier()

		// 設定新圖騰
		grid := s.Grids()[table[rnd]]
		grid.Symbol = game.symbols[id]
		grid.Param = mul

		// 將已選取的位置刪除
		table[rnd] = table[len(table)-1]
		table = table[:len(table)-1]
	}
}

// 檢查賠付線
//
//	計算每條 payline 的賠付
//	並將中獎的圖騰設為空白
func (s *Slot) CheckPaylines(bet float64) PaylineResults {

	combs := PaylineResults{}

	// 列舉所有 payline
	for id, payline := range game.paylines {

		// 取得 payline 上的圖騰
		line := payline.FetchSymbols(s.Slot)

		// 找出第一個 normal 圖騰 (如果沒有 normal 圖騰, 就使用 wild 圖騰)
		var symbol slotkit.Symbol = game.symbols[game.baseWildId]
		if idx := line.FindMatch(game.maskNormal, 0); idx >= 0 {
			symbol = line[idx].Symbol
		}

		// size = 圖騰的連線長度 (mask = 圖騰的 flag | wild flag)
		size := line.Combinations(symbol.Flag() | game.maskWild)
		if mul := game.paytable.GetPayout(symbol, size); mul > 0 {
			combs = append(combs, PaylineResult{id, symbol, line[0:size:size]})
		}
	}

	return combs
}

func (s *Slot) RemoveHitSymbols(combs PaylineResults) {

	// 將 payline 上中獎的圖騰設為空白
	for _, comb := range combs {
		for _, pos := range comb.EffectGrids {
			pos.Symbol = game.emptySymbol
			pos.Param = nil
		}
	}
	// 將盤面所有與中獎相同圖騰設為空白
	for _, comb := range combs {
		for _, pos := range s.Grids() {
			if pos.Symbol.Id() == comb.Symbol.Id() {
				pos.Symbol = game.emptySymbol
				pos.Param = nil
			}
		}
	}
}

func (s Slot) CalculatePayouts(bet float64, combs PaylineResults) []lineResult {

	payouts := []lineResult{}

	for _, comb := range combs {

		ext := 1 // extra multiplier
		mul := game.paytable.GetPayout(comb.Symbol, len(comb.EffectGrids))
		if mul > 0 {
			// 計算 extra multiplier
			for _, pos := range comb.EffectGrids {
				if m, ok := pos.Param.(int); ok {
					ext *= m
				}
			}
		}

		payout := lineResult{
			PayLine:    comb.Id,
			SymbolID:   comb.Symbol.Id(),
			Amount:     len(comb.EffectGrids),
			Multiplier: ext,
			PayCredit:  mul * bet * float64(ext),
		}
		payouts = append(payouts, payout)
	}

	return payouts
}

// GrantExtraWild: 將 wild store 圖騰加到中獎的圖騰格
func (s *Slot) GrantExtraWild(store *WildStore, pos []int) []transfer {

	if len(pos) == 0 {
		for i, grid := range s.Grids() {
			if grid.Symbol.Match(game.maskNormal) {
				pos = append(pos, i)
			}
		}
	}

	var trans []transfer

	// 將 wild store 的圖騰, 隨機加到中獎的圖騰格
	for store.Length() > 0 && len(pos) > 0 {
		rnd := rand.Int63n(int64(len(pos)))
		to := pos[rnd]

		// 如果中獎的圖騰是 normal 圖騰, 就將 wild store 的圖騰加到中獎的圖騰格
		grid := s.Grids()[to]
		if wild := store.Pull(); wild != nil {
			grid.Symbol = wild.Symbol
			grid.Param = wild.Param

			from := len(s.Grids()) + len(store.store) // store 的圖騰位置 (從 25 開始)
			trans = append(trans, transfer{wild.Symbol.Id(), from, to})
		}

		// 將中獎的圖騰格刪除
		pos[rnd] = pos[len(pos)-1]
		pos = pos[:len(pos)-1]
	}

	return trans
}

// StoreWild: 將 wild 圖騰存到 WildStore
func (s *Slot) StoreWild(store *WildStore) []transfer {

	var trans []transfer
	for from, pos := range s.Grids() {
		if store.Length() >= 5 {
			break
		}

		if pos.Symbol.Match(game.maskWild) {
			store.Push(*pos)

			to := len(s.Grids()) + len(store.store) - 1 // store 的圖騰位置 (從 25 開始)
			trans = append(trans, transfer{pos.Symbol.Id(), from, to})

			pos.Symbol = game.emptySymbol
			pos.Param = nil
		}
	}
	return trans
}

// JumpWild: 將 wild 圖騰跳到其他位置, 並將新的 wild 圖騰加 transfer
func (s *Slot) JumpWild(sticky *map[int]int) []transfer {

	// 建立一個表格, 用來記錄每個圖騰格的索引位置
	table := make([]int, len(s.Grids()))
	for i := range s.Grids() {
		table[i] = i
	}

	// 將盤面中剩餘的 wild 圖騰加到 extra 中
	extra := map[int]int{}
	for _, pos := range table {
		grid := s.Grids()[pos]
		if grid.Symbol.Match(game.maskWild) {
			extra[pos] = grid.Symbol.Id()
		}
	}

	// table 排除 sticky 佔用的 wild 位置
	for i := len(table) - 1; i >= 0; i-- {
		pos := table[i]
		if _, ok := (*sticky)[pos]; !ok {
			continue
		}
		// 將 wild 的位置刪除
		table[i] = table[len(table)-1]
		table = table[:len(table)-1]
	}

	// 返回的 transfer
	jump := []transfer{}

	// 移動 wild 圖騰
	for pos := range *sticky {
		// 亂數選取一個空白位置
		// rnd := math.Random(0, int64(len(table)-1))
		rnd := rand.Int63n(int64(len(table)))

		src := pos
		dst := table[rnd]

		// 隨機產生新的 wild 倍數
		id, mul := s.feature.RandomMultiplier()

		// 設定新圖騰
		grid := s.Grids()[dst]
		grid.Symbol = game.symbols[id]
		grid.Param = mul

		// 設定 transfer
		jump = append(jump, transfer{id, src, dst})

		// 將已選取的位置刪除
		table[rnd] = table[len(table)-1]
		table = table[:len(table)-1]

		// 將 extra 中相同位置的圖騰刪除
		delete(extra, dst)
	}

	// 將 extra 中的圖騰加到盤面中 (from = to)
	for pos, id := range extra {
		if len(jump) < 5 {
			jump = append(jump, transfer{id, -1, pos})
			continue
		}
		break
	}

	*sticky = make(map[int]int, len(jump))
	for _, trans := range jump {
		id := trans[0]
		pos := trans[2]
		(*sticky)[pos] = id
	}

	return jump
}

func (s *Slot) RemoveSymbols(sticky *map[int]int) {
	for pos, _ := range *sticky {
		grid := s.Grids()[pos]
		grid.Symbol = game.emptySymbol
		grid.Param = nil
	}
}

func (s *Slot) HasEmptySymbol() bool {
	return s.Grids().FindMatch(game.emptySymbol.Flag(), 0) >= 0
}

func (s *Slot) Cascade(feature Feature) cascading {

	cas := cascading{Multiplier: 1}

	// 建立新的滾輪
	tmp := game.NewSlot(feature, true)

	// 取出每一條滾輪
	for i, reel := range s.Reels() {

		idx := len(reel)
		del := make([]int, len(reel))

		// 反向列舉滾輪上的位置
		for n, pos := range reel.Reverse() {
			n = len(reel) - n - 1

			// 如果是空白圖騰, 就標記為刪除
			if pos.Symbol.Id() == game.emptySymbol.Id() {
				del[n] = 1
				continue
			}
			// 標記為不刪除
			del[n] = -1

			// 如果不是空白, 就將圖騰複製過去
			idx--
			tmp.Reel(i)[idx] = pos
		}

		// 將新增的圖騰加入到 cascading 結果中
		cas.AddResult = append(cas.AddResult, tmp.Reel(i)[0:idx].GetSymbolsId())
		// 紀錄刪除的位置
		cas.DelPosition = append(cas.DelPosition, del)
	}
	s.Slot = tmp.Slot

	cas.NewResult = s.GetSymbolsId()

	return cas
}

func (s Slot) GetSymbolsId() [][]int {
	reels := s.Reels()
	ids := make([][]int, len(reels))
	for i, reel := range reels {
		ids[i] = reel.GetSymbolsId()
	}
	return ids
}

func (s Slot) Trace() {
	fmt.Println("-----------------------")
	for i, reel := range s.Reels() {
		fmt.Printf("R%d : %s", i+1, reel)

		fmt.Print(" ")
		for _, p := range reel {
			if p.Param == nil {
				fmt.Print(" . ")
			} else {
				fmt.Printf("%2d ", p.Param)
			}
		}
		fmt.Println("")
	}
}
