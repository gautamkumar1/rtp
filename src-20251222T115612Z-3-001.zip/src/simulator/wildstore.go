package simulator

import (
	"github.com/idtksrv/simulator-server/internal/util/slotkit"
)

type WildStore struct {
	store slotkit.Grids
}

// NewWildStore 建立 WildStore
func NewWildStore() WildStore {
	return WildStore{store: slotkit.NewGrid(0)}
}

// Push: 將圖騰格存到 WildStore
func (ws *WildStore) Push(grid slotkit.Grid) bool {
	if len(ws.store) >= 5 || grid.Symbol == nil || !grid.Symbol.Match(game.maskWild) {
		return false
	}
	ws.store = append(ws.store, &grid)
	return true
}

// Pull: 取出 WildStore 的圖騰格
func (ws *WildStore) Pull() *slotkit.Grid {
	if len(ws.store) == 0 {
		return nil
	}
	n := len(ws.store) - 1
	grid := ws.store[n:][0]
	ws.store = ws.store[:n]
	return grid
}

func (ws *WildStore) CurrentPos() int {
	return len(ws.store)
}

func (ws *WildStore) Length() int {
	return len(ws.store)
}

func (ws WildStore) List() []int {
	id := make([]int, len(ws.store))
	for i, grid := range ws.store {
		id[i] = grid.Symbol.Id()
	}
	return id
}

func (ws WildStore) String() string {
	return ws.store.String()
}
