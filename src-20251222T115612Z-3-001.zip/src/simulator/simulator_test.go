package simulator

import (
	"fmt"
	"runtime"
	"sync"
	"testing"
	"time"

	"github.com/idtksrv/simulator-server/internal/configuration"
)

func TestSimulator(t *testing.T) {
	// 設定測試參數
	gameId := 4500
	spinTimes := 20000000
	req := &spinParam{
		LineBet:   1.0,  // 每條線下注金額
		LineNum:   20,   // 下注線數
		CoinValue: 0.05, // 硬幣面值
		BuySpin:   0,    // 購買 feature game
	}
	spinMode := map[int]float64{
		0: 1.0,  // normal
		1: 3.0,  // buy bonus - tiger's move
		2: 15.0, // buy bonus - tiger's run
		3: 30.0, // buy bonus - tiger's hunt
		4: 50.0, // buy bonus - tiger's jump
	}

	req.BetCredit = req.LineBet * float64(req.LineNum) * req.CoinValue
	betMul := spinMode[req.BuySpin]

	// 獲取模擬器
	sim, err := getSimulator(gameId)
	if err != nil {
		t.Fatalf(err.Error())
		return
	}

	// 開始測試
	fmt.Printf("game id: %d, buy mode: %d\n", gameId, req.BuySpin)
	spinRes, err := runSpin(sim, req, spinTimes)
	if err != nil {
		t.Fatalf("RunSpin() error = %v", err)
		return
	}

	// 統計數據
	totalBet := 0.0
	totalWin := 0.0
	spinCount := 0
	graph := newGraph()
	maingraph := newGraph()
	subgraph := newGraph()
	maingame := struct {
		totalWin float64
		anyHit   int
		winHit   int
	}{}
	subgame := struct {
		count    int
		totalWin float64
		anyHit   int
		winHit   int
	}{}

	begin := time.Now()
	for data := range spinRes {
		if res, ok := data.(*result); ok {
			spinCount++
			totalBet += req.BetCredit * betMul
			totalWin += res.MainGame.PayCreditTotal
			graph.Record(req.BetCredit*betMul, res.MainGame.PayCreditTotal+res.SubGame.PayCreditTotal)
			// totalWin += res.SubGame.PayCreditTotal

			// 計算 main game 中獎率
			maingame.totalWin += res.MainGame.PayCreditTotal
			if res.MainGame.PayCreditTotal > 0 {
				maingame.anyHit++
			}
			if res.MainGame.PayCreditTotal >= req.BetCredit {
				maingame.winHit++
			}
			maingraph.Record(req.BetCredit*betMul, res.MainGame.PayCreditTotal)

			// 計算 sub game 中獎率
			if res.GetSubGame {
				subgame.totalWin += res.SubGame.PayCreditTotal
				if res.SubGame.PayCreditTotal > 0 {
					subgame.anyHit++
				}
				if res.SubGame.PayCreditTotal >= req.BetCredit {
					subgame.winHit++
				}
				totalWin += res.SubGame.PayCreditTotal
			}
			subgame.count++
			subgraph.Record(req.BetCredit*betMul, res.SubGame.PayCreditTotal)

			// 顯示進度
			if time.Since(begin).Seconds() > 5 || spinCount%1000000 == 0 {
				fmt.Printf("spin counts:%d progress:%.2f%% RTP:%.2f%% (%.2fsec)\n", spinCount, float64(spinCount)/float64(spinTimes)*100.0, totalWin/totalBet*100, time.Since(begin).Seconds())
				begin = time.Now()
			}
		} else if res, ok := data.(error); ok {
			fmt.Printf("error: %v\n", res)
		} else {
			t.Fatalf("unknown data: %v\n", data)
			break
		}
	}
	fmt.Printf("spin counts:%d progress:%.2f%% RTP:%.2f%% (%.2fsec)\n", spinCount, float64(spinCount)/float64(spinTimes)*100.0, totalWin/totalBet*100, time.Since(begin).Seconds())

	fmt.Printf("--- BASIC DATA\n")
	fmt.Printf("Buy Spin : %d\n", req.BuySpin)
	fmt.Printf("Bet Times %d\n", spinCount)
	fmt.Printf("Game ID %d\n", gameId)
	fmt.Printf("Bet Credit %.2f\n", req.BetCredit)
	fmt.Printf("Line Bet %.2f\n", req.LineBet)
	fmt.Printf("Lines %d\n", req.LineNum)
	fmt.Printf("Coin Value %.2f\n", req.CoinValue)

	fmt.Printf("--- SIMULATOR\n")
	fmt.Printf("RTP %.4f%%\n", (totalWin/totalBet)*100)
	fmt.Printf("Total Bet %.2f\n", totalBet)
	fmt.Printf("Total Payout %.2f\n", totalWin)
	fmt.Printf("Average Payout %.2f\n", totalWin/float64(spinCount))
	fmt.Printf("Any Win Prob %.2f%% Hit %.2f\n", float64(maingame.anyHit+subgame.anyHit)/float64(spinCount)*100.0, float64(spinCount)/float64(maingame.anyHit+subgame.anyHit))
	fmt.Printf("Win >= Bet %.2f%% Hit %.2f\n", float64(maingame.winHit+subgame.winHit)/float64(spinCount)*100.0, float64(spinCount)/float64(maingame.winHit+subgame.winHit))

	fmt.Printf("--- MAIN GAME\n")
	fmt.Printf("Payout %.2f\n", maingame.totalWin)
	fmt.Printf("RTP %.4f%%\n", maingame.totalWin/totalBet*100)
	fmt.Printf("TIMES %d\n", spinCount)
	fmt.Printf("Any Win Prob %.2f%% Hit %.2f\n", float64(maingame.anyHit)/float64(spinCount)*100.0, float64(spinCount)/float64(maingame.anyHit))
	fmt.Printf("Win >= Bet %.2f%% Hit %.2f\n", float64(maingame.winHit)/float64(spinCount)*100.0, float64(spinCount)/float64(maingame.winHit))
	fmt.Printf("PAYOUT GRAPH -----\n")
	maingraph.Print(spinCount, totalBet)

	fmt.Printf("--- FEATURE GAME / FREE SPIN\n")
	fmt.Printf("Times %d\n", subgame.count)
	fmt.Printf("Payout %.2f\n", subgame.totalWin)
	fmt.Printf("RTP %.4f%%\n", subgame.totalWin/totalBet*100)
	fmt.Printf("Hit %.2f\n", float64(spinCount)/float64(subgame.count))
	fmt.Printf("Probability %.2f%%\n", float64(subgame.count)/float64(spinCount)*100)
	fmt.Printf("Total spin times %d Avg %.2f\n", subgame.count, float64(subgame.count)/float64(spinCount))
	fmt.Printf("Any Win Prob %.2f%% Hit %.2f\n", float64(subgame.anyHit)/float64(spinCount)*100.0, float64(spinCount)/float64(subgame.anyHit))
	fmt.Printf("Win >= Bet %.2f%% Hit %.2f\n", float64(subgame.winHit)/float64(spinCount)*100.0, float64(spinCount)/float64(subgame.winHit))
	fmt.Printf("PAYOUT GRAPH -----\n")
	subgraph.Print(subgame.count, totalBet)

	fmt.Printf("--- SIMULATOR PAYOUT GRAPH \n")
	graph.Print(spinCount, totalBet)
}

func runSpin(sim *Simulator, req *spinParam, times int) (<-chan any, error) {

	proc := runtime.NumCPU() * 10

	// 模擬運行
	wg := sync.WaitGroup{}
	spinResult := make(chan any)

	go func() {

		for p := 0; p < proc; p++ {
			// 平行處理
			wg.Add(1)
			go func() {
				defer wg.Done()
				for cnt := 0; cnt < (times / proc); cnt++ {
					res, err := sim.run(req.BuySpin, req.LineBet, req.LineNum, req.CoinValue, req.BetCredit)
					if err != nil {
						spinResult <- fmt.Errorf("RunSpin() error = %v", err)
						continue
					}
					spinResult <- res
				}
				// 模擬運行邏輯
				// spinResult <- "Spin result"
			}()
		}
		wg.Wait()
		close(spinResult)
	}()

	return spinResult, nil
}

func getSimulator(gameId int) (*Simulator, error) {
	cfg, err := configuration.NewConfigurator("config.json", "./../../cfg/")
	if err != nil {
		return nil, fmt.Errorf("NewConfigurator() error = %v", err)
	}

	sd, mgs, sgs, jps, err := cfg.GetSettings(gameId)
	if err != nil {
		return nil, fmt.Errorf("GetSettings() error = %v", err)
	}

	sim, err := NewSimulator(sd, mgs, sgs, jps, nil)
	if err != nil {
		return nil, fmt.Errorf("NewSimulator() error = %v", err)
	}

	return sim, nil
}

type spinParam struct {
	LineBet   float64
	LineNum   int
	CoinValue float64
	BetCredit float64
	BuySpin   int
	// RTP       string
}

type payoutGraph struct {
	graph []struct {
		mul    float64
		count  float64
		payout float64
	}
}

func newGraph() *payoutGraph {
	mul := []float64{0, 1, 5, 10, 20, 30, 50, 100, 200, 300, 400, 500, 1000}

	p := &payoutGraph{}
	p.graph = make([]struct {
		mul    float64
		count  float64
		payout float64
	}, len(mul))

	for i := 0; i < len(mul); i++ {
		p.graph[i].mul = mul[i]
	}
	return p
}

func (p *payoutGraph) Record(bet float64, win float64) {
	mul := win / bet
	for i := 1; i < len(p.graph); i++ {
		if p.graph[i].mul > mul {
			p.graph[i-1].count++
			p.graph[i-1].payout += win
			return
		}
	}
	p.graph[len(p.graph)-1].count++
	p.graph[len(p.graph)-1].payout += win
}

func (p *payoutGraph) Print(totalCount int, totalBet float64) {
	for _, graph := range p.graph {
		fmt.Printf("%0.fx Times %.f Probability %.2f%% RTP %.2f%%\n", graph.mul, graph.count, graph.count/float64(totalCount)*100.0, graph.payout/float64(totalBet)*100.0)
	}
}
