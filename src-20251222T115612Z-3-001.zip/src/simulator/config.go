package simulator

import (
	"github.com/idtksrv/simulator-server/game/core"
	"github.com/idtksrv/simulator-server/internal/configuration"
	slotUtil "github.com/idtksrv/simulator-server/internal/util/slot"
)

type TableRate struct {
	Rate    []int
	Element []int
}
type SpinData struct {
	BaseReel   [][]int
	RespinReel [][]int
}

type Simulator struct {
	base *configuration.SimulatorSetting
	*GameSetting
}

type GameSetting struct {
	MainGameSettingID int               //simulator對照id用
	BaseSetting       *core.BaseSetting //base setting for normal slot
	NormalMode        *Mode
	BuyMode           []*Mode
}

type Mode struct {
	SpinData
	FreeSpin   []*SpinData
	Multiplier *MultiplierData
	ExtraWild  int
}

func (m Mode) GetFeature(feature GameFeature) *Feature {
	if feature == MainGame {
		return &Feature{
			spinData:        &m.SpinData,
			multiplierId:    &m.Multiplier.MultiplierID,
			multiplierTable: m.Multiplier.BaseGame,
		}
	} else if feature == FreeSpin1 {
		return &Feature{
			spinData:        m.FreeSpin[0],
			multiplierId:    &m.Multiplier.MultiplierID,
			multiplierTable: m.Multiplier.FreeGame[0],
		}
	} else if feature == FreeSpin2 {
		return &Feature{
			spinData:        m.FreeSpin[1],
			multiplierId:    &m.Multiplier.MultiplierID,
			multiplierTable: m.Multiplier.FreeGame[1],
		}
	}
	return nil
}

type Feature struct {
	spinData        *SpinData
	multiplierId    *[]int
	multiplierTable *TableRate
}

func (f Feature) ReelStrips(respin bool) [][]int {
	if respin {
		return f.spinData.RespinReel
	}
	return f.spinData.BaseReel
}

func (f Feature) RandomMultiplier() (int, int) {
	idx, _ := slotUtil.RandomIndexOfWeightTable(f.multiplierTable.Rate)
	return (*f.multiplierId)[idx], f.multiplierTable.Element[idx]
}

type MultiplierData struct {
	MultiplierID []int
	BaseGame     *TableRate
	FreeGame     []*TableRate
}
