package simulator

import (
	"encoding/json"
	"fmt"
	"math/rand"

	"github.com/idtksrv/service"
	"github.com/idtksrv/simulator-server/game/core"
	"github.com/idtksrv/simulator-server/internal/configuration"
)

/*
遊戲規則
1. 5x5,27線掉落消除
2. 盤面上出現3個Scatter會觸發10場TIGER'S HUNT免費遊戲
3. 盤面上出現4個(含)以上Scatter會觸發10場TIGER'S JUMP免費遊戲

MAIN
1. 輪面上Wild將隨機出現倍數圖騰(2x,3x,4x,5x,10x)。
2. 若有倍數圖騰出現且有中獎，贏分將乘以輪面所有倍數。

FEATURE
Todo...
1. 基本算分跟 main 相同 。
2. 若有中獎 且 出現倍數圖騰，倍數將會累計進當前倍數的總和，贏分也將乘上當前倍數的總和。
3. 中獎圖騰全部消除後，空位隨機出現倍數(2x-500x，依據low, high symbol 不同)，並累計進當前倍數的總和。
3. 掉落也隨機出現倍數圖騰，並累計進當前倍數的總和。
3. 每次spin [倍數總和] 將不會重置，持續累計至免費遊戲結束。
   (第一局出現x2,x3，總倍數為x5，該局Spin贏分x5。第二局出現x10，總倍數為x15，該局Spin贏分x15...)
4. scatter >=3, free spin +5

倍數加法：
第一次出現倍數2，分數是贏分x2 不是x3
free
	有贏分沒倍數，計量表不算
	有倍數沒贏分，計量表不加計
	有贏分有倍數，計量表加計，且本次贏分算加計後的分數。倍數加到計量表就消失了
	倍數只能算一次，free game 用過之後就加到計量表。
main 有贏分有倍數，算倍數，沒有加計。
	倍數只能算一次，main game 用過就沒了
*/

const (
	// Game Feature
	MainGame  GameFeature = iota
	FreeSpin1             // free game1
	FreeSpin2             // free game2
)

type GameFeature int

// 整體Result
type result struct {
	GameID     int            `json:"game_id"`
	MainGame   *gameResult    `json:"main_game"`
	GetSubGame bool           `json:"get_sub_game"` //是否中sub game, bool
	SubGame    *subGameResult `json:"sub_game"`
}

// gameResult 一次spin 回傳的結果
type gameResult struct {
	PayCreditTotal float64              `json:"pay_credit_total"`     //總 pay credit
	GameResult     [][]int              `json:"result_reels"`         //
	NearWin        int                  `json:"near_win"`             //0=none,1=yes
	FreeSpinTimes  int                  `json:"free_spin_times"`      //
	ScatterInfo    *core.BaseSymbolInfo `json:"scatter_info"`         //free spin time >0 才有傳, cascading 跑完在算
	Transfer       []transfer           `json:"wild_transfer"`        //[[12, 10, 27], [12, 1, 28], [14, 22, 29]] (wild 移動位置 x2:10->27, x2:1->28, x4:22->29)
	Cascading      []*cascading         `json:"cascading"`            //
	WildStore      []int                `json:"wild_store,omitempty"` // 只有 tiger hunt 會用到
}

type cascading struct {
	Multiplier  int          `json:"multiplier"`
	PayLine     []lineResult `json:"pay_line"`
	NewResult   [][]int      `json:"new_result"`      //組合後的新symbol
	AddResult   [][]int      `json:"add_result"`      //補充的symbol
	DelPosition [][]int      `json:"delete_position"` //1=有, -1 沒有 column,line 長度應該跟 result 一樣
	Transfer    []transfer   `json:"wild_transfer"`   //[[12, 10, 27], [12, 1, 28], [14, 22, 29]] (wild 移動位置 x2:10->27, x2:1->28, x4:22->29)
}

type transfer [3]int

type lineResult struct {
	PayLine    int     `json:"pay_line"`   //pay line id
	SymbolID   int     `json:"symbol_id"`  //這條線的symbol id
	Amount     int     `json:"amount"`     //中幾個symbol
	Multiplier int     `json:"multiplier"` //倍數
	PayCredit  float64 `json:"pay_credit"` //本條線金額
}

type subGameResult struct {
	PayCreditTotal float64       `json:"pay_credit_total"`
	Result         []*gameResult `json:"result"`
}

func NewSimulator(sd *configuration.SimulatorSetting, mgs *configuration.GameSetting, sgs *configuration.GameSetting, jps *configuration.JackpotSetting, rds *service.Redis) (*Simulator, error) {
	s := &Simulator{
		base: sd,
	}

	var gs []GameSetting
	if err := json.Unmarshal(mgs.GameSetting, &gs); err != nil {
		return nil, err
	}
	for _, setting := range gs {
		if setting.MainGameSettingID == sd.MainGameSettingID {
			s.GameSetting = &setting
			break
		}
	}

	game.init(s.GameSetting)

	return s, nil
}

func (s *Simulator) Spin(spinMode int, lineBet float64, lines int, coinValue float64, betCredit float64, rtp string, userId int64) ([]byte, error) {
	res, err := s.run(spinMode, lineBet, lines, coinValue, betCredit)
	if err != nil {
		return nil, err
	}
	return json.Marshal(res)
}

func (s *Simulator) run(buySpin int, lineBet float64, lines int, coinValue float64, betCredit float64) (ret *result, retErr error) {
	logPrefix := "run"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logPrefix, r)
			return
		}
	}()

	//total result
	totalResult := s.getEmptyResult(s.base.GameID)

	// 設定 mode
	mode := s.NormalMode
	if buySpin > 0 {
		mode = s.BuyMode[buySpin-1]
	}

	// main game
	mgameResult, err := s.runGame(*mode.GetFeature(MainGame), mode.ExtraWild, betCredit)
	if err != nil {
		retErr = fmt.Errorf("%s err %s", logPrefix, err)
		return
	}
	totalResult.MainGame = mgameResult

	// 進行免費遊戲
	var result []*gameResult

	scatterInfo := mgameResult.ScatterInfo
	if scatterInfo != nil && scatterInfo.Amount == 3 {
		// 3 個 scatter
		store := NewWildStore()
		for i := mgameResult.FreeSpinTimes - 1; i >= 0 && err == nil; i-- {
			//fmt.Println("free spin times", i+1)
			var res *gameResult
			res, err = s.runFreeSpin1(*mode.GetFeature(FreeSpin1), &store, i == 0, betCredit)
			result = append(result, res)
		}
	} else if scatterInfo != nil && scatterInfo.Amount > 3 {
		// 4 個 scatter (含以上)
		sticky := make(map[int]int, 5) // map[position]symbolID
		for i := 0; i < mgameResult.FreeSpinTimes && err == nil; i++ {
			//fmt.Println("free spin times", i+1)
			var res *gameResult
			res, err = s.runFreeSpin2(*mode.GetFeature(FreeSpin2), &sticky, betCredit)
			result = append(result, res)
		}
	}

	if err != nil {
		retErr = fmt.Errorf("%s err %s", logPrefix, err)
		return
	}

	subGames := &subGameResult{}
	for _, sub := range result {
		subGames.PayCreditTotal += sub.PayCreditTotal
		subGames.Result = append(subGames.Result, sub)
	}

	if len(subGames.Result) > 0 {
		totalResult.GetSubGame = true
		totalResult.SubGame = subGames
	}

	return totalResult, nil
}

func DecideReRun(targetRTP string, reRunTimes int, payout, betCredit float64, lowerBound, upperBound int, reSpinData map[string]float64) bool {

	//rerun once only
	if reRunTimes < 1 {
		lb := lowerBound
		//超過要reRun倍數
		if (payout / betCredit) >= float64(lb) {
			if rtp, ok := reSpinData[targetRTP]; ok {
				if rand.Float64() < rtp {
					return true
				}
			}
		}
	}
	return false
}

// 5x5 連消和 27 條支付線遊戲。
// 每當出現贏局時，所有贏局類型的符號將從輪盤中移除。
// Wild 符號可以替代贏線上的其他支付符號。
// 每個 Wild 符號有隨機倍數 x2、x3、x4、x5、x10。
// Wild 符號會將其倍數應用於其所屬的任何贏局組合。
// 如果同一贏局組合中有多個 Wild 符號，這些倍數將相乘。
// 當 Wild 符號成為贏局的一部分時，它將在下一次連消時與贏局符號一起被移除。
// 3 個 SC 將觸發稱為 "TIGER'S HUNT" 的免費遊戲，獲得 10 次免費旋轉。
// ≥ 4 個 SC 將觸發稱為 "TIGER'S JUMP" 的免費遊戲，獲得 10 次免費旋轉。
func (s *Simulator) runGame(feature Feature, extraWild int, betCredit float64) (retResult *gameResult, retErr error) {
	logPrefix := "runGame"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logPrefix, r)
			return
		}
	}()

	retResult = s.getEmptyGameResult()

	// 建立 main game 的 slot
	slot := game.NewSlot(feature, false)

	// 額外增加 5 個 wild
	slot.AddExtraWild(extraWild)

	retResult.GameResult = slot.GetSymbolsId()

	// 進行掉落消除
	for {
		//slot.Trace()

		// 計算 payline 的賠付
		combs := slot.CheckPaylines(betCredit)
		// if len(combs) == 0 {
		// 	break
		// }

		// 計算 payline 的賠付
		payouts := slot.CalculatePayouts(betCredit, combs)
		for _, payout := range payouts {
			// fmt.Printf("payline:%02d symbol:%02d combo:%d win:%f\n", payout.PayLine, payout.SymbolID, payout.Amount, payout.PayCredit)
			retResult.PayCreditTotal += payout.PayCredit
		}

		// 消除中獎的 symbol
		slot.RemoveHitSymbols(combs)

		// 有空白的 symbol 就繼續
		if slot.HasEmptySymbol() {
			// 進行 cascading
			cascading := slot.Cascade(feature)
			cascading.PayLine = payouts
			retResult.Cascading = append(retResult.Cascading, &cascading)
			continue
		}

		break
	}

	// 進行 free spin
	sct := slot.Grids().CountMatch(game.maskScatter)
	if sct < 3 {
		return
	}

	scinfo := &core.BaseSymbolInfo{}
	scinfo.Amount = sct
	scinfo.Multiplier = 1
	for _, reel := range slot.Reels() {
		// 建立 scatter_info
		buf := make([]int, len(reel))
		for i, symbol := range reel {
			if symbol.Symbol.Match(game.maskScatter) {
				scinfo.ID = append(scinfo.ID, symbol.Symbol.Id())
				buf[i] = 1
			} else {
				buf[i] = -1
			}
		}
		scinfo.Position = append(scinfo.Position, buf)
	}
	retResult.ScatterInfo = scinfo
	retResult.FreeSpinTimes = 10

	return
}

func (s *Simulator) runFreeSpin1(feature Feature, store *WildStore, last bool, betCredit float64) (retResult *gameResult, retErr error) {
	logPrefix := "runSubGame1"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logPrefix, r)
			return
		}
	}()

	retResult = s.getEmptyGameResult()

	// 建立 sub game 的 slot
	slot := game.NewSlot(feature, false)
	retResult.GameResult = slot.GetSymbolsId()
	retResult.WildStore = store.List()

	// 進行掉落消除
	for {
		// 計算 payline 的賠付
		combs := slot.CheckPaylines(betCredit)

		// 紀錄 wild 的移動
		trans := []transfer{}

		// 將 wild store 的圖騰, 隨機加到中獎的圖騰格
		if store.Length() > 0 {
			if len(combs) > 0 {
				trans = slot.GrantExtraWild(store, combs.GetEffectivePositions())
			} else if last {
				trans = slot.GrantExtraWild(store, nil)
			}
		}

		// 重新計算 payline 的賠付
		if len(trans) > 0 {
			combs = slot.CheckPaylines(betCredit)
		}

		// 計算 payline 的賠付
		payouts := slot.CalculatePayouts(betCredit, combs)
		for _, payout := range payouts {
			// fmt.Printf("payline:%02d symbol:%02d combo:%d win:%f, mul:%d\n", payout.PayLine, payout.SymbolID, payout.Amount, payout.PayCredit, payout.Multiplier)
			retResult.PayCreditTotal += payout.PayCredit
		}

		// 消除中獎的 symbol
		slot.RemoveHitSymbols(combs)

		// 將 wild 圖騰存到 WildStore (最後一次不存)
		if !last {
			trans = append(trans, slot.StoreWild(store)...)
		}

		// 有空白的 symbol 就繼續
		if slot.HasEmptySymbol() || len(trans) > 0 {

			// 進行 cascading
			cascading := slot.Cascade(feature)
			cascading.PayLine = payouts
			cascading.Transfer = trans
			retResult.Cascading = append(retResult.Cascading, &cascading)
			continue
		}

		return
	}
}

// sticky: 有 sticky 的圖騰 (map[position]symbolID)
func (s *Simulator) runFreeSpin2(feature Feature, sticky *map[int]int, betCredit float64) (retResult *gameResult, retErr error) {
	logPrefix := "runSubGame2"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logPrefix, r)
			return
		}
	}()

	retResult = s.getEmptyGameResult()

	// 建立 sub game 的 slot
	slot := game.NewSlot(feature, false)
	retResult.GameResult = slot.GetSymbolsId()
	retResult.Transfer = slot.JumpWild(sticky)

	// 進行掉落消除
	for {
		// 重新計算 payline 的賠付
		combs := slot.CheckPaylines(betCredit)
		if len(combs) == 0 {
			return
		}

		// 計算 payline 的賠付
		payouts := slot.CalculatePayouts(betCredit, combs)
		for _, payout := range payouts {
			// fmt.Printf("payline:%02d symbol:%02d combo:%d win:%f, mul:%d\n", payout.PayLine, payout.SymbolID, payout.Amount, payout.PayCredit, payout.Multiplier)
			retResult.PayCreditTotal += payout.PayCredit
		}

		// 消除中獎的 symbol
		slot.RemoveHitSymbols(combs)

		// 消除 jumper 的圖騰
		slot.RemoveSymbols(sticky)

		// 有空白的 symbol 就繼續
		if slot.HasEmptySymbol() {

			// 進行 cascading
			cascading := slot.Cascade(feature)
			cascading.PayLine = payouts
			retResult.Cascading = append(retResult.Cascading, &cascading)
			cascading.Transfer = slot.JumpWild(sticky)
			continue
		}

		return
	}
}

func (s *Simulator) getEmptyGameResult() *gameResult {
	return &gameResult{
		0,
		[][]int{},
		0,
		0,
		nil,
		[]transfer{},
		[]*cascading{},
		[]int{},
	}
}

func (s *Simulator) getEmptyResult(gameID int) *result {
	return &result{
		gameID,
		&gameResult{},
		false,
		&subGameResult{
			0,
			[]*gameResult{},
		},
	}
}
