package main

import (
	"fmt"
	"log"
	"os"

	"github.com/idtksrv/service"
	"github.com/idtksrv/simulator-server/internal/configuration"
	"github.com/idtksrv/simulator-server/internal/handler"
)

var version = "v1.0.0" //每次 merge release 打 tag 版號 編譯時, 帶入參數 -X main.version 覆蓋過去

func main() {

	sc := "serviceConfig.json"
	conf := "config.json"

	args := os.Args //args 包括程式本身 game-simulator
	//process name
	//serviceConfig.json
	//config.json
	//所以長度是3
	if len(args) >= 3 {
		sc = args[1]
		conf = args[2]
	}

	svc, err := service.NewService(sc)
	if err != nil {
		log.Printf("err=%s\n", err.Error())
		exit(0, err)
	}
	logger, _ := svc.GetLogger()
	logger.Init()

	con, err := configuration.NewConfigurator(conf)
	if err != nil {
		fmt.Printf("err=%s\n", err.Error())
		exit(10, err)
	}

	http, err := svc.GetHTTP()
	if err != nil {
		fmt.Printf("err=%s\n", err.Error())
		exit(20, err)
	}
	router := http.GetRouter()
	h, err := handler.NewHTTPHandler(svc, con)
	if err != nil {
		fmt.Printf("err=%s\n", err.Error())
		exit(30, err)
	}
	router.Handle("/", h).Methods("POST", "OPTIONS")

	fmt.Printf("simulator-server start, version:%s\n", version)

	svc.Hold()

}

func exit(id int, err error) {
	fmt.Println(err)
	log.Println(err)
	os.Exit(id)
}
