package mainGame

type GameSetting struct {
	Symbol                      Symbol
	GetPrizeSymbolMinNumPerLine int //最少中幾個symbol才有獎
	Reel                        [][]int
	PayLine                     [][]int
	PayTable                    []PayRate
	MainGameSettingID           int //simulator對照id用
	ReSpinData                  map[string]float64
	LowerBound                  int
}
type Symbol struct {
	JackpotID []int
	WildID    []int
	ScatterID []int
	SymbolID  []int
}

//PayRate 賠率 範例
//payTable = []PayRate{
//	{
//		1,
//		[]int{0, 0, 0, 200, 1000, 5000}, //index 0=0個0倍,1=1個0倍,2=2個0倍,3=3個200倍,4=4個1000..
//	},
//}
type PayRate struct {
	SymbolID int   //Symbol id
	PayRate  []int //賠率,index 0=0個0倍,1=1個0倍,2=2個0倍,3=3個200倍,4=4個1000..
}

//Result 回傳的結果
type Result struct {
	PayCreditTotal float64      `json:"pay_credit_total"` //總 pay credit
	GameResult     [][]int      `json:"game_result"`
	PayLine        []LineResult `json:"pay_line"` //
}

//LineResult 每條線的結果
type LineResult struct {
	PayLine   int     `json:"pay_line"`   //pay line id
	SymbolID  int     `json:"symbol_id"`  //這條線的symbol id
	Amount    int     `json:"amount"`     //中幾個symbol
	PayCredit float64 `json:"pay_credit"` //本條線金額
}
