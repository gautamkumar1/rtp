package mainGame2100

import (
	"encoding/json"
	"fmt"
	"sort"

	"github.com/idtksrv/simulator-server/internal/util/rand"
	"github.com/idtksrv/simulator-server/internal/util/slot"
	"github.com/shopspring/decimal"
)

const (
	Mode1 = "mode1"
	Mode2 = "mode2"
)

// Game represents main game with type 100
type Game struct {
	GameType    int
	GameSetting *GameSetting
}

type GameSetting struct {
	Symbol                      Symbol
	ModeTable                   *ModeTable
	GetPrizeSymbolMinNumPerLine int //最少中幾個symbol才有獎
	Reel1                       [][]int
	Reel2                       [][]int
	PayLine                     [][]int
	PayTable                    []PayRate
	MainGameSettingID           int //simulator對照id用
	Mode1                       *ModeSetting
	Mode2                       *ModeSetting
	//WinMultiplier               []int
	//WinMultiplierTime           []int
	WinMultiplierTable []int
	WaitWinSymbol      []int //wait win
}

type Symbol struct {
	SymbolID []int
	Medusa   int
	Wild     []int
}
type ModeTable struct {
	Weight  []int
	Element []string
}
type ModeSetting struct {
	WinMultiplier     []int   `json:"WinMultiplier"`
	WinMultiplierTime []int   `json:"WinMultiplierTime"`
	Reel              [][]int `json:"Reel"`
}

// PayRate 賠率
// 範例
//
//	payTable = []PayRate{
//		{
//			1,
//			[]int{0, 0, 0, 200, 1000, 5000}, //index 0=0個0倍,1=1個0倍,2=2個0倍,3=3個200倍,4=4個1000..
//		},
//	}
type PayRate struct {
	SymbolID int   //Symbol id
	PayRate  []int //賠率,index 0=0個0倍,1=1個0倍,2=2個0倍,3=3個200倍,4=4個1000..
}

// Result 回傳的結果
type Result struct {
	PayCreditTotal float64      `json:"pay_credit_total"` //總 pay credit
	GameResult     [][]int      `json:"game_result"`
	PayLine        []LineResult `json:"pay_line"` //
	MedusaLocation []int        `json:"medusa_location"`
	Multiplier     []int        `json:"multiplier"`
	WaitWin        bool         `json:"wait_win"`
}

// LineResult 每條線的結果
type LineResult struct {
	PayLine   int     `json:"pay_line"`   //pay line id
	SymbolID  int     `json:"symbol_id"`  //這條線的symbol id
	Amount    int     `json:"amount"`     //中幾個symbol
	PayCredit float64 `json:"pay_credit"` //本條線金額
}

func NewGame(gameType int, st json.RawMessage, gameSettingID int) (*Game, error) {

	g := &Game{}
	g.GameType = gameType
	var gs []GameSetting
	if err := json.Unmarshal(st, &gs); err != nil {
		return nil, err
	}
	for index, setting := range gs {
		if setting.MainGameSettingID == gameSettingID {
			g.GameSetting = &gs[index]
		}

	}
	return g, nil
}

// GetResult
// return *Result
// return int featureGame amount
// return error
func (g *Game) GetResult(lineBet float64, lines int, coinValue float64, betCredit float64) (ret *Result, retErr error) {
	logFunc := "GetResult "

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	mode := g.RandomMode()
	//main game
	modeSetting, err := g.PickModeSetting(mode)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}
	resultReel, medusaLocation, err := g.countReelResult(modeSetting.Reel)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}
	//get Multiplier
	multipliers, times := g.makeMultiplier(modeSetting.WinMultiplier, modeSetting.WinMultiplierTime, g.GameSetting.WinMultiplierTable)
	lineResult, err := g.countLineResult(resultReel, g.GameSetting.PayLine, g.GameSetting.GetPrizeSymbolMinNumPerLine, g.GameSetting.Symbol.Wild)
	waitWin := g.countWaitWin(resultReel, g.GameSetting.Symbol.Wild)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	lineResult, payCredit, err := g.countLineCredit(lineBet, coinValue, lineResult, g.GameSetting.PayTable, times)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logFunc, err.Error())
		return
	}

	//scatterLocations:= g.countFeatureGame(resultReel)
	return &Result{
		payCredit,
		resultReel,
		lineResult,
		medusaLocation,
		multipliers,
		waitWin,
	}, nil
}

// GetReelResult 傳入機率算好的輪面，random 回傳一個盤面
// 回傳結構
// {{1,2,3} client的第1輪 1=上面，2=中間，3=下面
// {1,1,1}  client的第2輪
// {1,1,1}
// {1,1,1}
// {1,1,1}}
func (g *Game) countReelResult(defaultReel [][]int) (retResult [][]int, medusaLocation []int, retErr error) {

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", "countReelResult", r)
		}
	}()

	//make return array
	retResult = make([][]int, len(defaultReel))
	for i := range retResult {
		retResult[i] = make([]int, 3)
	}

	var max int //length 會變嗎

	medusaLocation = make([]int, 3)

	//for index, content := range g.GameSetting.Reel {
	//	max = len(content)
	//	//randomIndex := rand.Intn(max) //todo using MersenneTwister
	//	roll, _ := cRand.Int(cRand.Reader, big.NewInt(int64(max))) //0~max 100000 0-100000 -1
	//	rollInt := roll.Int64()
	//	up := defaultReel[index][mod(rollInt-2, int64(max))]
	//	down := defaultReel[index][mod(rollInt+2, int64(max))]
	//	//fmt.Printf("[-2]:%v [+2]:%v\n",defaultReel[index][mod(randomIndex-2, max)],defaultReel[index][mod(randomIndex+2, max)])
	//	g.makeMedusaLocation(up, down, index, medusaLocation)
	//
	//	retResult[index][0] = defaultReel[index][mod(rollInt-1, int64(max))]
	//	retResult[index][1] = defaultReel[index][mod(rollInt, int64(max))]
	//	retResult[index][2] = defaultReel[index][mod(rollInt+1, int64(max))]
	//}
	for index, content := range defaultReel {
		max = len(content)
		//randomIndex := rand.Intn(max) //todo using MersenneTwister
		rollInt := rand.Int63n(int64(max)) //0~max 100000 0-100000 -1

		up := defaultReel[index][mod(rollInt-2, int64(max))]
		down := defaultReel[index][mod(rollInt+2, int64(max))]
		//fmt.Printf("[-2]:%v [+2]:%v\n",defaultReel[index][mod(randomIndex-2, max)],defaultReel[index][mod(randomIndex+2, max)])
		g.makeMedusaLocation(up, down, index, medusaLocation)

		retResult[index][0] = defaultReel[index][mod(rollInt-1, int64(max))]
		retResult[index][1] = defaultReel[index][mod(rollInt, int64(max))]
		retResult[index][2] = defaultReel[index][mod(rollInt+1, int64(max))]
	}
	return
}

// countLineResult 用random的盤面及預先定義好的線為參數，算出中哪幾條線的資料，
func (g *Game) countLineResult(result [][]int, payLine [][]int, getPrizeSymbolMinNumPerLine int, wildIDs []int) (ret []LineResult, retErr error) {

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", "countLineResult", r)
			return
		}
	}()
	ret = []LineResult{}
	//result=[][]int{ {2,2,2},{0,0,0},{7,7,2}}  //for debug specific scenario
	//取跟payLine同位置的的symbol,取成一筆
	var rr [][]int
	for _, line := range payLine {
		var r = make([]int, 3, 3)
		for j, v := range line {
			r[j] = result[j][v]
		}
		rr = append(rr, r)
	}
	//用這些去判斷是否有中
	firstSymbol := -1

	for i, line := range rr {
		num := 1
		j := 0
		v := 0
		firstSymbolWild := false
		firstSymbol = line[0]
		if firstSymbol == 0 {
			firstSymbolWild = true
		}
		for j, v = range line {
			if j > 0 {
				if v == firstSymbol {
					num += 1
				} else if firstSymbolWild {
					num += 1
					firstSymbol = v
					firstSymbolWild = false
				} else {
					//是否wild
					got := false
					for _, x := range wildIDs {
						if v == x {
							num += 1
							got = true
							break
						}
					}
					if !got {
						break
					}
				}
			}
		}
		if num >= getPrizeSymbolMinNumPerLine {
			ret = append(ret, LineResult{
				i,
				firstSymbol,
				num,
				0, //後續再算
			})
		}
	}
	return
}

// countLineCredit 計算每條中的線的金額，及計算總金額
// []LineResult 每條線的結果，補進去
// float64 總金額
func (g *Game) countLineCredit(lineBet, coinValue float64, lineResult []LineResult, payTable []PayRate, times int) (ret []LineResult, payCredit float64, retErr error) {
	logFunc := "countLineCredit "
	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()

	lbc := decimal.NewFromFloat(lineBet).Mul(decimal.NewFromFloat(coinValue)) //line bet* coin value
	pp := decimal.NewFromFloat(0)
	pc := decimal.NewFromFloat(0) //parCredit

	var resultNewSlice []LineResult
	//var creditAmount float64
	for i, content := range lineResult {
		for _, v := range payTable {
			if v.SymbolID == content.SymbolID {
				pr := decimal.NewFromFloat(float64(v.PayRate[content.Amount])) // pay rate
				pp = lbc.Mul(pr)                                               //lineBet * coinValue * pay rate
				pc = pc.Add(pp)
				lineResult[i].PayCredit, _ = pp.Mul(decimal.NewFromInt(int64(times))).Float64() //這條線的credit
				resultNewSlice = append(resultNewSlice, lineResult[i])
			}
		}
	}

	payCredit, _ = pc.Mul(decimal.NewFromInt(int64(times))).Float64()
	ret = resultNewSlice
	return
}
func mod(a, b int64) int64 {
	if a < 1 {
		a += b
	}
	return a % b
}

// 0:沒有,1:此輪最上方,2:此輪最下方,3：此輪上下方都有
func (g *Game) makeMedusaLocation(up, down, index int, location []int) {
	medusa := g.GameSetting.Symbol.Medusa
	location[index] = 0
	if up == medusa && down == medusa {
		location[index] = 3
		return
	}
	if up == medusa {
		location[index] = 1
		return
	}
	if down == medusa {
		location[index] = 2
		return
	}
	return
}

func (g *Game) makeMultiplier(multiplier, WinMultiplierTime, winMultiplierTable []int) (multipart []int, times int) {
	//multiplier := g.GameSetting.WinMultiplier
	//winMultiplierTable := g.GameSetting.WinMultiplierTable
	max := multiplier[len(multiplier)-1]
	//eachTime := g.GameSetting.WinMultiplierTime
	roll := rand.Intn(max) //0~max 10000
	multipart = make([]int, 4)
	returnTimes := 1
	for index, value := range multiplier {
		if roll < value {
			returnTimes = WinMultiplierTime[index]
			break
		}
	}
	times = returnTimes
	position := -1
	position = g.getPosition(winMultiplierTable, position, times)

	if position != -1 {
		multipart[0] = winMultiplierTable[mod(int64(position)-1, int64(len(winMultiplierTable)))]
		multipart[1] = times
		multipart[2] = winMultiplierTable[mod(int64(position)+1, int64(len(winMultiplierTable)))]
		multipart[3] = winMultiplierTable[mod(int64(position)+2, int64(len(winMultiplierTable)))]
	}
	return
}

func (g *Game) getPosition(table []int, position, times int) (pos int) {
	arrayIndex := rand.Intn(len(table))
	for i := 0; i < len(table); i++ {
		if table[arrayIndex] == times {
			position = arrayIndex
			break
		}
		arrayIndex = (arrayIndex + 1) % len(table)
	}
	return position
}

func (g *Game) countWaitWin(reel [][]int, wild []int) (waitWin bool) {
	//wildSymbol := wild[0]
	//countWaitWin := 0
	//reel = [][]int{{3, 0, 0}, {1, 6, 0}, {3, 3, 3}}
	//reel = [][]int{{5, 0, 0}, {5, 5, 7}, {5, 5, 1}}
	//reel = [][]int{{5, 2, 2}, {2, 2, 2}, {6, 6, 6}}
	//reel = [][]int{{0, 0, 0}, {0, 7, 7}, {5, 5, 5}}//false
	//reel = [][]int{{5, 5, 0}, {0, 0, 7}, {7, 7, 7}}//false
	//reel = [][]int{{0, 0, 0}, {0, 0, 7}, {7, 7, 7}}//false
	jump := g.GameSetting.WaitWinSymbol
	first := make([]int, 0)
	second := make([]int, 0)
	firstZeroNum := 0
	secondZeroNum := 0
	for index, singleReel := range reel {
		for _, value := range singleReel {
			if value == 0 {
				if index == 0 {
					firstZeroNum++
				} else if index == 1 {
					secondZeroNum++
				}
			}
			for _, v := range jump {
				if v == value {
					if index == 0 {
						first = append(first, value)
					} else if index == 1 {
						second = append(second, value)
					}

				}
			}
		}
	}

	if (firstZeroNum >= 2 && secondZeroNum >= 1 && len(second) > 0) ||
		(firstZeroNum >= 1 && secondZeroNum >= 2 && len(first) > 0) || (firstZeroNum >= 2 && secondZeroNum >= 2) {
		waitWin = true
		return
	}

	firstSymbol := -1
	if len(first) == 2 {
		if first[0] == first[1] {
			firstSymbol = first[0]
		}
	} else if len(first) == 3 {
		firstSymbol = MoreThan2(first)
	}
	secondSymbol := -1
	if len(second) == 2 {
		if second[0] == second[1] {
			secondSymbol = second[0]
		}
	} else if len(second) == 3 {
		secondSymbol = MoreThan2(second)
	}
	if firstSymbol == secondSymbol && secondSymbol != -1 {
		waitWin = true
		return
	}
	if secondZeroNum >= 2 && firstSymbol != -1 || firstZeroNum >= 2 && secondSymbol != -1 {
		waitWin = true
		return
	}

	if firstZeroNum == 1 && secondZeroNum == 1 {
		for _, v1 := range first {
			for _, v2 := range second {
				if v1 == v2 {
					waitWin = true
					return
				}
			}
		}
	}

	return
}

func MoreThan2(nums []int) int {
	if len(nums) == 0 {
		return 0
	}
	sort.Ints(nums)
	target := nums[len(nums)/2]
	count := 0

	for i := 0; i < len(nums); i++ {
		if nums[i] == target {
			count++
		}
	}

	if count > len(nums)/2 {
		return target
	}

	return -1
}

func (g *Game) PickModeSetting(mode string) (*ModeSetting, error) {
	if mode == Mode1 {
		return g.GameSetting.Mode1, nil
	} else if mode == Mode2 {
		return g.GameSetting.Mode2, nil

	}
	return nil, fmt.Errorf("PickModeSetting mode not found %s", mode)
}

func (g *Game) RandomMode() string {
	idx, _ := slot.RandomIndexOfWeightTable(g.GameSetting.ModeTable.Weight)
	return g.GameSetting.ModeTable.Element[idx]
}
