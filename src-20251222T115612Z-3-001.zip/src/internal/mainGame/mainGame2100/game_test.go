package mainGame2100

import (
	"fmt"
	"os"
	"testing"

	"github.com/idtksrv/simulator-server/internal/configuration"
)

const (
	mainGameType      = 2100
	mainGameSettingID = 1
	//bet data
	betTimes  = 500000
	lineBet   = 100.0
	lines     = 5
	coinValue = 1.0
	betCredit = lineBet * lines * coinValue
	betTotal  = betTimes * betCredit
)

func TestGame_getResult(t *testing.T) {
	configurator, err := configuration.NewConfigurator("config.json", "./../../../cmd/")
	if err != nil {
		fmt.Printf("err=%s\n", err.Error())
		os.Exit(1)
	}

	gs, err := configurator.GetMainGameSetting(mainGameType, mainGameSettingID)
	if err != nil {
		t.Fatalf("GetMainGameSetting %s", err)
	}

	game, err := NewGame(mainGameType, gs.GameSetting, mainGameSettingID)
	if err != nil {
		t.Fatalf("NewGame error %s", err)
	}

	//main game
	var payCreditTotal float64
	freeSpinTimes := 0
	freeSpinProbability := 0.0

	for i := 0; i < betTimes; i++ {
		result, err := game.GetResult(lineBet, lines, coinValue, betCredit)
		if err != nil {
			t.Fatalf("GetResult error %s", err)
		}
		payCreditTotal += result.PayCreditTotal
	}

	freeSpinProbability = float64(freeSpinTimes) / float64(betTimes)
	t.Logf("--- BET DATA\n")
	t.Logf("Bet %.0f", betCredit)
	t.Logf("Bet times %d", betTimes)
	t.Logf("--- MAIN GAME\n")
	t.Logf("RTP :%.2f%%", (payCreditTotal/betTotal)*100)
	t.Logf("Total bet %.0f ", betTotal)
	t.Logf("Payout %.0f ", payCreditTotal)
	t.Logf("Free spin times %d probability %0.2f%%", freeSpinTimes, freeSpinProbability*100)

}
