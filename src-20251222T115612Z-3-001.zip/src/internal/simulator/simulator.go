package simulator

import (
	"encoding/json"
	"fmt"

	"github.com/idtksrv/service"
	"github.com/idtksrv/simulator-server/game/core"
	"github.com/idtksrv/simulator-server/internal/configuration"
	sliceUtil "github.com/idtksrv/simulator-server/internal/util/slice"
	slotUtil "github.com/idtksrv/simulator-server/internal/util/slot"
	"github.com/shopspring/decimal"
)

/*
遊戲規則
1. 盤面上出現8個(含)以上相同Symbol會消去獲得賠分，並落下新圖騰，直到沒有贏分為止。
2. 盤面上出現4/5/6個(含以上)Scatter會觸發10/15/20場免費遊戲。

MAIN
1. 輪面上將隨機出現倍數圖騰(2x~500x)。
2. 若有倍數圖騰出現且有中獎，贏分將乘以輪面所有倍數的總和。
3. scatter 有算分。scatter 算分也要乘倍。
4. scatter 4/5/6, free spin +10/15/20

FREE
1. 基本算分跟 main 相同 。
2. 若有中獎 且 出現倍數圖騰，倍數將會累計進當前倍數的總和，贏分也將乘上當前倍數的總和。
3. 每次spin [倍數總和] 將不會重置，持續累計至免費遊戲結束。
   (第一局出現x2,x3，總倍數為x5，該局Spin贏分x5。第二局出現x10，總倍數為x15，該局Spin贏分x15...)
4. scatter >=3, free spin +5

倍數加法：
第一次出現倍數2，分數是贏分x2 不是x3
free
	有贏分沒倍數，計量表不算
	有倍數沒贏分，計量表不加計
	有贏分有倍數，計量表加計，且本次贏分算加計後的分數。倍數加到計量表就消失了
	倍數只能算一次，free game 用過之後就加到計量表。
main 有贏分有倍數，算倍數，沒有加計。
	倍數只能算一次，main game 用過就沒了
*/

// 1 落下的 有 multiplier
// 2 落下的有 scatter

type configExtraData struct {
	MultiplierID int
	MainGame     *gameData
	FreeGame     *gameData
}
type gameData struct {
	ActiveFreeSpinGreaterOrEqualAmount int
	MultiplierTable                    []int
	LowTable                           *tableRate
	HighTable                          *tableRate
	FreeSpinTimes                      [][]int
}

type tableRate struct {
	Rate    []int
	Element []int
}

// result
// flow 是消除資料，可能一個 cascading 裡面有3個 symbol 消除
type flow struct {
	SymbolID  int     `json:"symbol_id"`
	Amount    int     `json:"amount"`
	PayCredit float64 `json:"pay_credit"` //未乘倍的數字
}
type cascading struct {
	InitResult    [][]int `json:"init_result"`    //初始輪面
	Flow          []*flow `json:"flow"`           //消除內容
	AddResult     [][]int `json:"add_result"`     //新出的symbol,只有空位的symbol
	NewResult     [][]int `json:"new_result"`     //消除後補上 add result, 最後的新輪面
	Multipliers   []int   `json:"multipliers"`    //[2,10,12...]  //每個ring 的倍數, 從第一輪開始
	MultiplierSum int     `json:"multiplier_sum"` //cascading 所有 flow 的倍數和
	//[5,5,1],
	//[5,5,1,1],
	//[],
	//[],
	//[8,7,9,1,2,3],
	//[],
}

// gameResult 一次spin 回傳的結果
type gameResult struct {
	PayCreditTotal float64              `json:"pay_credit_total"` //總 pay credit 有乘倍
	GameResult     [][]int              `json:"game_result"`
	Cascading      []*cascading         `json:"cascading"`
	FreeSpinTimes  int                  `json:"free_spin_times"` //
	MultiplierSum  int                  `json:"multiplier_sum"`  //這個輪面倍數總和
	Multipliers    []int                `json:"multipliers"`     //[2,10,12...]  //每個ring 的倍數, 從第一輪開始
	ScatterInfo    *core.BaseSymbolInfo `json:"scatter_info"`    // free spin time >0 才有傳, cascading 跑完在算
}

type subGameResult struct {
	PayCreditTotal float64       `json:"pay_credit_total"`
	Result         []*gameResult `json:"result"`
}

// 整體Result
type result struct {
	GameID     int            `json:"game_id"`
	MainGame   *gameResult    `json:"main_game"`
	GetSubGame bool           `json:"get_sub_game"` //是否中sub game, bool
	SubGame    *subGameResult `json:"sub_game"`
}

type Simulator struct {
	base            *core.BaseSimulator
	normalExtraData *configExtraData
	buyExtraData    *configExtraData
	usedExtraData   *configExtraData
	gameSetting     *core.GameSetting
	buySpin         int //run 傳進來
}

func NewSimulator(sd *configuration.SimulatorSetting, mgs *configuration.GameSetting, sgs *configuration.GameSetting, jps *configuration.JackpotSetting, rds *service.Redis) (*Simulator, error) {

	baseSim, err := core.NewSimulator(sd, mgs)
	if err != nil {
		return nil, fmt.Errorf("new base simulator error %s", err)
	}

	// normal extra
	nex := &configExtraData{}
	err = json.Unmarshal(baseSim.GetMode(configuration.BuySpinNormal).ExtraData, nex)
	if err != nil {
		return nil, fmt.Errorf("unmarshal game config extra error %s", err)
	}

	// buy mode extra
	bex := &configExtraData{}
	err = json.Unmarshal(baseSim.GetMode(configuration.BuySpinYes).ExtraData, bex)
	if err != nil {
		return nil, fmt.Errorf("unmarshal game config extra error %s", err)
	}

	s := &Simulator{
		base:            baseSim,
		normalExtraData: nex,
		buyExtraData:    bex,
		gameSetting:     baseSim.GetGameSetting(),
	}

	return s, nil
}

func (s *Simulator) Spin(spinMode int, lineBet float64, lines int, coinValue float64, betCredit float64, rtp string, userId int64) ([]byte, error) {
	res, err := s.run(spinMode, lineBet, lines, coinValue, betCredit)
	if err != nil {
		return nil, err
	}
	return json.Marshal(res)
}

func (s *Simulator) run(buySpin int, lineBet float64, lines int, coinValue float64, betCredit float64) (ret *result, retErr error) {
	logPrefix := "run"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logPrefix, r)
			return
		}
	}()

	s.buySpin = buySpin
	s.usedExtraData = s.getConfigExtraData(buySpin)
	mode := s.base.GetMode(buySpin)

	result := s.getEmptyResult(s.base.GetSimulatorSetting().GameID)

	//main game
	gameResult, _, err := s.runSpin(mode, false, 0, betCredit)
	if err != nil {
		retErr = fmt.Errorf("%s err %s", logPrefix, err)
		return nil, retErr
	}
	result.MainGame = gameResult
	freeSpinTimes := gameResult.FreeSpinTimes

	//free spin
	accMultiplier := 0
	if freeSpinTimes > 0 {
		result.GetSubGame = true
		pd := decimal.NewFromFloat(0)

		for freeSpinTimes > 0 {
			freeSpinTimes--
			sr, am, err := s.runSpin(mode, true, accMultiplier, betCredit)
			accMultiplier = am
			if err != nil {
				retErr = fmt.Errorf("%s err %s", logPrefix, err)
				return
			}
			freeSpinTimes += sr.FreeSpinTimes
			result.SubGame.Result = append(result.SubGame.Result, sr)
			pd = pd.Add(decimal.NewFromFloat(sr.PayCreditTotal))
			//result.SubGame.PayCreditTotal += sr.PayCreditTotal
		}

		result.SubGame.PayCreditTotal, _ = pd.Float64()
	}

	return result, nil
}

// accMultiplier 目前為止累積的 multiplier
func (s *Simulator) runSpin(mode *core.Mode, isFreeSpin bool, accMultiplier int, betCredit float64) (retResult *gameResult, retAccMultiplier int, retErr error) {
	logPrefix := "runSpin"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logPrefix, r)
			return
		}
	}()

	usedGameData := s.getGameData(isFreeSpin)

	//accMultiplier 有可能是 0
	retAccMultiplier = accMultiplier
	retResult = s.getEmptyGameResult()

	//get result wheel
	resultWheel, err := s.base.RandomWheel(s.getBaseReel(mode, isFreeSpin), s.gameSetting.BaseSetting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logPrefix, err.Error())
		return
	}

	retResult.GameResult = resultWheel

	//resultWheel算multipliers
	tr := s.randomMultiplierWeightTable(usedGameData)
	m := s.countMultiplierSymbolAmount(s.usedExtraData.MultiplierID, resultWheel)
	mul := s.createMultipliersByLast(m, nil, tr)
	retResult.Multipliers = mul
	retResult.MultiplierSum = s.sumMultipliers(mul)

	//所有的消除結果
	baseCascading, err := s.base.CascadingRecursive(s.gameSetting.BaseSetting, resultWheel, s.getReSpinReel(mode, isFreeSpin))
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logPrefix, err.Error())
		return
	}

	//處理 cascading result
	casResult, err := s.baseCascadingToCascading(baseCascading)
	if err != nil {
		err = fmt.Errorf("%s error %s", logPrefix, retErr.Error())
		return
	}
	_ = s.fillCascadingMultipliers(s.usedExtraData.MultiplierID, casResult, tr, mul)
	//fill cascading flows pay credit 沒乘倍，最後才乘倍
	s.fillCascadingFlowPayCredit(casResult, s.gameSetting.BaseSetting.PayTable, betCredit)
	retResult.Cascading = casResult

	//算出本次spin全部最後的multiplier sum, 還有
	if cl := len(retResult.Cascading); cl == 0 {

	}
	thisMultipliers, thisMultiplierSum := s.getThisSpinMultiplierSum(retResult)
	retResult.Multipliers = thisMultipliers     //指定給 ret result
	retResult.MultiplierSum = thisMultiplierSum //指定給 ret result

	scatterResult := s.getResultForScatter(retResult)

	//scatter info 算 free spin times。
	//有消除，要算最後一個 wheel
	_, _, retResult.ScatterInfo, err = s.base.CountSymbolInfo(scatterResult, s.gameSetting.BaseSetting.Symbol.ScatterID, s.gameSetting.BaseSetting.ColumnAndLine)
	if err != nil {
		retErr = fmt.Errorf("%s error %s", logPrefix, err.Error())
		return
	}

	//scatter payCredit
	scatterCredit, scatterPayRate := s.base.CountSymbolPayout(s.gameSetting.BaseSetting.Symbol.ScatterID[0], retResult.ScatterInfo.Amount, s.gameSetting.BaseSetting.PayTable, 1, betCredit)
	retResult.ScatterInfo.PayRate = scatterPayRate
	retResult.ScatterInfo.PayCredit = scatterCredit //未乘倍

	//free spin
	if s.isActiveFreeSpin(retResult.ScatterInfo.Amount, usedGameData.ActiveFreeSpinGreaterOrEqualAmount) {
		retResult.FreeSpinTimes = s.getFreeSpinTimes(retResult.ScatterInfo.Amount, usedGameData.FreeSpinTimes)
	}

	if thisMultiplierSum == 0 {
		//用1倍去計算(不加計，但是計算用1倍)
		thisMultiplierSum = 1
	} else if (len(retResult.Cascading) > 0 || scatterCredit > 0) && isFreeSpin {
		//freeSpin, 有贏分、有倍數，要累計, 且這次用累計的倍數
		retAccMultiplier += thisMultiplierSum
		thisMultiplierSum = retAccMultiplier
	}
	//其餘情況直接用 thisMultiplierSum

	//計算 cascading payCredit，scatter pay credit, 最後乘倍
	retResult.PayCreditTotal, _ = (decimal.NewFromFloat(s.sumCascadingPayCredit(retResult.Cascading)).Add(decimal.NewFromFloat(scatterCredit))).Mul(decimal.NewFromInt(int64(thisMultiplierSum))).Float64()
	return
}

func (s *Simulator) baseCascadingToCascading(baseCascading []*core.CascadingResult) (retCas []*cascading, retErr error) {
	logPrefix := "baseCascadingToCascading"

	retCas = []*cascading{}

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logPrefix, r)
			return
		}
	}()

	max := len(baseCascading) - 1

	if max < 0 {
		return
	}

	for i := 0; i <= max; i++ {
		v := baseCascading[i]
		cas := &cascading{
			v.InitResult,
			s.baseFlowToFlow(v.Flow),
			v.AddResult,
			v.NewResult,
			[]int{},
			0,
		}

		retCas = append(retCas, cas)
	}
	return
}

func (s *Simulator) fillCascadingMultipliers(multiplierID int, cascading []*cascading, tr *tableRate, firstMultipliers []int) (retErr error) {
	logPrefix := "fillCascadingMultipliers"

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logPrefix, r)
			return
		}
	}()

	max := len(cascading) - 1

	if max < 0 {
		return
	}

	//第一次消除,用 newResult 算 multipliers 數量及random

	//第二次消除，如果newResult的multiplier 數量變多，先填上一次的，在家新的
	var m int
	for i := 0; i <= max; i++ {
		v := cascading[i]

		//算這次的數量
		m = s.countMultiplierSymbolAmount(multiplierID, v.NewResult)
		var last []int

		//第一次，有可能接收gameResult 來的multipliers
		if i == 0 {
			last = firstMultipliers
		} else {
			last = cascading[i-1].Multipliers
		}
		mul := s.createMultipliersByLast(m, last, tr)
		v.MultiplierSum = s.sumMultipliers(mul)
		v.Multipliers = mul
	}

	return
}

func (s *Simulator) baseFlowToFlow(baseFlow []*core.Flow) (retFlow []*flow) {
	retFlow = []*flow{}

	for _, v := range baseFlow {
		f := &flow{
			v.SymbolID,
			v.Amount,
			0,
		}
		retFlow = append(retFlow, f)
	}
	return
}

func (s *Simulator) fillCascadingFlowPayCredit(cas []*cascading, pt []*core.BasePayTable, betCredit float64) {

	for _, v := range cas {

		//這個 cascading flow 有消除
		if len(v.Flow) > 0 {
			v.Flow = s.calculateFlowPayCredit(v.Flow, pt, 1, betCredit)
		}
	}
	return
}

func (s *Simulator) calculateFlowPayCredit(f []*flow, pt []*core.BasePayTable, mul int, betCredit float64) []*flow {

	if mul < 1 {
		mul = 1
	}
	for _, v := range f {
		rate := s.base.GetPayTablePayRate(v.SymbolID, v.Amount, pt)
		fl, _ := decimal.NewFromFloat(rate).Mul(decimal.NewFromFloat(float64(mul))).Mul(decimal.NewFromFloat(betCredit)).Float64()
		v.PayCredit = fl
	}
	return f
}
func (s *Simulator) sumCascadingPayCredit(cas []*cascading) float64 {

	pd := decimal.NewFromFloat(0)
	var ret float64 = 0
	for _, v := range cas {
		for _, vv := range v.Flow {
			pd = pd.Add(decimal.NewFromFloat(vv.PayCredit))
		}
	}
	ret, _ = pd.Float64()
	return ret
}

// countMultiplierSymbolAmount return multiplier symbol amount
func (s *Simulator) countMultiplierSymbolAmount(multiplierSymbolID int, wheel [][]int) int {
	retAmount := 0
	for i := 0; i < len(wheel); i++ {
		for j := 0; j < len(wheel[i]); j++ {
			if wheel[i][j] == multiplierSymbolID {
				retAmount++
			}
		}
	}
	return retAmount
}

// random multiplier weight table
func (s *Simulator) randomMultiplierWeightTable(gd *gameData) *tableRate {
	idx, err := slotUtil.RandomIndexOfWeightTable(gd.MultiplierTable)
	if err != nil {
		return gd.LowTable
	}
	if idx == 0 {
		return gd.LowTable
	}
	return gd.HighTable
}

func (s *Simulator) randomMultiplier(table *tableRate) int {

	idx, _ := slotUtil.RandomIndexOfWeightTable(table.Rate)
	return table.Element[idx]
}

// randomMultipleByMultiplierAmount 從 multiplier symbol 數量及 table rate，ran 每個 multiplier 的倍數
func (s *Simulator) randomMultipleByMultiplierAmount(mulAmount int, wt *tableRate) (retMultipliers []int) {
	retMultipliers = []int{}

	if mulAmount < 1 {
		return
	}

	var m int = 0
	for i := 0; i < mulAmount; i++ {
		m = s.randomMultiplier(wt)
		retMultipliers = append(retMultipliers, m)
	}
	return
}

// func (s *Simulator) runSpin(mode *core.Mode, isFreeSpin bool, betCredit float64) (retResult *gameResult, retErr error) {
func (s *Simulator) getBaseReel(mode *core.Mode, isFreeSpin bool) [][]int {
	if isFreeSpin {
		return mode.FreeSpin.BaseReel
	}
	return mode.BaseReel
}
func (s *Simulator) getReSpinReel(mode *core.Mode, isFreeSpin bool) [][]int {
	if isFreeSpin {
		return mode.FreeSpin.RespinReel
	}
	return mode.RespinReel

}
func (s *Simulator) getGameData(isFreeSpin bool) *gameData {
	if isFreeSpin {
		return s.usedExtraData.FreeGame
	}
	return s.usedExtraData.MainGame

}

func (s *Simulator) getFreeSpinTimes(scatterAmount int, times [][]int) int {

	max := len(times) - 1
	for i := max; i >= 0; i-- {
		if scatterAmount >= times[i][0] {
			return times[i][1]
		}
	}
	return 0
}
func (s *Simulator) getConfigExtraData(buy int) *configExtraData {
	if buy == configuration.BuySpinYes {
		return s.buyExtraData
	}
	return s.normalExtraData
}

func (s *Simulator) getEmptyGameResult() *gameResult {
	return &gameResult{
		0,
		[][]int{},
		[]*cascading{},
		0,
		0,
		[]int{},
		&core.BaseSymbolInfo{},
	}
}
func (s *Simulator) getEmptyResult(gameID int) *result {
	return &result{
		gameID,
		&gameResult{},
		false,
		&subGameResult{
			0,
			[]*gameResult{},
		},
	}
}

func (s *Simulator) isActiveFreeSpin(scatterAmount, activeAmount int) bool {
	if scatterAmount >= activeAmount {
		return true
	}
	return false
}

func (s *Simulator) createMultipliersByLast(multiplierAmount int, lastMultipliers []int, wt *tableRate) []int {

	lastLen := len(lastMultipliers)
	ret := make([]int, lastLen)
	copy(ret, lastMultipliers)

	n := multiplierAmount - lastLen
	//不可能小於上一次的數量
	if n <= 0 {
		return ret

	}

	//數量變多，要再random
	mul := s.randomMultipleByMultiplierAmount(n, wt) //multiplier 的倍數，從第一輪開始依序
	ret = append(ret, mul...)                        //補入新ran的multiplier

	return ret
}

func (s *Simulator) getLastMultipliers(cas []*cascading) []int {
	if ll := len(cas); ll == 0 {
		return nil
	} else {
		return cas[ll-1].Multipliers
	}
}

func (s *Simulator) sumMultipliers(mul []int) int {
	var sum = 0
	for _, v := range mul {
		sum += v
	}
	return sum
}

// 取最大的(最後一個)multipliers and sum
func (s *Simulator) getCascadingMultiplierSumMax(cas []*cascading) ([]int, int) {

	max := len(cas) - 1
	if max < 0 {
		return nil, 0
	}
	//copy multipliers
	co := make([]int, len(cas[max].Multipliers))
	copy(co, cas[max].Multipliers)
	return co, cas[max].MultiplierSum
}

func (s *Simulator) getThisSpinMultiplierSum(gr *gameResult) ([]int, int) {
	cl := len(gr.Cascading)
	if cl == 0 {
		//copy multipliers
		co := make([]int, len(gr.Multipliers))
		copy(co, gr.Multipliers)
		return co, gr.MultiplierSum
	}
	return s.getCascadingMultiplierSumMax(gr.Cascading)
}
func (s *Simulator) getResultForScatter(gr *gameResult) (retResultForScatter [][]int) {
	cl := len(gr.Cascading)
	if cl == 0 {
		return sliceUtil.Duplicate2DSlice(gr.GameResult)
	}
	return sliceUtil.Duplicate2DSlice(gr.Cascading[cl-1].NewResult)
}
