package handler

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	"github.com/idtksrv/service"
	"github.com/idtksrv/simulator-server/internal/configuration"

	"github.com/idtksrv/simulator-server/internal/rds"
	"github.com/idtksrv/simulator-server/internal/simulator"
)

type httpHandler struct {
	service      *service.Service
	logger       *service.Logger
	svcConfigure *service.Configure
	Configurator *configuration.Configurator
}

type Simulator interface {
	Spin(spinMode int, lineBet float64, lines int, coinValue float64, betCredit float64, rtp string, userId int64) ([]byte, error)
}
type mainGame interface {
}

type featureGame interface {
}

type jackpot interface {
}

func NewHTTPHandler(svc *service.Service, configurator *configuration.Configurator) (*httpHandler, error) {

	logger, err := svc.GetLogger()
	if err != nil {
		return nil, err
	}
	logger.IsFullPath(false)
	logger.SetFormatter(service.FormatterTypeJSON, true, false, nil)
	logger.SetLevel(service.LevelTrace) //最低層

	conf, err := svc.GetConfigure()
	if err != nil {
		return nil, err
	}

	pm := &httpHandler{
		service:      svc,
		logger:       logger,
		svcConfigure: conf,
		Configurator: configurator,
	}

	return pm, nil
}

func (h *httpHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	//logFunc := "ServeHTTP"
	logger, _ := h.service.GetLogger()
	//entry := logger.NewEntry()
	logger.Out(io.Discard)
	//l, _ := h.service.GetLogger()

	defer func() {
		if r := recover(); r != nil {
			resStr := h.getResCommand(configuration.CmdSpin, configuration.CodePanic, "error", h.getEmptyResData())
			_ = h.write(w, resStr)
			h.logger.LogFileTemp(service.LevelError, fmt.Sprintf("%s panic %s", "ServeHTTP", r))
		}
	}()

	//讀取伺服器傳來的command
	body, err := io.ReadAll(r.Body)
	if err != nil {
		errMsg := fmt.Sprintf("%s", err.Error())
		//logger.WithFieldsHook(entry, service.LevelError, logrus.Fields{"apiCommand": configuration.CmdSpin, "function": "ReadAll"}, errMsg)
		//_ = l.WithFieldsFile(service.LevelError, service.Fields{"caller": l.ReturnCallerFormatted()}, errMsg)
		resStr := h.getResCommand(configuration.CmdSpin, configuration.CodeBodyReadError, errMsg, h.getEmptyResData())
		_ = h.write(w, resStr)
		return
	}

	var req configuration.RequestModule
	if err = json.Unmarshal(body, &req); err != nil {
		errMsg := fmt.Sprintf("umarshal requestModule %v", err)
		//logger.WithFieldsHook(entry, service.LevelError, logrus.Fields{"apiCommand": configuration.CmdSpin, "function": "json.Unmarshal", "orderID": req.Data.OrderID}, errMsg)
		resStr := h.getResCommand(configuration.CmdSpin, configuration.CodeUnmarshalError, errMsg, h.getEmptyResData())
		_ = h.write(w, resStr)
		return
	}

	svcRedis, err := h.service.GetRedis()
	if err != nil {
		errMsg := fmt.Sprintf("GetRedis error %s", err.Error())
		resStr := h.getResCommand(configuration.CmdSpin, configuration.CodeError, errMsg, h.getEmptyResData())
		_ = h.write(w, resStr)
		return
	}

	// 取得玩家資料
	if req.Command == configuration.CmdGetUserData {
		data, err := rds.GetUserDataAllBet(svcRedis, req.Data.GameID, req.Data.UserID)
		if err != nil {
			errMsg := fmt.Sprintf("GetUserData error %s", err.Error())
			resStr := h.getResCommand(configuration.CmdGetUserData, configuration.CodeError, errMsg, h.getEmptyResData())
			_ = h.write(w, resStr)
			return
		}

		resByte, err := json.Marshal(data)
		if err != nil {
			errMsg := fmt.Sprintf("GetUserData Marshal error %s", err.Error())
			resStr := h.getResCommand(configuration.CmdGetUserData, configuration.CodeError, errMsg, h.getEmptyResData())
			_ = h.write(w, resStr)
			return
		}

		//success
		resStr := h.getResCommand(configuration.CmdGetUserData, configuration.CodeSuccess, "", resByte)

		err = h.write(w, resStr)
		if err != nil {
			h.logger.LogFileTemp(service.LevelError, fmt.Sprintf("write err %s", err))
		}
		return
	}

	// 取得 config.json 設定檔 內的 setting 資料
	sd, mgs, sgs, jps, err := h.Configurator.GetSettings(req.Data.GameID)
	if err != nil {
		resStr := h.getResCommand(configuration.CmdSpin, configuration.CodeError, err.Error(), h.getEmptyResData())
		_ = h.write(w, resStr)
		return
	}

	sim, err := h.GetSimulator(sd, mgs, sgs, jps, svcRedis)

	if err != nil {
		errMsg := fmt.Sprintf("GetSimulator error %s", err.Error())
		resStr := h.getResCommand(configuration.CmdSpin, configuration.CodeError, errMsg, h.getEmptyResData())
		_ = h.write(w, resStr)
		return
	}

	spinRes, serr := sim.Spin(req.Data.BuySpin, req.Data.LineBet, req.Data.LineNum, req.Data.CoinValue, req.Data.BetCredit, req.Data.RTP, req.Data.UserID)
	if serr != nil {
		errMsg := fmt.Sprintf("spin error %s", serr.Error())
		resStr := h.getResCommand(configuration.CmdSpin, configuration.CodeError, errMsg, h.getEmptyResData())
		_ = h.write(w, resStr)
		return
	}

	//success
	resStr := h.getResCommand(configuration.CmdSpin, configuration.CodeSuccess, "", spinRes)

	err = h.write(w, resStr)
	if err != nil {
		h.logger.LogFileTemp(service.LevelError, fmt.Sprintf("write err %s", err))
		//_ = h.logger.WithFieldFile(service.LevelError, "func", "write", err.Error())
	}
}

func (h *httpHandler) GetSimulator(sd *configuration.SimulatorSetting, mgs *configuration.GameSetting, sgs *configuration.GameSetting, jps *configuration.JackpotSetting, rds *service.Redis) (Simulator, error) {
	return simulator.NewSimulator(sd, mgs, sgs, jps, rds)
}

// // 2600 之後的遊戲 沒有使用
// func (h *httpHandler) GetMainGame(gs *configuration.GameSetting, gameSettingID int) (mainGame, error) {
// 	if gs.GameType == configuration.MainGame3X3MultiplierTime {
// 		return mainGame2100.NewGame(gs.GameType, gs.GameSetting, gameSettingID)
// 	}
// 	return nil, fmt.Errorf("mainGame not found game type %d", gs.GameType)
// }

// func (h *httpHandler) GetFeatureGame(gs *configuration.GameSetting, featureGameSettingID int) (featureGame, error) {
// 	return nil, errors.New("")
// }

// func (h *httpHandler) GetJackpot(set *configuration.JackpotSetting, jackpotID int) (featureGame, error) {
// 	return nil, errors.New("")
// }

func (h *httpHandler) getResCommand(cmd string, errCode int, msg string, data []byte) string {
	rd := configuration.ResponseModule{
		Command:   cmd,
		ErrorCode: errCode,
		Message:   msg,
		Data:      json.RawMessage(data),
	}
	b, _ := json.Marshal(rd)
	return string(b)
}

func (h *httpHandler) getEmptyResData() []byte {

	var s []struct{}
	b, _ := json.Marshal(s)
	return b
}

func (h *httpHandler) write(w http.ResponseWriter, resStr string) error {

	//CORS
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Content-Type", "application/json")

	w.Header().Set("Access-Control-Allow-Credentials", "true")

	w.Header().Set("Access-Control-Allow-Headers", "Content-Type,access-control-allow-origin, access-control-allow-headers")
	w.Header().Set("charset", "UTF-8")

	w.Header().Set("Cache-Control", "no-cache, no-store, must-revalidate") // HTTP 1.1.
	w.Header().Set("Pragma", "no-cache")                                   // HTTP 1.0.
	w.Header().Set("Expires", "0")                                         // Proxies.
	w.WriteHeader(http.StatusOK)

	_, err := io.WriteString(w, resStr)
	return err

}
