package rds

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/idtksrv/service"
	"github.com/redis/go-redis/v9"
)

func simKey(gameId int, userId int64) string {
	return fmt.Sprintf("sim_%v_%v", gameId, userId)
}

func getUserDataField(betCredit float64) string {
	return fmt.Sprintf("%v", betCredit)
}

func GetUserDataAllBet(rds *service.Redis, gameId int, userId int64) (map[string]json.RawMessage, error) {
	data, err := rds.HGetAll(simKey(gameId, userId))
	if err != nil {
		return nil, err
	}

	result := map[string]json.RawMessage{}

	for i, v := range data {
		result[i] = json.RawMessage(v)
	}

	return result, nil
}

func SetUserData(rds *service.Redis, gameId int, userId int64, betCredit float64, data []byte) error {
	m := map[string]interface{}{
		getUserDataField(betCredit): data,
	}

	err := rds.HMSet(simKey(gameId, userId), m)
	if err != nil {
		return err
	}

	return nil
}

func GetUserData4800(rds *service.Redis, gameId int, userId int64, betCredit float64) (*UserData4800, error) {
	res := &UserData4800{}

	field := getUserDataField(betCredit)
	resultBytes, err := rds.GetClient().HGet(context.TODO(), simKey(gameId, userId), field).Bytes()
	if err != nil {
		if err == redis.Nil {
			fmt.Println("redis.Nil")
			return res, nil
		}
		return nil, err
	}

	err = json.Unmarshal(resultBytes, res)
	if err != nil {
		return res, nil
	}

	return res, nil
}
