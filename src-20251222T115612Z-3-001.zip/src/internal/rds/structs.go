package rds

type UserData4800 struct {
	RandomWildGem int `json:"random_wild_gem"` // 亂數 wild 寶石
	WildX2Gem     int `json:"wildX2_gem"`      // wild x2 寶石
}
