package rds

import (
	"github.com/idtksrv/service"
)

var (
	// userData0 = &UserData4800{
	// 	RandomWildGem: 3,
	// 	WildX2Gem:     3,
	// }
	userData0  = &UserData4800{}
	userData1  = &UserData4800{}
	userData2  = &UserData4800{}
	userData3  = &UserData4800{}
	userData4  = &UserData4800{}
	userData5  = &UserData4800{}
	userData6  = &UserData4800{}
	userData7  = &UserData4800{}
	userData8  = &UserData4800{}
	userData9  = &UserData4800{}
	userData10 = &UserData4800{}
	userData11 = &UserData4800{}
	userData12 = &UserData4800{}
	userData13 = &UserData4800{}
	userData14 = &UserData4800{}
	userData15 = &UserData4800{}
	userData16 = &UserData4800{}
	userData17 = &UserData4800{}
	userData18 = &UserData4800{}
	userData19 = &UserData4800{}
	userData20 = &UserData4800{}
	userData21 = &UserData4800{}
	userData22 = &UserData4800{}
	userData23 = &UserData4800{}
	userData24 = &UserData4800{}
	userData25 = &UserData4800{}
	userData26 = &UserData4800{}
	userData27 = &UserData4800{}
	userData28 = &UserData4800{}
	userData29 = &UserData4800{}
	userData30 = &UserData4800{}
	userData31 = &UserData4800{}
	userData32 = &UserData4800{}
	userData33 = &UserData4800{}
	userData34 = &UserData4800{}
	userData35 = &UserData4800{}
	userData36 = &UserData4800{}
	userData37 = &UserData4800{}
	userData38 = &UserData4800{}
	userData39 = &UserData4800{}
	userData40 = &UserData4800{}
	userData41 = &UserData4800{}
	userData42 = &UserData4800{}
	userData43 = &UserData4800{}
	userData44 = &UserData4800{}
	userData45 = &UserData4800{}
	userData46 = &UserData4800{}
	userData47 = &UserData4800{}
	userData48 = &UserData4800{}
	userData49 = &UserData4800{}
	userData50 = &UserData4800{}
	userData51 = &UserData4800{}
	userData52 = &UserData4800{}
	userData53 = &UserData4800{}
	userData54 = &UserData4800{}
	userData55 = &UserData4800{}
	userData56 = &UserData4800{}
	userData57 = &UserData4800{}
	userData58 = &UserData4800{}
	userData59 = &UserData4800{}
	userData60 = &UserData4800{}
	userData61 = &UserData4800{}
	userData62 = &UserData4800{}
	userData63 = &UserData4800{}
	userData64 = &UserData4800{}
	userData65 = &UserData4800{}
	userData66 = &UserData4800{}
	userData67 = &UserData4800{}
	userData68 = &UserData4800{}
	userData69 = &UserData4800{}
	userData70 = &UserData4800{}
	userData71 = &UserData4800{}
	userData72 = &UserData4800{}
	userData73 = &UserData4800{}
	userData74 = &UserData4800{}
	userData75 = &UserData4800{}
	userData76 = &UserData4800{}
	userData77 = &UserData4800{}
	userData78 = &UserData4800{}
	userData79 = &UserData4800{}
	userData80 = &UserData4800{}
	userData81 = &UserData4800{}
	userData82 = &UserData4800{}
	userData83 = &UserData4800{}
	userData84 = &UserData4800{}
	userData85 = &UserData4800{}
	userData86 = &UserData4800{}
	userData87 = &UserData4800{}
	userData88 = &UserData4800{}
	userData89 = &UserData4800{}
	userData90 = &UserData4800{}
	userData91 = &UserData4800{}
	userData92 = &UserData4800{}
	userData93 = &UserData4800{}
	userData94 = &UserData4800{}
	userData95 = &UserData4800{}
	userData96 = &UserData4800{}
	userData97 = &UserData4800{}
	userData98 = &UserData4800{}
	userData99 = &UserData4800{}
)

func GetUserData4800Test(rds *service.Redis, gameId int, userId int64) (*UserData4800, error) {

	switch userId {
	case 0:
		return userData0, nil
	case 1:
		return userData1, nil
	case 2:
		return userData2, nil
	case 3:
		return userData3, nil
	case 4:
		return userData4, nil
	case 5:
		return userData5, nil
	case 6:
		return userData6, nil
	case 7:
		return userData7, nil
	case 8:
		return userData8, nil
	case 9:
		return userData9, nil
	case 10:
		return userData10, nil
	case 11:
		return userData11, nil
	case 12:
		return userData12, nil
	case 13:
		return userData13, nil
	case 14:
		return userData14, nil
	case 15:
		return userData15, nil
	case 16:
		return userData16, nil
	case 17:
		return userData17, nil
	case 18:
		return userData18, nil
	case 19:
		return userData19, nil
	case 20:
		return userData20, nil
	case 21:
		return userData21, nil
	case 22:
		return userData22, nil
	case 23:
		return userData23, nil
	case 24:
		return userData24, nil
	case 25:
		return userData25, nil
	case 26:
		return userData26, nil
	case 27:
		return userData27, nil
	case 28:
		return userData28, nil
	case 29:
		return userData29, nil
	case 30:
		return userData30, nil
	case 31:
		return userData31, nil
	case 32:
		return userData32, nil
	case 33:
		return userData33, nil
	case 34:
		return userData34, nil
	case 35:
		return userData35, nil
	case 36:
		return userData36, nil
	case 37:
		return userData37, nil
	case 38:
		return userData38, nil
	case 39:
		return userData39, nil
	case 40:
		return userData40, nil
	case 41:
		return userData41, nil
	case 42:
		return userData42, nil
	case 43:
		return userData43, nil
	case 44:
		return userData44, nil
	case 45:
		return userData45, nil
	case 46:
		return userData46, nil
	case 47:
		return userData47, nil
	case 48:
		return userData48, nil
	case 49:
		return userData49, nil
	case 50:
		return userData50, nil
	case 51:
		return userData51, nil
	case 52:
		return userData52, nil
	case 53:
		return userData53, nil
	case 54:
		return userData54, nil
	case 55:
		return userData55, nil
	case 56:
		return userData56, nil
	case 57:
		return userData57, nil
	case 58:
		return userData58, nil
	case 59:
		return userData59, nil
	case 60:
		return userData60, nil
	case 61:
		return userData61, nil
	case 62:
		return userData62, nil
	case 63:
		return userData63, nil
	case 64:
		return userData64, nil
	case 65:
		return userData65, nil
	case 66:
		return userData66, nil
	case 67:
		return userData67, nil
	case 68:
		return userData68, nil
	case 69:
		return userData69, nil
	case 70:
		return userData70, nil
	case 71:
		return userData71, nil
	case 72:
		return userData72, nil
	case 73:
		return userData73, nil
	case 74:
		return userData74, nil
	case 75:
		return userData75, nil
	case 76:
		return userData76, nil
	case 77:
		return userData77, nil
	case 78:
		return userData78, nil
	case 79:
		return userData79, nil
	case 80:
		return userData80, nil
	case 81:
		return userData81, nil
	case 82:
		return userData82, nil
	case 83:
		return userData83, nil
	case 84:
		return userData84, nil
	case 85:
		return userData85, nil
	case 86:
		return userData86, nil
	case 87:
		return userData87, nil
	case 88:
		return userData88, nil
	case 89:
		return userData89, nil
	case 90:
		return userData90, nil
	case 91:
		return userData91, nil
	case 92:
		return userData92, nil
	case 93:
		return userData93, nil
	case 94:
		return userData94, nil
	case 95:
		return userData95, nil
	case 96:
		return userData96, nil
	case 97:
		return userData97, nil
	case 98:
		return userData98, nil
	case 99:
		return userData99, nil
	}

	return userData0, nil
}

func SetUserDataTest(rds *service.Redis, gameId int, userId int64, data *UserData4800) error {
	switch userId {
	case 0:
		userData0 = data
	case 1:
		userData1 = data
	case 2:
		userData2 = data
	case 3:
		userData3 = data
	case 4:
		userData4 = data
	case 5:
		userData5 = data
	case 6:
		userData6 = data
	case 7:
		userData7 = data
	case 8:
		userData8 = data
	case 9:
		userData9 = data
	case 10:
		userData10 = data
	case 11:
		userData11 = data
	case 12:
		userData12 = data
	case 13:
		userData13 = data
	case 14:
		userData14 = data
	case 15:
		userData15 = data
	case 16:
		userData16 = data
	case 17:
		userData17 = data
	case 18:
		userData18 = data
	case 19:
		userData19 = data
	case 20:
		userData20 = data
	case 21:
		userData21 = data
	case 22:
		userData22 = data
	case 23:
		userData23 = data
	case 24:
		userData24 = data
	case 25:
		userData25 = data
	case 26:
		userData26 = data
	case 27:
		userData27 = data
	case 28:
		userData28 = data
	case 29:
		userData29 = data
	case 30:
		userData30 = data
	case 31:
		userData31 = data
	case 32:
		userData32 = data
	case 33:
		userData33 = data
	case 34:
		userData34 = data
	case 35:
		userData35 = data
	case 36:
		userData36 = data
	case 37:
		userData37 = data
	case 38:
		userData38 = data
	case 39:
		userData39 = data
	case 40:
		userData40 = data
	case 41:
		userData41 = data
	case 42:
		userData42 = data
	case 43:
		userData43 = data
	case 44:
		userData44 = data
	case 45:
		userData45 = data
	case 46:
		userData46 = data
	case 47:
		userData47 = data
	case 48:
		userData48 = data
	case 49:
		userData49 = data
	case 50:
		userData50 = data
	case 51:
		userData51 = data
	case 52:
		userData52 = data
	case 53:
		userData53 = data
	case 54:
		userData54 = data
	case 55:
		userData55 = data
	case 56:
		userData56 = data
	case 57:
		userData57 = data
	case 58:
		userData58 = data
	case 59:
		userData59 = data
	case 60:
		userData60 = data
	case 61:
		userData61 = data
	case 62:
		userData62 = data
	case 63:
		userData63 = data
	case 64:
		userData64 = data
	case 65:
		userData65 = data
	case 66:
		userData66 = data
	case 67:
		userData67 = data
	case 68:
		userData68 = data
	case 69:
		userData69 = data
	case 70:
		userData70 = data
	case 71:
		userData71 = data
	case 72:
		userData72 = data
	case 73:
		userData73 = data
	case 74:
		userData74 = data
	case 75:
		userData75 = data
	case 76:
		userData76 = data
	case 77:
		userData77 = data
	case 78:
		userData78 = data
	case 79:
		userData79 = data
	case 80:
		userData80 = data
	case 81:
		userData81 = data
	case 82:
		userData82 = data
	case 83:
		userData83 = data
	case 84:
		userData84 = data
	case 85:
		userData85 = data
	case 86:
		userData86 = data
	case 87:
		userData87 = data
	case 88:
		userData88 = data
	case 89:
		userData89 = data
	case 90:
		userData90 = data
	case 91:
		userData91 = data
	case 92:
		userData92 = data
	case 93:
		userData93 = data
	case 94:
		userData94 = data
	case 95:
		userData95 = data
	case 96:
		userData96 = data
	case 97:
		userData97 = data
	case 98:
		userData98 = data
	case 99:
		userData99 = data
	}

	return nil
}
