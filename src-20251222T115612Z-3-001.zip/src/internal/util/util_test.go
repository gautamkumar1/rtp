package util

import (
	"reflect"
	"testing"
)

func TestChangeToJPReel(t *testing.T) {
	type args struct {
		gameResult [][]int
		JPID       string
	}
	tests := []struct {
		name       string
		args       args
		wantJPReel [][]int
		wantErr    bool
	}{
		{"mini", args{
			[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
			"mini"},
			[][]int{{6, 1, 5}, {8, 1, 4}, {5, 5, 3}},
			false,
		},
		{"minor", args{
			[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
			"minor"},
			[][]int{{6, 1, 5}, {8, 1, 4}, {5, 1, 3}},
			false,
		},
		{"major", args{
			[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
			"major"},
			[][]int{{6, 1, 5}, {1, 9, 1}, {5, 1, 3}},
			false,
		},
		{"grand", args{
			[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
			"grand"},
			[][]int{{6, 1, 5}, {1, 1, 1}, {5, 1, 3}},
			false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotJPReel, err := ChangeToJPReel(tt.args.gameResult, tt.args.JPID)
			if (err != nil) != tt.wantErr {
				t.Errorf("ChangeToJPReel() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotJPReel, tt.wantJPReel) {
				t.Errorf("ChangeToJPReel() gotJPReel = %v, want %v", gotJPReel, tt.wantJPReel)
			}
		})
	}
}

func TestModifyIntArrayToJPReelSingle(t *testing.T) {
	type args struct {
		source       [][]int
		newElement   int
		modifyAmount int
	}
	tests := []struct {
		name    string
		args    args
		want    [][]int
		wantErr bool
	}{
		{"test", args{
			[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}, {5, 5, 3}, {5, 5, 3}},
			1, 3,
		}, [][]int{{6, 1, 5}, {8, 1, 4}, {5, 1, 3}, {5, 5, 3}, {5, 5, 3}},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ModifyIntArrayToJPReelSingle(tt.args.source, tt.args.newElement, tt.args.modifyAmount)
			if (err != nil) != tt.wantErr {
				t.Errorf("ModifyIntArrayToJPReelSingle() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !tt.wantErr {
				newElementNum := 0
				for _, v := range got {
					for _, w := range v {
						if w == tt.args.newElement {
							newElementNum += 1
						}
					}
				}
				if newElementNum != tt.args.modifyAmount {
					t.Errorf("ModifyIntArrayElement() got newEle num= %d, want %d", newElementNum, tt.args.modifyAmount)
				}
			}

		})
	}
}

func TestCopySpecifyElement(t *testing.T) {
	type args struct {
		oriSlice       [][]int
		targetSlice    [][]int
		specifyElement []int
	}
	tests := []struct {
		name         string
		args         args
		wantRetSlice [][]int
		wantErr      bool
	}{
		{
			"0",
			args{
				[][]int{},
				[][]int{{}},
				[]int{},
			},
			[][]int{},
			true,
		},
		{
			"1",
			args{
				[][]int{{0, 1, 0}, {0, 1, 0}, {0, 1, 0}, {0, 1, 0}, {0, 1, 0}},
				[][]int{{2, 2, 2}, {0, 0, 0}, {2, 2, 2}, {0, 0, 0}, {2, 2, 2}},
				[]int{1},
			},
			[][]int{{2, 1, 2}, {0, 1, 0}, {2, 1, 2}, {0, 1, 0}, {2, 1, 2}},
			false,
		},
		{
			"2",
			args{
				[][]int{{0, 1, 0}, {0, 1, 0}, {0, 1, 0}, {0, 1, 0}, {0, 1, 0}},
				[][]int{{2, 2, 2}, {0, 0, 0}, {2, 2, 2}, {0, 0, 0}, {2, 2, 2}},
				[]int{-1},
			},
			[][]int{{2, 2, 2}, {0, 0, 0}, {2, 2, 2}, {0, 0, 0}, {2, 2, 2}},
			false,
		},
		{
			"3",
			args{
				[][]int{{0, 1, 0}, {0, 1, 0}, {0, 1, 0}, {0, 1, 0}, {0, 1, 0}},
				[][]int{{2, 2, 2}, {0, 0, 0}, {2, 2, 2}, {0, 0, 0}, {2, 2, 2}},
				[]int{-1, 1},
			},
			[][]int{{2, 1, 2}, {0, 1, 0}, {2, 1, 2}, {0, 1, 0}, {2, 1, 2}},
			false,
		},
		{
			"4",
			args{
				[][]int{{0, 1, 0}, {0, 1, 3}, {0, 1, 3}, {0, 2, 3}, {0, 1, 0}},
				[][]int{{2, 2, 2}, {0, 0, 0}, {2, 2, 2}, {0, 0, 0}, {2, 2, 2}},
				[]int{2, 3},
			},
			[][]int{{2, 2, 2}, {0, 0, 3}, {2, 2, 3}, {0, 2, 3}, {2, 2, 2}},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotRetSlice, err := CopySpecifyElement(tt.args.oriSlice, tt.args.targetSlice, tt.args.specifyElement)
			if (err != nil) != tt.wantErr {
				t.Errorf("CopySpecifyElement() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotRetSlice, tt.wantRetSlice) {
				t.Errorf("CopySpecifyElement() gotRetSlice = %v, want %v", gotRetSlice, tt.wantRetSlice)
			}
		})
	}
}

//func TestRandom(t *testing.T) {
//	type args struct {
//		min int64
//		max int64
//	}
//	tests := []struct {
//		name string
//		args args
//		want int64
//	}{
//		{
//			"0",
//			args{
//				2,
//				2,
//			},
//			2,
//		},
//	}
//		for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			if got := Random(tt.args.min, tt.args.max); got != tt.want {
//				t.Errorf("Random() = %v, want %v", got, tt.want)
//			}
//		})
//	}
//}
