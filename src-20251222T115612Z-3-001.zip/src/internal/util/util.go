package util

import (
	"fmt"
	"log"
	"regexp"
	"strings"

	mathUtil "github.com/idtksrv/simulator-server/internal/util/math"
	"github.com/idtksrv/simulator-server/internal/util/rand"
)

func init() {
}

// ModifyIntArrayToJPReelSingle 用newElement 更改source slice的 element, 數量為 modifyAmount
func ModifyIntArrayToJPReelSingle(source [][]int, newElement int, modifyAmount int) ([][]int, error) {

	column := len(source) //5
	if column == 0 {
		return source, fmt.Errorf("source length want >0, got %d", len(source))
	}
	line := len(source[0]) //3

	if line == 0 {
		return source, fmt.Errorf("source[0] length want >0, got %d", len(source[0]))
	}

	if modifyAmount <= 0 {
		return source, fmt.Errorf("modifyAmount want >0, got %d", modifyAmount)
	}

	//make temp slice to store rand position
	temp := make([][]int, column)
	for i := range temp {
		temp[i] = make([]int, line)
	}

	var shuffle []int
	for i := 0; i < column; i++ {
		shuffle = append(shuffle, i)
	}
	rand.Shuffle(len(shuffle), func(i, j int) {
		shuffle[i], shuffle[j] = shuffle[j], shuffle[i]
	})

	var changeIndex []int
	for i := 0; i < modifyAmount; i++ {
		changeIndex = append(changeIndex, rand.Intn(line)) //0,1,2
	}

	if len(shuffle) < len(changeIndex) {
		return source, fmt.Errorf("len(shuffle) : %v < len(changeIndex): %v", len(shuffle), len(changeIndex))
	}

	for index, value := range changeIndex {
		source[shuffle[index]][value] = newElement
	}

	return source, nil
}

func ChangeToJPReel(gameResult [][]int, JPID string) (JPReel [][]int, retErr error) {
	logFunc := "ChangeToJPReel"
	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("%s panic %s", logFunc, r)
		}
	}()
	JPSymbol := 1
	if gameResult == nil {
		return nil, fmt.Errorf("gameResult length want is nil : %v", gameResult)
	}
	if len(gameResult) != 3 {
		return nil, fmt.Errorf("gameResult length : %v want 3", gameResult)
	}
	if len(gameResult[0]) != 3 || len(gameResult[1]) != 3 || len(gameResult[2]) != 3 {
		return nil, fmt.Errorf("gameResult[0],[1],[2] length : %v want 3\n", gameResult)
	}
	//枚舉法 比較好寫
	switch JPID {
	case "mini":
		gameResult[0][1] = JPSymbol
		gameResult[1][1] = JPSymbol
	case "minor":
		gameResult[0][1] = JPSymbol
		gameResult[1][1] = JPSymbol
		gameResult[2][1] = JPSymbol
	case "major":
		gameResult[0][1] = JPSymbol
		gameResult[1][0] = JPSymbol
		gameResult[1][2] = JPSymbol
		gameResult[2][1] = JPSymbol
	case "grand":
		gameResult[0][1] = JPSymbol
		gameResult[1][0] = JPSymbol
		gameResult[1][1] = JPSymbol
		gameResult[1][2] = JPSymbol
		gameResult[2][1] = JPSymbol
	}

	return gameResult, retErr
}

// CopyTargetElement
// 從 oriSlice copy target element to targetSlice
// oriSlice 跟targetSlice 規格要一樣
// opposite 是否取反值(不同於 specifyElement的, copy 過去)
func CopySpecifyElement(oriSlice, targetSlice [][]int, specifyElement []int) (retSlice [][]int, retErr error) {
	oLen := len(oriSlice)
	tLen := len(targetSlice)

	if oLen != tLen || oLen == 0 || tLen == 0 || len(specifyElement) == 0 {
		return [][]int{}, fmt.Errorf("ori slice and target slice length not match")
	}

	defer func() {
		if r := recover(); r != nil {
			retErr = fmt.Errorf("CopyTargetElement panic %s", r)
			return
		}
	}()

	for i, content := range oriSlice {
		for j, v := range content {
			for _, e := range specifyElement {
				if v == e {
					targetSlice[i][j] = v
					break
				}
			}
		}
	}
	return targetSlice, nil
}

//func Make2DSlice(defaultValue int, firstDimensionLength, secondDimensionLength int) [][]int {
//	var retSlice [][]int
//	for i := 0; i < firstDimensionLength; i++ {
//		var r = make([]int, secondDimensionLength, secondDimensionLength)
//		for j := 0; j < secondDimensionLength; j++ {
//			r[j] = defaultValue
//		}
//
//		retSlice = append(retSlice, r)
//	}
//	return retSlice
//}

// 計算array中幾個指定element
func CountSpecifyElementAmount(ary [][]int, element []int) int {
	amount := 0
	for _, content := range ary {
		for _, v := range content {

			got := false
			for _, s := range element {
				if v == s {
					got = true
					break
				}
			}
			if !got {
				amount++
			}
		}
	}
	return amount
}

//Random return min<= int64 <=max
//if max < min, return max
//func Random(min, max int64) int64 {
//	if max < min {
//		return max
//	} else if min == max {
//		return min
//	}
//	//default is not include max, so max+1
//	bg := big.NewInt(max + 1 - min)
//
//	n, err := cRand.Int(cRand.Reader, bg)
//	if err != nil {
//		panic(err)
//	}
//
//	return n.Int64() + min
//}

func FormatCommas(num int64) string {
	str := fmt.Sprintf("%d", num)
	re := regexp.MustCompile("(\\d+)(\\d{3})")
	for n := ""; n != str; {
		n = str
		str = re.ReplaceAllString(str, "$1,$2")
	}
	return str
}

func IntInSlice(s []int, e int) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}

func LogErrorPayoutCreditDecimal(mainGameCredit, subGameCredit float64, decimalNumber int) {

	sn := mathUtil.CountDecimalNum(mainGameCredit)
	if sn > decimalNumber {
		log.Println("sn,  MainGame PayCreditTotal ", sn, mainGameCredit)
	} else if sn == decimalNumber {
		x := fmt.Sprintf("%f", mainGameCredit)
		if strings.Index(x, ".000000") == -1 { //error
			log.Println("sn, str, MainGame PayCreditTotal ", sn, x, mainGameCredit)
		}
	}

	sn = mathUtil.CountDecimalNum(subGameCredit)
	if sn > decimalNumber {
		log.Println("sn, str, subGame PayCreditTotal ", sn, subGameCredit)
	} else if sn == decimalNumber {
		if sn >= decimalNumber {
			x := fmt.Sprintf("%f", subGameCredit)
			if strings.Index(x, ".000000") == -1 { //error
				log.Println("sn, str, subGame PayCreditTotal ", sn, x, subGameCredit)
			}
		}
	}
}
