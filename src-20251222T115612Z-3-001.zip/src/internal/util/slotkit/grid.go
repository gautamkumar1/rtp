package slotkit

// Grid
type Grid struct {
	Symbol Symbol
	Param  interface{}
}

// Grids :
type Grids []*Grid

// NewGrid : 建立彩帶
func NewGrid(length int) Grids {
	g := make([]*Grid, length)
	for i := range g {
		g[i] = &Grid{}
	}
	return g
}

// At : 以循環方式轉換 index.
// 當 index = -1 時, 返回最後一個位置的 Pos.
// 當 index = length 時, 返回第一個位置 Pos.
func (g Grids) At(index int) *Grid {
	length := g.Length()
	index = ((index % length) + length) % length
	return g[index]
}

// Length : 取得彩帶長度
func (g Grids) Length() int {
	return len(g)
}

// Bound : 檢查 index 是否在彩帶範圍內
func (s Grids) Bound(index int) bool {
	return (0 <= index && s.Length() > index)
}

// Swap : 交換 Pos
func (s *Grids) Swap(a int, b int) bool {
	if s.Bound(a) && s.Bound(b) {
		pos := (*s)[a]
		(*s)[a] = (*s)[b]
		(*s)[b] = pos
		return true
	}
	return false
}

// SetSymbols : 設定彩帶圖騰
func (s *Grids) SetSymbols(index int, symbols ...Symbol) int {
	for i, symbol := range symbols {

		// 取得 Pos
		if pos := (*s)[index]; nil != pos {
			pos.Symbol = symbol
			index++
			continue
		}

		// 傳回設定的數量
		return i
	}
	// 設定全部完成, 傳回數量
	return s.Length()
}

// CountID : 計算相同 id 的數量
func (s Grids) CountID(id int) int {
	count := 0
	for _, pos := range s {
		if pos.Symbol.Id() == id {
			count++
		}
	}
	return count
}

// CountMatch : 計算相符圖騰 flag 的數量
func (s Grids) CountMatch(mask uint32) int {
	count := 0
	for _, pos := range s {
		if pos.Symbol.Match(mask) {
			count++
		}
	}
	return count
}

// CountEqual : 計算相同圖騰數量 (id 與 flag 皆相等)
func (s Grids) CountEqual(symbol Symbol) int {
	count := 0
	for _, pos := range s {
		if pos.Symbol.Equal(symbol) {
			count++
		}
	}
	return count
}

// FindMatch : 尋找相符合的圖騰.
// start : 起始位置.
// 成功 : 當找到符合條件的圖騰時, 傳回 index 與 Pos.
// 失敗 : 傳回 -1
func (s Grids) FindMatch(mask uint32, start int) int {
	return s.find(mask, start, true)
}

// FindUnmatch : 尋找不相符的圖騰.
// start : 起始位置.
// 成功 : 當找到符合條件的圖騰時, 傳回 index 與 Pos.
// 失敗 : 傳回 start 與 nil
func (s Grids) FindUnmatch(mask uint32, start int) int {
	return s.find(mask, start, false)
}

// Combinations : 檢查連線組合, 傳回連線長度
func (s Grids) Combinations(mask uint32) int {
	count := 0
	for _, pos := range s {
		if !pos.Symbol.Match(mask) {
			return count
		}
		count++
	}
	return count
}

// Reverse : 反轉彩帶
func (g Grids) Reverse() Grids {
	len := g.Length()
	strip := make(Grids, len)
	for i, pos := range g {
		strip[len-i-1] = pos
	}
	return strip
}

// GetSymbolsId : 取得彩帶上的圖騰
func (g Grids) GetSymbolsId() []int {
	ids := make([]int, g.Length())
	for i, pos := range g {
		ids[i] = pos.Symbol.Id()
	}
	return ids
}

func (g *Grids) find(mask uint32, start int, match bool) int {

	for i := start; i < g.Length(); i++ {
		pos := g.At(i)
		// 檢查錯誤
		if nil == pos || nil == pos.Symbol {
			break
		}
		if match == pos.Symbol.Match(mask) {
			return i
		}
	}

	return -1
}

// ResetParams : 清除 Param
func (g *Grids) ResetParams() {
	for _, pos := range *g {
		pos.Param = nil
	}
}

func (g Grids) String() string {
	var str string = "["
	for _, pos := range g {
		if nil == pos.Symbol {
			str += " --"
			continue
		}
		str += " " + pos.Symbol.String()
	}
	str += " ]"
	return str
}
