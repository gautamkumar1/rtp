package slotkit

import (
	"fmt"
	"strings"
)

type Symbol interface {

	// ID : 圖騰識別
	Id() int

	// Flag : 圖騰類型
	Flag() uint32

	// String : 圖騰文字描述
	String() string

	// Match : 檢查圖騰是否符合指定的 flag.
	//  成立條件 : (symbol.flag & mask) == symbol.flag
	Match(uint32) bool

	// Equal : 檢查兩個圖騰是否相等 (id 與 flag 必須完全相同)
	Equal(Symbol) bool
}

// symbol :
type symbol struct {
	id   int    // 圖騰編號
	flag uint32 // 圖騰類型
	str  string // 圖騰描述文字
}

// NewSymbol : 建立 Symbol 物件
func NewSymbol(id int, flag uint32, str ...string) Symbol {

	s := strings.Join(str, "")
	if len(s) == 0 {
		s = fmt.Sprintf("%02d", id)
	}

	return &symbol{
		id:   id,
		flag: flag,
		str:  s,
	}
}

// // Create : 建立 Symbol 物件
// func (s *Symbol) Create(id int, flag uint32, str string) {
// 	s.id = id
// 	s.flag = flag
// 	s.str = str
// }

func (s *symbol) Id() int {
	return s.id
}

func (s *symbol) Flag() uint32 {
	return s.flag
}

func (s symbol) String() string {
	return s.str
}

func (s *symbol) Match(mask uint32) bool {
	return nil != s && s.flag == (s.flag&mask)
}

func (s *symbol) Equal(s2 Symbol) bool {
	return (nil != s && nil != s2) && (s.id == s2.Id() && s.flag == s2.Flag())
}

// SymbolMap : 圖騰對照表
type SymbolMap map[int]Symbol

// GetSymbols : 取得指定 id 的圖騰陣列, 如果 id 不存在則忽略.
//
//	可依據返回的陣列長度來判斷結果.
func (sm SymbolMap) GetSymbls(ids []int) []Symbol {
	var symbols []Symbol
	for _, id := range ids {
		if s, ok := sm[id]; ok {
			symbols = append(symbols, s)
		}
	}
	return symbols
}

// GetSymbolsByRange : 取得指定 id 的圖騰陣列, 並依據 start 與 count 來取得指定範圍的圖騰.
func (sm SymbolMap) GetSymbolsByRange(ids []int, start int, count int) []Symbol {
	var symbols []Symbol
	for i := 0; i < count && len(ids) > 0; i++ {
		id := ids[(start+i)%len(ids)]
		if s, ok := sm[id]; ok {
			symbols = append(symbols, s)
		}
	}
	return symbols
}
