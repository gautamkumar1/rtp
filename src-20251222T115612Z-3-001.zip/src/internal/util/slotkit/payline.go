package slotkit

type Payline struct {
	pos []int
}

// NewPayline : 建立 Payline 物件
func NewPayline(pos ...int) *Payline {
	p := &Payline{}
	p.Create(pos...)
	return p
}

// Create : 建立 Payline 物件
func (p *Payline) Create(pos ...int) {
	p.pos = pos
}

// Positions : 取得 pos 陣列
func (p *Payline) Positions() []int {
	return p.pos
}

// FetchSymbols : 取得 Payline 上的圖騰
func (p *Payline) FetchSymbols(slot *Slot) Grids {
	strip := NewGrid(slot.TotalReels())
	for i, pos := range p.pos {
		strip[i] = slot.grids[pos]
	}
	return strip
}
