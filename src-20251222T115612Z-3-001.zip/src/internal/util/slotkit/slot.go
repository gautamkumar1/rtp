package slotkit

// Slot :
type Slot struct {
	grids Grids
	reels []Grids
}

// NewSlot : 建立 slot
func NewSlot(reelsize ...int) *Slot {
	s := &Slot{}
	s.Create(reelsize...)
	return s
}

// Create :
func (s *Slot) Create(reelsize ...int) {
	length := 0
	for _, size := range reelsize {
		length += size
	}

	s.grids = NewGrid(length)
	s.reels = make([]Grids, len(reelsize))
	index := 0
	for i := range s.reels {
		length = reelsize[i]
		s.reels[i] = s.grids[index : index+length : index+length] // s.Slice(index, length)
		index += length
	}
}

// Reel : 取得指定滾輪陣列
func (s *Slot) Reel(index int) Grids {
	return s.reels[index]
}

// Reels : 取得所有滾輪陣列
func (s *Slot) Reels() []Grids {
	return s.reels
}

// TotalReels : 取得滾輪數量
func (s *Slot) TotalReels() int {
	return len(s.reels)
}

// Grids : 取得所有盤面內容
func (s *Slot) Grids() Grids {
	return s.grids
}

func (s *Slot) String() string {
	var str string = "["
	for _, reel := range s.reels {
		str += " " + reel.String()
	}
	str += " ]"
	return str
}
