package slot

import (
	"reflect"
	"testing"
)

func TestGetSymbolIDByStartIndex(t *testing.T) {
	type args struct {
		reel []int
		startIndex int
		getNum     int
	}
	tests := []struct {
		name         string
		args         args
		wantRetIndex []int
	}{
		{
			"0",
			args{
				[]int{0},
				0,
				1,
			},
			[]int{0},
		},
		{
			"1",
			args{
				[]int{1,1,1},
				0,
				3,
			},
			[]int{1,1,1},
		},
		{
			"2",
			args{
				[]int{1,1,1},
				0,
				1,
			},
			[]int{1},
		},
		{
			"3",
			args{
				[]int{0,1,2,2,2,2},
				0,
				3,
			},
			[]int{0,1,2},
		},
		{
			"4",
			args{

				[]int{0,1,2,3,4},
				3,
				5,
			},
			[]int{3,4,0,1,2},
		},
		{
			"5",
			args{
				[]int{1,2,3,4,5},
				1,
				3,
			},
			[]int{2,3,4},
		},
		{
			"6",
			args{
				[]int{1,2,3,4,5},
				4,
				3,
			},
			[]int{5,1,2},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotRetIndex := GetSymbolIDByStartIndex(tt.args.reel,tt.args.startIndex, tt.args.getNum); !reflect.DeepEqual(gotRetIndex, tt.wantRetIndex) {
				t.Errorf("GetReelIndex() = %v, want %v", gotRetIndex, tt.wantRetIndex)
			}
		})
	}
}

func TestGetReelIndex(t *testing.T) {
	type args struct {
		startIndex int
		reelLen    int
		getNum     int
	}
	tests := []struct {
		name         string
		args         args
		wantRetIndex []int
	}{
		{
			"0",
			args{
				0,
				0,
				1,
			},
			[]int{},
		},
		{
			"1",
			args{
				0,
				1,
				1,
			},
			[]int{0},
		},
		{
			"2",
			args{
				0,
				3,
				3,
			},
			[]int{0,1,2},
		},
		{
			"3",
			args{
				0,
				3,
				5,
			},
			[]int{0,1,2,0,1},
		},
		{
			"4",
			args{
				3,
				3,
				5,
			},
			[]int{},
		},
		{
			"5",
			args{
				3,
				4,
				5,
			},
			[]int{3,0,1,2,3},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if gotRetIndex := GetReelIndex(tt.args.startIndex, tt.args.reelLen, tt.args.getNum); !reflect.DeepEqual(gotRetIndex, tt.wantRetIndex) {
				t.Errorf("GetReelIndex() = %v, want %v", gotRetIndex, tt.wantRetIndex)
			}
		})
	}
}

func TestAddJPToResultReel(t *testing.T) {

	source0:=[][]int{{1},{1}}
	ele0:=0
	amount0:=2

	source1:=[][]int{{1,1,1},{1,1,1},{1,1,1},{2,2,2}}
	ele1:=1
	amount1:=3

	source2:=[][]int{{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1}}
	ele2:=1
	amount2:=5

	source3:=[][]int{{3},{3},{3},{3},{3}}
	ele3:=0
	amount3:=5

	type args struct {
		source       [][]int
		newElement   int
		modifyAmount int
	}
	tests := []struct {
		name    string
		args    args
		want    [][]int
		wantErr bool
	}{
		{
			"0",
			args{
				source0,
				ele0,
				amount0,
			},
			[][]int{{0},{0}},
			false,
		},
		{
			"1",
			args{
				source1,
				ele1,
				amount1,
			},
			[][]int{{1,1,1},{1,1,1},{1,1,1},{2,2,2}},
			false,
		},
		{
			"2",
			args{
				source2,
				ele2,
				amount2,
			},
			[][]int{{1,1,1},{1,1,1},{1,1,1},{1,1,1},{1,1,1}},
			false,
		},
		{
			"3",
			args{
				source3,
				ele3,
				amount3,
			},
			[][]int{{0},{0},{0},{0},{0}},
			false,
		},
	}
		for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := AddJPToResultReel(tt.args.source, tt.args.newElement, tt.args.modifyAmount)
			if (err != nil) != tt.wantErr {
				t.Errorf("AddJPToResultReel() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("AddJPToResultReel() got = %v, want %v", got, tt.want)
			}
		})
	}
}