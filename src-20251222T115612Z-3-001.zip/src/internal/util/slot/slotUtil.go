package slot

import (
	"fmt"

	"github.com/idtksrv/simulator-server/internal/util/rand"
)

func GetSymbolIDByStartIndex(reel []int, startIndex, getNum int) (retReel []int) {

	reelLen := len(reel)
	if reelLen == 0 || startIndex >= reelLen {
		return make([]int, 0)
	}

	retReel = make([]int, getNum)
	idx := 0

	for i := 0; i < getNum; i++ {
		idx = startIndex + i
		if idx >= reelLen {
			idx = idx % reelLen
		}

		retReel[i] = reel[idx]
	}
	return
}

// GetReelIndex 是從一個輪上取 n 個 element，從startIndex開始，往下取，
// startIndex 起始 index
// reelLen 	reel 長度
// getNum 總共取幾個
func GetReelIndex(startIndex, reelLen, getNum int) (retIndex []int) {

	if reelLen == 0 || startIndex >= reelLen {
		return make([]int, 0)
	}

	retIndex = make([]int, getNum)
	idx := 0

	for i := 0; i < getNum; i++ {
		idx = startIndex + i
		if idx >= reelLen {
			idx = idx % reelLen
		}

		retIndex[i] = idx
	}
	return
}

// RandomIndexOfWeightTable
// eg. [216,555,1000]
// random 1-1000
// 如果<=216, 回傳 index 0
// 如果 <=555, 回傳 index 1
func RandomIndexOfWeightTable(weightTable []int) (int, error) {

	wLen := len(weightTable)

	r := rand.Intn(weightTable[wLen-1]) + 1
	rr := int(r)

	for i, v := range weightTable {
		if v >= rr {
			return i, nil
		}
	}

	return 1, fmt.Errorf("index error")
}

// RandomStartIndexByTargetID random 從 reel 找到指定ID, 然後從取出指定數量的 IDs
// reel 原始 reel
// targetID 指定ID
func RandomStartIndexByTargetID(reel []int, targetID int) (retIdx int, retErr error) {

	rLen := len(reel)

	//起始找的 index
	rr := rand.Intn(rLen)

	//最多找 rLen次
	for i := 0; i < rLen; i++ {
		if rr >= rLen {
			rr = 0
		}
		if reel[rr] == targetID {
			return rr, nil
		}
		rr++
	}

	return -1, fmt.Errorf("targetID %d not found", targetID)
}

// AddJPToResultReel 用newElement 更改source slice的 element, 數量為 modifyAmount
func AddJPToResultReel(source [][]int, newElement int, modifyAmount int) ([][]int, error) {

	column := len(source) //5
	if column == 0 {
		return source, fmt.Errorf("source length want >0, got %d", len(source))
	}
	line := len(source[0]) //3

	if line == 0 {
		return source, fmt.Errorf("source[0] length want >0, got %d", len(source[0]))
	}

	if modifyAmount <= 0 {
		return source, fmt.Errorf("modifyAmount want >0, got %d", modifyAmount)
	}

	for i := 0; i < modifyAmount; i++ {
		source[i][rand.Intn(line)] = newElement
	}

	return source, nil
}
