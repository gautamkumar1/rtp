package slice

import "fmt"

type MatrixQueue struct {
	queue []*[][]int //pointer to [][]int
}

func NewMatrixQueue() *MatrixQueue {
	return &MatrixQueue{
		queue: []*[][]int{},
	}
}
func (m *MatrixQueue) Enqueue(matrix ...*[][]int) {
	m.queue = append(m.queue, matrix...)
}
func (m *MatrixQueue) Dequeue() *[][]int {
	var ret *[][]int = nil
	if len(m.queue) > 0 {
		ret = m.queue[0]
		m.queue = m.queue[1:]
	}
	return ret
}

//Get element but not remove it
func (m *MatrixQueue) Get(index int) *[][]int {
	if len(m.queue) > index {
		return m.queue[index]
	}
	return nil
}
func (m *MatrixQueue) ToString() string {
	s := "["
	for _, v := range m.queue {
		s += fmt.Sprintf("%v,", *v)
	}
	s += "]"
	return s
}
