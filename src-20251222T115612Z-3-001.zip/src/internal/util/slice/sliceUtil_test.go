package slice

import (
	"reflect"
	"testing"
)

func TestRandomElementIn2DSlice(t *testing.T) {
	type args struct {
		elementTable [][]int
	}
	tests := []struct {
		name    string
		args    args
		want    int
		wantErr bool
	}{
		{
			"0",
			args{
				[][]int{{1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
			},
			1,
			false,
		},
		{
			"1",
			args{
				[][]int{{2, 2, 2}, {2}},
			},
			2,
			false,
		},
		{
			"2",
			args{
				[][]int{{}},
			},
			-1,
			true,
		},
		{
			"3",
			args{
				[][]int{{1}, {1}, {1, 1, 1, 1, 1, 1, 1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}},
			},
			1,
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := RandomElementIn2DSlice(tt.args.elementTable)
			if (err != nil) != tt.wantErr {
				t.Errorf("RandomElementIn2DSlice() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("RandomElementIn2DSlice() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetTargetNewElementPosition(t *testing.T) {

	targetElement := []int{9}
	oriSlice := [][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}, {4, 4, 9}}
	newSlice := [][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 9}, {4, 9, 9}}

	type args struct {
		targetElement []int
		oriSlice      [][]int
		newSlice      [][]int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{targetElement,
				oriSlice,
				newSlice},
			[][]int{{2, 2}, {3, 1}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetTargetNewElementLocation(tt.args.targetElement, tt.args.oriSlice, tt.args.newSlice); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetTargetElementPosition() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDuplicate2DSlice(t *testing.T) {
	oriSlice := [][]int{{1, 2, 3}, {-1, -2, -3}}

	type args struct {
		matrix [][]int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{oriSlice},
			[][]int{{1, 2, 3}, {-1, -2, -3}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Duplicate2DSlice(tt.args.matrix); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Duplicate2DSlice() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestMake2DSlice(t *testing.T) {
	type args struct {
		defaultValue          int
		firstDimensionLength  int
		secondDimensionLength int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{-1, 5, 5},
			[][]int{{-1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1}},
		},
		{
			"1",
			args{1, 3, 5},
			[][]int{{1, 1, 1, 1, 1}, {1, 1, 1, 1, 1}, {1, 1, 1, 1, 1}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Make2DSlice(tt.args.defaultValue, tt.args.firstDimensionLength, tt.args.secondDimensionLength); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Make2DSlice() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestModifyIntArrayElement(t *testing.T) {
	type args struct {
		source       [][]int
		newEle       int
		modifyAmount int
	}
	tests := []struct {
		name       string
		args       args
		wantEleNum int
		wantErr    bool
	}{
		{
			"0",
			args{
				[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
				1,
				5,
			},
			5,
			false,
		},
		{
			"1",
			args{
				[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
				1,
				2,
			},
			2,
			false,
		},
		{
			"2",
			args{
				[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
				1,
				0,
			},
			3,
			true,
		},
		{
			"3",
			args{
				[][]int{},
				9,
				3,
			},
			3,
			true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ModifyIntSliceElement(tt.args.source, tt.args.newEle, tt.args.modifyAmount)

			if (err != nil) != tt.wantErr {
				t.Fatalf("wantErr not match")
			}

			if !tt.wantErr {

				newElementNum := 0
				for _, v := range got {
					for _, w := range v {
						if w == tt.args.newEle {
							newElementNum += 1
						}
					}
				}

				if newElementNum != tt.wantEleNum {
					t.Errorf("ModifyIntArrayElement() got newEle num= %d, want %d", newElementNum, tt.wantEleNum)
				}
			}
		})
	}
}

func TestSwitchIntArrayElement(t *testing.T) {
	type args struct {
		source    [][]int
		targetEle int
		newEle    int
	}
	tests := []struct {
		name          string
		args          args
		wantSlice     [][]int
		wantSwitchNum int
		wantErr       bool
	}{
		{
			"0",
			args{
				[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
				1,
				5,
			},
			[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
			0,
			false,
		},
		{
			"1",
			args{
				[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
				6,
				2,
			},
			[][]int{{2, 9, 5}, {8, 9, 4}, {5, 5, 3}},
			1,
			false,
		},
		{
			"2",
			args{
				[][]int{{6, 9, 5}, {8, 9, 4}, {5, 5, 3}},
				5,
				0,
			},
			[][]int{{6, 9, 0}, {8, 9, 4}, {0, 0, 3}},
			3,
			false,
		},
		{
			"3",
			args{
				[][]int{},
				9,
				3,
			},
			[][]int{},
			0,
			true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, gotSwitchNum := SwitchIntSliceElement(tt.args.source, tt.args.targetEle, tt.args.newEle)

			if gotSwitchNum != tt.wantSwitchNum {
				t.Fatalf("wantSwitchNum not match got %v want %v", gotSwitchNum, tt.wantSwitchNum)
			}
			if !reflect.DeepEqual(got, tt.wantSlice) {
				t.Fatalf("got not match got %v want %v", got, tt.wantSlice)
			}
		})
	}
}

func TestCountEveryElementAmountPerColumn(t *testing.T) {
	type args struct {
		reels [][]int
	}
	tests := []struct {
		name string
		args args
		want []map[int]int
	}{
		{
			"0",
			args{
				[][]int{{12, 1, 1}, {12, 2, 2}, {12, 12, 12}, {7, 8, 9}},
			},
			[]map[int]int{{12: 1, 1: 2}, {12: 1, 2: 2}, {12: 3}, {7: 1, 8: 1, 9: 1}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := CountEveryElementAmountPerColumn(tt.args.reels); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("CountEveryElementAmountPerColumn() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCountEveryElementAmount(t *testing.T) {
	type args struct {
		targetSlice []int
	}
	tests := []struct {
		name string
		args args
		want map[int]int
	}{
		{
			"0",
			args{
				[]int{1, 1, 1},
			},
			map[int]int{1: 3},
		},
		{
			"1",
			args{
				[]int{1, 1, 1, 2},
			},
			map[int]int{1: 3, 2: 1},
		},
		{
			"2",
			args{
				[]int{1, 1, 1, 2, 2, 3, 3, 3, 0},
			},
			map[int]int{1: 3, 2: 2, 3: 3, 0: 1},
		},
		{
			"3",
			args{
				[]int{2, 3, 4},
			},
			map[int]int{2: 1, 3: 1, 4: 1},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := CountEveryElementAmount(tt.args.targetSlice); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("CountEveryElementAmount() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestModifyMatrixByCompareAndTargetElement(t *testing.T) {

	type args struct {
		source        [][]int
		compare       [][]int
		targetElement int
		writeElement  int
	}
	tests := []struct {
		name    string
		args    args
		want    [][]int
		wantErr bool
	}{
		{
			"0",
			args{
				[][]int{{3, 6, 3}, {3, 6, 8}, {3, 6, 70}, {9, 3, 6}, {8, 8, 5}},
				[][]int{{1, -1, 1}, {1, -1, -1}, {1, -1, -1}, {-1, 1, -1}, {-1, -1, -1}},
				1,
				-1,
			},
			[][]int{{-1, 6, -1}, {-1, 6, 8}, {-1, 6, 70}, {9, -1, 6}, {8, 8, 5}},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ModifyMatrixByCompareAndTargetElement(tt.args.source, tt.args.compare, tt.args.targetElement, tt.args.writeElement)
			if (err != nil) != tt.wantErr {
				t.Errorf("ModifyMatrixByCompareAndTargetElement() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ModifyMatrixByCompareAndTargetElement() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDuplicate2DSlice1(t *testing.T) {
	type args struct {
		matrix [][]int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{
				[][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}},
			},
			[][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}},
		},
		{
			"1",
			args{
				[][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}, {4, 4, 4}},
			},
			[][]int{{1, 1, 1}, {2, 2, 2}, {3, 3, 3}, {4, 4, 4}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := Duplicate2DSlice(tt.args.matrix)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Duplicate2DSlice() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestSum2DSlice(t *testing.T) {
	type args struct {
		source [][]int
	}
	tests := []struct {
		name string
		args args
		want int
	}{
		{
			"0",
			args{
				[][]int{{1, 1, 1, 1}, {1, 1, 1, 1}},
			},
			8,
		},
		{
			"1",
			args{
				[][]int{{1, 1, 1, 1}, {1, 1, 1, 1}, {2, 2, 2, 2}, {0, 0, 0, 1}},
			},
			17,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Sum2DSlice(tt.args.source); got != tt.want {
				t.Errorf("Sum2DSlice() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestAdd2DSlice(t *testing.T) {
	type args struct {
		addValue    int
		exceptValue int
		source      [][]int
	}
	tests := []struct {
		name string
		args args
		want [][]int
	}{
		{
			"0",
			args{
				1,
				-1,
				[][]int{{1, 1, 1, 1}, {1, 1, 1, 1}},
			},
			[][]int{{2, 2, 2, 2}, {2, 2, 2, 2}},
		},

		{
			"1",
			args{
				-1,
				2,
				[][]int{{1, 1, 1, 1}, {1, 1, 1, 1}, {1, 1, 2, 2}},
			},
			[][]int{{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 2, 2}},
		},
		{
			"2",
			args{
				1,
				0,
				[][]int{{1, 1, 1, 1}, {1, 1, 1, 1}, {1, 1, 0, 0}},
			},
			[][]int{{2, 2, 2, 2}, {2, 2, 2, 2}, {2, 2, 0, 0}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Add2DSlice(tt.args.addValue, tt.args.exceptValue, tt.args.source); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Add2DSlice() = %v, want %v", got, tt.want)
			}
		})
	}
}
