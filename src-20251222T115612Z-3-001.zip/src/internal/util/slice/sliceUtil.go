package slice

import (
	"fmt"

	"github.com/idtksrv/simulator-server/internal/util/rand"
)

func RandomElementIn2DSlice(elementTable [][]int) (int, error) {

	eLen := len(elementTable)
	if eLen == 0 {
		return -1, fmt.Errorf("elementTable table length 0 %v", elementTable)
	}

	//dimension 1
	d1Ran := rand.Intn(eLen)

	//dimension 2
	d2 := elementTable[d1Ran]
	eLen = len(d2)
	if eLen == 0 {
		return -1, fmt.Errorf("elementTable dimension 2 length 0 %v", elementTable)
	}
	d2Ran := rand.Intn(eLen)

	return d2[d2Ran], nil

}

func Duplicate2DSlice(matrix [][]int) [][]int {
	duplicate := make([][]int, len(matrix))
	for i := range matrix {
		duplicate[i] = make([]int, len(matrix[i]))
		copy(duplicate[i], matrix[i])
	}
	//copy(duplicate, matrix)  //這樣不行
	return duplicate
}
func Duplicate2DFloatSlice(matrix [][]float32) [][]float32 {
	duplicate := make([][]float32, len(matrix))
	for i := range matrix {
		duplicate[i] = make([]float32, len(matrix[i]))
		copy(duplicate[i], matrix[i])
	}
	//copy(duplicate, matrix)  //這樣不行
	return duplicate
}

func Make2DSlice(defaultValue int, firstDimensionLength, secondDimensionLength int) [][]int {
	var retSlice [][]int
	for i := 0; i < firstDimensionLength; i++ {
		var r = make([]int, secondDimensionLength, secondDimensionLength)
		for j := 0; j < secondDimensionLength; j++ {
			r[j] = defaultValue
		}

		retSlice = append(retSlice, r)
	}
	return retSlice
}

func Make2DFloatSlice(defaultValue float32, firstDimensionLength, secondDimensionLength int) [][]float32 {
	var retSlice [][]float32
	for i := 0; i < firstDimensionLength; i++ {
		var r = make([]float32, secondDimensionLength, secondDimensionLength)
		for j := 0; j < secondDimensionLength; j++ {
			r[j] = defaultValue
		}

		retSlice = append(retSlice, r)
	}
	return retSlice
}

func MakeSlice(defaultValue int, length int) []int {
	var r = make([]int, length, length)
	for i := 0; i < length; i++ {
		r[i] = defaultValue
	}

	return r
}

// ShuffleSlice with creating new slice
func ShuffleSlice(sl []int) []int {
	ret := make([]int, len(sl))
	perm := rand.Perm(len(sl))
	for i, randIndex := range perm {
		ret[i] = sl[randIndex]
	}
	return ret
}

func Shuffle2DSlice(sl [][]int) [][]int {
	ret := make([][]int, len(sl))
	perm := rand.Perm(len(sl))
	for i, randIndex := range perm {
		ret[i] = sl[randIndex]
	}
	return ret
}

// GetTargetNewElementLocation
// target element []int{2}
// oriSlice [][]int{{1,1},{1,1}}
// newSlice [][]int{{1,2},{1,2}}
// location [][]int{{0,1},{0,1}}
// location 是採用紀錄 new target的位址，並非 scatter position 的方式
func GetTargetNewElementLocation(targetElement []int, oriSlice, newSlice [][]int) [][]int {

	var ret [][]int
	for rIndex, content := range newSlice {
		for cIndex, symbolID := range content {
			for _, s := range targetElement {
				//gameResult 是scatter, 同位置ori result 非 scatter
				if symbolID == s && oriSlice[rIndex][cIndex] != s {
					ret = append(ret, []int{rIndex, cIndex})
				}
			}
		}
	}
	return ret
}

// ModifyIntSliceElement 把目表的 slice 的 element 改成 new element，只改指定數量
func ModifyIntSliceElement(source [][]int, newElement int, modifyAmount int) ([][]int, error) {

	column := len(source) //5
	if column <= 0 {
		return source, fmt.Errorf("source length want >0, got %d", len(source))
	}
	line := len(source[0]) //3

	if line <= 0 {
		return source, fmt.Errorf("source[0] length want >0, got %d", len(source[0]))
	}

	if modifyAmount <= 0 {
		return source, fmt.Errorf("modifyAmount want >0, got %d", modifyAmount)
	}

	//make temp slice to store rand position
	temp := make([][]int, column)
	for i := range temp {
		temp[i] = make([]int, line)
	}

	//success rand position amount
	modifiedAmount := 0

	//
	var cn = 0
	var ln = 0

	for {
		cn = rand.Intn(column)
		ln = rand.Intn(line)
		if temp[cn][ln] == 0 {
			//modify temp slice
			temp[cn][ln] = 1

			//change source slice
			source[cn][ln] = newElement
			modifiedAmount += 1
		}

		if modifiedAmount >= modifyAmount {
			break
		}

	}

	return source, nil
}

// SwitchIntSliceElement 把目標的 slice 的 指定 element 改成 new element
func SwitchIntSliceElement(source [][]int, targetElement, newElement int) ([][]int, int) {

	temp := Duplicate2DSlice(source)

	switchNum := 0

	for i := 0; i < len(temp); i++ {
		v := temp[i]
		for j := 0; j < len(v); j++ {
			ele := v[j]
			if ele == targetElement {
				temp[i][j] = newElement
				switchNum++
			}
		}
	}

	return temp, switchNum
}

// CountEveryElementAmount 計算 slice 裡面每種 element 的數量
// [1,2,3,1]=1=2個，2=1個,3=1個
// return map[int]int{1:2,2:1,3:1}
func CountEveryElementAmount(targetSlice []int) map[int]int {
	visited := make(map[int]int, 0)

	for _, v := range targetSlice {
		if _, ok := visited[v]; ok {
			visited[v]++
		} else {
			visited[v] = 1
		}
	}
	return visited
}
func CountTargetElementAmount(targetSlice [][]int, targetElement int) int {
	amount := 0
	for _, v := range targetSlice {
		for _, vv := range v {
			if vv == targetElement {
				amount++
			}
		}
	}
	return amount
}

// CountEveryElementAmountPerColumn 算每個 reel 的每種 symbol有幾個
// m[0]=reel 0
// m[1]=reel 1
// []map[int]int={{1:3,2:1},{1:2,3:1}}  reel 0 symbol 1=3個，symbol 2=1個,reel 1 symbol 1=2個, symbol 3=1個
// m =[]map[int]int{}
func CountEveryElementAmountPerColumn(reels [][]int) []map[int]int {

	ret := make([]map[int]int, 0)
	wLen := len(reels)
	for i := 0; i < wLen; i++ {
		ret = append(ret, CountEveryElementAmount(reels[i]))
	}
	return ret
}

// IsTheSameSize 比對兩個 matrix 的 size 是否相同
func IsTheSameSize(source, compare [][]int) bool {
	wLen := len(compare)
	if wLen != len(source) {
		return false
	}

	for i := 0; i < wLen; i++ {
		if len(compare[i]) != len(source[i]) {
			return false
		}
	}
	return true
}

// ModifyMatrixByCompareAndTargetElement
// 比對 compare 的 element 如果是 targetElement，
// 則 source 的相同位置，也改成 targetElement.
// 兩者 size 必須相同，否則回傳 error
func ModifyMatrixByCompareAndTargetElement(source, compare [][]int, targetElement int, writeElement int) ([][]int, error) {
	wLen := len(compare)
	var lLen int

	if !IsTheSameSize(source, compare) {
		return source, fmt.Errorf("two matrix size not the same")
	}

	for i := 0; i < wLen; i++ {
		lLen = len(compare[i])
		for j := 0; j < lLen; j++ {
			if compare[i][j] == targetElement {
				source[i][j] = writeElement
			}
		}
	}
	return source, nil
}

// 除了targetElement, 其他 element 都改成 writeElement
func ModifyMatrixByReplaceAndTargetElement(source [][]int, targetElement int, writeElement int) ([][]int, error) {
	wLen := len(source)
	var lLen int

	for i := 0; i < wLen; i++ {
		lLen = len(source[i])
		for j := 0; j < lLen; j++ {
			if source[i][j] != targetElement {
				source[i][j] = writeElement
			}
		}
	}
	return source, nil
}

func Sum2DSlice(source [][]int) int {

	result := 0
	for _, v := range source {
		result += SumIntSlice(v...)
	}
	return result
}
func SumIntSlice(numbs ...int) int {
	result := 0
	for _, numb := range numbs {
		result += numb
	}
	return result
}

// Add2DSlice 所有element 加上 value, 除了原本 value 是 excepteValue 的不加
func Add2DSlice(addValue int, exceptValue int, source [][]int) [][]int {

	for _, v := range source {
		v = AddIntSlice(addValue, exceptValue, v...)
	}
	return source
}
func AddIntSlice(addValue int, exceptValue int, numbs ...int) []int {

	for i, v := range numbs {
		if v != exceptValue {
			numbs[i] = v + addValue
		}
	}
	return numbs
}
