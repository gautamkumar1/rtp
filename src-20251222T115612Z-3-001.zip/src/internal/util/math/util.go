package math

import (
	"fmt"
	"math"
	"strings"

	"github.com/idtksrv/simulator-server/internal/util/rand"
)

func Mean(v []float64) float64 {
	var res float64 = 0
	var n = len(v)
	for i := 0; i < n; i++ {
		res += v[i]
	}
	return res / float64(n)
}

func Variance(v []float64) float64 {
	var res float64 = 0
	var m = Mean(v)
	var n = len(v)
	for i := 0; i < n; i++ {
		res += (v[i] - m) * (v[i] - m)
	}
	return res / float64(n-1)
}
func StandardDeviation(v []float64) float64 {
	return math.Sqrt(Variance(v))
}

func CountDecimalNum(n float64) int {
	s := fmt.Sprintf("%v", n)
	if strings.Index(s, ".") == -1 {
		return 0
	}
	return len(strings.Split(s, ".")[1])

}

func DecideByTargetProbability(target string, probability map[string]float64) bool {

	if rtp, ok := probability[target]; ok {
		if rand.Float64() < rtp {
			return true
		}
	}
	return false
}

func DecideByProbability(probability float64) bool {

	if rand.Float64() < probability {
		return true
	}

	return false
}

// RandomElementByWeightTable 傳入 element table, weight table
// 兩 table 長度需相同
// random weight table index, 然後用 index 取 element table
func RandomElementByWeightTable(elementTable, weightTable []int) (int, error) {

	wLen := len(weightTable)
	if len(elementTable) != wLen {
		return -1, fmt.Errorf("length of two tables are not match")
	}

	r := rand.Int63n(int64(weightTable[wLen-1])) + 1
	rr := int(r)

	for i, v := range weightTable {
		if v >= rr {
			return elementTable[i], nil
		}
	}

	return -1, fmt.Errorf("index error")
}

// DivMod 除法取商數、餘數
// dividend 除數
// divisor 被除數
func DivMod(dividend, divisor int64) (quotient int64, remainder int64) {
	//x := big.NewInt(dividend)
	//y := big.NewInt(divisor)
	//
	//var q, r big.Int
	//q.DivMod(x, y, &r)
	//fmt.Printf("quotient: %v, remainder: %v\n", &q, &r)
	return dividend / divisor, dividend % divisor
}
