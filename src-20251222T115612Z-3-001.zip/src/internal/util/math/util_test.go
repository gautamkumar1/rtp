package math

import (
	"fmt"
	"testing"
)

func Test_math(t *testing.T) {

	var data = []float64{79, 84, 84, 88, 92, 93, 94, 97, 98, 99, 100, 101, 101, 102, 102, 108, 110, 113, 118, 125}
	fmt.Println("期望值：", Mean(data))
	fmt.Println("變異數(方差)：", Variance(data))
	fmt.Println("標準差：", StandardDeviation(data))

}

func TestCountDecimalNum(t *testing.T) {
	type args struct {
		n float64
	}
	tests := []struct {
		name string
		args args
		want int
	}{
		{
			"0",
			args{
				1,
			},
			0,
		},
		{
			"0",
			args{
				1.110,
			},
			2,
		},
		{
			"0",
			args{
				1.1110011,
			},
			7,
		},
		{
			"2",
			args{
				502.100000,
			},
			1,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := CountDecimalNum(tt.args.n); got != tt.want {
				t.Errorf("CountDecimalNum() = %v, want %v", got, tt.want)
			}
		})
	}
}
