package configuration

import "encoding/json"

const (
	Game1601 = 1601
	Game1602 = 1602
	Game1603 = 1603
	Game1604 = 1604
	Game1605 = 1605
	Game1811 = 1811
	Game1812 = 1812
	Game1813 = 1813
	Game1815 = 1815
	Game1816 = 1816
	Game1908 = 1908
	Game1822 = 1822
	Game1905 = 1905
	Game1906 = 1906
	Game1907 = 1907
	Game1818 = 1818
	Game1817 = 1817
	Game1819 = 1819
	Game1820 = 1820
	Game1900 = 1900
	Game1901 = 1901
	Game1902 = 1902
	Game2000 = 2000
	Game2001 = 2001

	Simulator3x5                         = 1601
	SimulatorScratchGame                 = 1811
	Simulator3X3IndependentWheel         = 1817
	Simulator3x5FreeSpinMode             = 1813
	Simulator5x3FreeSpinWildExpanding    = 1818
	Simulator3X3MultiplierTime           = 2100
	Simulator5x3Clown                    = 2200
	Simulator1x1Lion                     = 2300
	Simulator3x5FreeGameTwoWay           = 2400
	SimulatorEraseGame                   = 2500
	SimulatorHoldAndSpinScatterOnly      = 2600
	SimulatorHoldAndSpinAccumulateCredit = 2700
	Simulator3X3Multiplier               = 2800
	SimulatorCascadeGame                 = 2900
	Simulator4x5Mystery                  = 3000
	Simulator4x5MightyWheel              = 3100
	Simulator4x5StickyWild               = 3200
	Simulator3300                        = 3300
	Simulator3400                        = 3400
	Simulator3500                        = 3500
	Simulator3510                        = 3510
	Simulator3600                        = 3600
	Simulator3700                        = 3700
	Simulator3800                        = 3800
	Simulator3900                        = 3900
	Simulator4000                        = 4000
	Simulator4100                        = 4100
	Simulator4200                        = 4200
	Simulator4300                        = 4300
	Simulator4400                        = 4400
	Simulator4500                        = 4500
	Simulator4600                        = 4600
	Simulator4700                        = 4700
	Simulator4800                        = 4800

	MainGame5x3                   = 1601
	MainGameScratch               = 1811
	MainGame5x3FreeSpinMode       = 1813
	MainGame5x3FreeGameWild       = 1818
	MainGame3X3IndependentSpecial = 1817
	MainGame3X3MultiplierTime     = 2100
	MainGame5X3NoJackPotClown     = 2200
	MainGame1X1NoJackPotLion      = 2300
	MainGame3x5FreeGameTwoWay     = 2400
	MainGame6X5Drop               = 2500
	MainGameNoNeed2600            = 2600
	MainGameNoNeed2700            = 2700
	MainGameNoNeed2800            = 2800
	MainGameNoNeed2900            = 2900
	MainGameNoNeed3000            = 3000
	MainGameNoNeed3100            = 3100
	MainGameNoNeed3200            = 3200
	MainGameNoNeed3300            = 3300
	MainGameNoNeed3400            = 3400
	MainGameNoNeed3500            = 3500
	MainGameNoNeed3510            = 3510
	MainGameNoNeed3600            = 3600
	MainGameNoNeed3700            = 3700
	MainGameNoNeed3800            = 3800
	MainGameNoNeed3900            = 3900
	MainGameNoNeed4000            = 4000
	MainGameNoNeed4100            = 4100
	MainGameNoNeed4200            = 4200
	MainGameNoNeed4300            = 4300
	MainGameNoNeed4400            = 4400
	MainGameNoNeed4500            = 4500
	MainGameNoNeed4600            = 4600
	MainGameNoNeed4700            = 4700
	MainGameNoNeed4800            = 4800

	NoFeatureGame          = -1
	FeatureGame3x1         = 1601
	FeatureFreeGame5X3     = 510
	FeatureFreeWildGame5X3 = 520
	FeatureIndependent     = 530

	Jackpot800 = 800
	NoJackpot  = -1

	CodeSuccess int = 0
	CodeError   int = 100
	CodePanic   int = 101

	// http request / response
	CodeBodyReadError  int = 200
	CodeUnmarshalError int = 201

	//CmdSpin protocol command
	CmdSpin        string = "spin"
	CmdGetUserData string = "get_user_data"
	Unmarshal      string = "Unmarshal Fail"

	RTPDefault string = "98.5"

	BuySpinNormal = 0
	BuySpinYes    = 1

	SymbolIDNotUse = -1
	SymbolIDHas    = 1

	ScatterWeightTableModeRandom   = 0
	ScatterWeightTableModeSequence = 1

	HoldAndSpinScatterOnlyCountCreditModeFinalCount = 0 //算錢方式，最後結算
	HoldAndSpinScatterOnlyCountCreditModeAccumulate = 1 //算錢方式，每次有中scatter, 整個輪面都算一次
)

type RequestModule struct {
	Command string `json:"command"`
	Data    struct {
		GameID    int     `json:"game_id"`
		LineBet   float64 `json:"line_bet"`
		LineNum   int     `json:"line_num"`
		CoinValue float64 `json:"coin_value"`
		BetCredit float64 `json:"bet_credit"`
		OrderID   int64   `json:"order_id"`
		RTP       string  `json:"rtp"`
		BuySpin   int     `json:"buy_spin"`
		UserID    int64   `json:"user_id"`
	} `json:"data"`
}
type ResponseModule struct {
	Command   string          `json:"command"`
	ErrorCode int             `json:"error_code"`
	Message   string          `json:"message"`
	Data      json.RawMessage `json:"data"`
}
