package configuration

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
)

type Configurator struct {
	Version              string
	ExtraMainGameSetting []string //額外載入的 main game setting
	Simulator            []*SimulatorSetting
	Jackpot              []*JackpotSetting
	MainGame             []*GameSetting
	FeatureGame          []*GameSetting
	currentPath          string
	logPath              string
}
type SimulatorSetting struct {
	SimulatorID          int
	GameID               int
	MainGameType         int
	MainGameSettingID    int //18系列 MainGameScratch
	FeatureGameType      int
	FeatureGameSettingID int //16系列 MainGame5x3
	JackpotType          int
	JackpotID            int // jackpot 對照表
	GameIndex            int
}
type GameSetting struct {
	GameType    int
	GameSetting json.RawMessage
}
type JackpotSetting struct {
	JackpotType    int
	JackpotSetting json.RawMessage
	OpenGrand      bool
}

// NewConfigurator returns configurator.
func NewConfigurator(fileName string, searchPath ...string) (*Configurator, error) {

	cf := &Configurator{}
	configFilePath := getFileLocation(fileName, searchPath...)
	err := cf.loadConfig(configFilePath)
	if err != nil {
		return nil, err
	}

	err = cf.appendExtraMainGameSettings()
	if err != nil {
		return nil, err
	}
	return cf, nil
}

func (c *Configurator) GetSettings(gameId int) (sd *SimulatorSetting, mgs *GameSetting, sgs *GameSetting, jps *JackpotSetting, err error) {

	if sd, err = c.GetSimulatorSetting(gameId); err != nil {
		return nil, nil, nil, nil, fmt.Errorf("GetSimulatorSetting error %v", err.Error())
	}

	// 取得 config-xxxx.json 的 設定
	if mgs, err = c.GetMainGameSetting(sd.MainGameType, sd.MainGameSettingID); err != nil {
		return nil, nil, nil, nil, fmt.Errorf("GetMainGameSetting error %v", err.Error())
	}
	// 取得 feature game 設定
	if sd.FeatureGameType != NoFeatureGame && sd.FeatureGameSettingID != -1 {
		sgs, err = c.GetFeatureGameSetting(sd.FeatureGameType, sd.FeatureGameSettingID)
		if err != nil {
			return nil, nil, nil, nil, fmt.Errorf("GetFeatureGameSetting error %v", err.Error())
		}
	}

	// 取得 jackpot 設定
	if sd.JackpotType != NoJackpot {
		jps, err = c.GetJackpotSetting(sd.JackpotType)
		if err != nil {
			return nil, nil, nil, nil, fmt.Errorf("GetJackpotSetting error %v", err.Error())
		}
	}

	return sd, mgs, sgs, jps, nil
}

// 取得 config.json 設定檔 內的 setting 資料
func (c *Configurator) GetSimulatorSetting(gameID int) (*SimulatorSetting, error) {

	//var gID []gameIDonSettingMapping
	for index, v := range c.Simulator {
		if v.GameID == gameID {
			v.GameIndex = index
			return v, nil
		}
	}
	return nil, fmt.Errorf("game id not found got %d", gameID)
}

// 取得 config-xxxx.json 的
func (c *Configurator) GetMainGameSetting(gameType int, mainGameSettingID int) (*GameSetting, error) {
	for _, v := range c.MainGame {
		if v.GameType == gameType {
			var gs []SimulatorSetting
			if err := json.Unmarshal(v.GameSetting, &gs); err != nil {
				return nil, fmt.Errorf("GetMainGameSetting Unmarshal fail %d", gameType)
			}
			for _, g := range gs {
				if g.MainGameSettingID == mainGameSettingID {
					return v, nil
				}
			}
		}
	}
	return nil, fmt.Errorf("game type not found got %d", gameType)
}

// 取得 config-xxxx.json 的 設定
func (c *Configurator) GetFeatureGameSetting(gameType int, featureGameSettingID int) (*GameSetting, error) {
	for _, v := range c.FeatureGame {
		if v.GameType == gameType && FeatureGame3x1 == gameType { //using gameType to classification
			var gs []SimulatorSetting
			if err := json.Unmarshal(v.GameSetting, &gs); err != nil {
				return nil, fmt.Errorf("GetFeatureGameSetting Unmarshal fail %d", gameType)
			}
			for _, va := range gs {
				if va.FeatureGameSettingID == featureGameSettingID {
					return v, nil
				}
			}
		}
		if v.GameType == gameType && FeatureFreeGame5X3 == gameType {
			var gs []SimulatorSetting
			if err := json.Unmarshal(v.GameSetting, &gs); err != nil {
				return nil, fmt.Errorf("GetFeatureGameSetting Unmarshal fail %d", gameType)
			}
			for _, va := range gs {
				if va.FeatureGameSettingID == featureGameSettingID {
					return v, nil
				}
			}
		}

		if v.GameType == gameType && FeatureFreeWildGame5X3 == gameType {
			var gs []SimulatorSetting
			if err := json.Unmarshal(v.GameSetting, &gs); err != nil {
				return nil, fmt.Errorf("GetFeatureGameSetting Unmarshal fail %d", gameType)
			}
			for _, va := range gs {
				if va.FeatureGameSettingID == featureGameSettingID {
					return v, nil
				}
			}
		}

		if v.GameType == gameType && FeatureIndependent == gameType {
			var gs []SimulatorSetting
			if err := json.Unmarshal(v.GameSetting, &gs); err != nil {
				return nil, fmt.Errorf("GetFeatureGameSetting Unmarshal fail %d", gameType)
			}
			for _, va := range gs {
				if va.FeatureGameSettingID == featureGameSettingID {
					return v, nil
				}
			}
		}
	}
	return nil, fmt.Errorf("game type GetFeatureGameSetting not found got %d", gameType)
}

func (c *Configurator) GetJackpotSetting(jackpotType int) (*JackpotSetting, error) {
	for _, v := range c.Jackpot {
		if v.JackpotType == jackpotType {
			return v, nil
		}
	}
	return nil, fmt.Errorf("jackpot type not found got %d", jackpotType)
}

func getFileLocation(fileName string, searchPath ...string) string {
	for _, path := range searchPath {
		filePath := filepath.Join(path, fileName)
		if _, err := os.Stat(filePath); err == nil {
			return filePath
		}
	}
	dir, err := filepath.Abs(filepath.Dir(os.Args[0]))
	if err != nil {
	}

	var buf bytes.Buffer
	buf.WriteString(dir)
	buf.WriteString("/")
	buf.WriteString(fileName)

	return buf.String()
}

func (c *Configurator) loadConfig(filePath string) error {

	b, err := os.ReadFile(filePath)
	if err != nil {
		return err
	}

	//unmarshal to struct
	if err := json.Unmarshal(b, &c); err != nil {
		return err
	}

	// 記錄當前路徑
	// 這個路徑是 config.json 的路徑
	c.currentPath = filepath.Dir(filePath)
	return nil
}

func (c *Configurator) appendExtraMainGameSettings() error {

	for _, fileName := range c.ExtraMainGameSetting {
		mgs, err := c.loadExtraMainGameSetting(fileName)
		if err != nil {
			return err
		}
		c.MainGame = append(c.MainGame, mgs)
	}
	return nil
}

func (c *Configurator) loadExtraMainGameSetting(fileName string) (*GameSetting, error) {
	// filePath := getFileLocation(fileName, c.currentPath)
	filePath := filepath.Join(c.currentPath, fileName)

	cf := &GameSetting{}

	b, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	//unmarshal to struct
	if err := json.Unmarshal(b, &cf); err != nil {
		return nil, err
	}
	return cf, nil
}
