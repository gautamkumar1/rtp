package jackpot800

import (
	"encoding/json"
	"reflect"
	"testing"

	"github.com/idtksrv/simulator-server/internal/util/rand"
	_ "github.com/shopspring/decimal"
)

var (
	js = &JackpotSetting{
		1000000000000000,
		40708,
		316615,
		678461,
		4070769,
		0.0012,
		0.0008,
		0.0006,
		0.00004,
		1,
	}
	jp1601 = &Jackpot{
		800,
		js,
		false,
	}
)

func TestRand(t *testing.T) {

	for i := 0; i < 1; i++ {
		r := rand.Intn(1.e+15)
		t.Logf("rand.Intn %d ", r)
	}
}

func TestJackpot_GetResult(t *testing.T) {
	var forAppend []*JackpotSetting
	forAppend = append(forAppend, js)
	gb, _ := json.Marshal(forAppend)

	jp, _ := NewJackpot(jp1601.JackpotType, gb, 1, false) //參照json檔案去調整

	gotTimes := 0
	for i := 0; i < 100000; i++ {
		get, r, _ := jp.GetResult(10000, 1)
		if get {
			gotTimes += 1
			t.Logf("getJackpot %v, result %+v", get, r)
		}
	}
	t.Logf("getJackpot times %d ", gotTimes)
}

/*
	func BenchmarkGet1601Result(b *testing.B) {
		var forAppend []*JackpotSetting
		forAppend = append(forAppend, js)
		gb, _ := json.Marshal(forAppend)
		game, _ := NewJackpot(jp1601.JackpotType, gb, 1,false) //參照json檔案去調整

		var bet = 3000000.0
		var count = 0
		var getJP = 0
		var grandJP = 0
		var majorJP = 0
		var minorJP = 0
		var miniJP = 0
		var totalBet = 0.0
		var totalPrize = 0.0

		originalGrandSeed := 150000000.0
		originalMajorSeed := 15000000.0
		originalMinorSeed := 5000000.0
		originalMiniSeed := 500000.0

		grandSeed := originalGrandSeed
		majorSeed := originalMajorSeed
		minorSeed := originalMinorSeed
		miniSeed := originalMiniSeed

		grandIncrementRate := 0.0012
		majorIncrementRate := 0.0008
		minorIncrementRate := 0.0006
		miniIncrementRate := 0.0004

		//每一秒可以跑的次數
		for i := 0; i < 1000000000; i++ {
			//分流錢
			grandSeed += bet * grandIncrementRate
			majorSeed += bet * majorIncrementRate
			minorSeed += bet * minorIncrementRate
			miniSeed += bet * miniIncrementRate
			get, retResponse, _ := game.GetResult(bet, 1)
			if get {
				getJP += 1

				prize := retResponse.JackpotID
				switch prize {
				case jackpot.Grand:
					//fmt.Printf("grandSeed %v \n", int64(grandSeed))
					totalPrize += grandSeed
					grandSeed = originalGrandSeed
					grandJP += 1
				case jackpot.Major:
					//fmt.Printf("majorSeed %v \n", int64(majorSeed))
					totalPrize += majorSeed
					majorSeed = originalMajorSeed
					majorJP += 1
				case jackpot.Minor:
					//fmt.Printf("minorSeed %v \n", int64(majorSeed))
					totalPrize += minorSeed
					minorSeed = originalMinorSeed
					minorJP += 1
				case jackpot.Mini:
					//fmt.Printf("miniSeed %v \n", int64(majorSeed))
					totalPrize += miniSeed
					miniSeed = originalMiniSeed
					miniJP += 1
				}
			}
			totalBet += bet
			count += 1
		}

		b.Logf("getJP %d count %v\n", getJP, count)
		b.Logf("Grand :%v , Major : %v , Minor : %v , Mini : %v\n", grandJP, majorJP, minorJP, miniJP)
		b.Logf("TotalBet %d TotalPrize %d RTP: %v\n", int64(totalBet), int64(totalPrize), totalPrize/totalBet)
	}
*/
func TestJackpot_CountIncrementCredit(t *testing.T) {

	var forAppend []*JackpotSetting
	forAppend = append(forAppend, js)
	gb, _ := json.Marshal(forAppend)

	jp, _ := NewJackpot(jp1601.JackpotType, gb, 1, false) //參照json檔案去調整

	type args struct {
		betCredit float64
	}
	tests := []struct {
		name string
		args args
		want *IncrementCredit
	}{
		{"0",
			args{
				10000,
			},
			&IncrementCredit{
				12,
				8,
				6,
				0.4,
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := jp.CountIncrementCredit(tt.args.betCredit)
			if !reflect.DeepEqual(got, tt.want) {
				t.Fatalf("Jackpot.CountIncrementCredit() = %v, want %v", got, tt.want)
			}
			t.Logf("%+v\n", got)

		})
	}
}
