package jackpot800

import (
	"encoding/json"

	"github.com/idtksrv/simulator-server/internal/jackpot"
	"github.com/idtksrv/simulator-server/internal/util/rand"
	"github.com/pkg/errors"
	"github.com/shopspring/decimal"
)

//用在5x3主遊戲上
//每一輪會有一個小輪
//每個小輪是一個 [1,1,1] 這樣的輪面,有3欄
// 1列的FeatureGame，欄位數不限

type Jackpot struct {
	JackpotType    int
	JackpotSetting *JackpotSetting
	OpenGrand      bool
}
type JackpotSetting struct {
	Denominator        int64   //分母
	GrandProbability   float64 //grand 機率/分子
	MajorProbability   float64
	MinorProbability   float64
	MiniProbability    float64
	GrandIncrementRate float64 //grand 依據投注額，增加多少比例到grand
	MajorIncrementRate float64
	MinorIncrementRate float64
	MiniIncrementRate  float64
	JackpotID          int
}

type Result struct {
	JackpotID     string  `json:"jackpot_id"`
	JackpotCredit float64 `json:"jackpot_credit"`
	SymbolID      []int   `json:"symbol_id"`
}

// IncrementCredit 是回傳的結果
type IncrementCredit struct {
	Grand float64 `json:"grand"`
	Major float64 `json:"major"`
	Minor float64 `json:"minor"`
	Mini  float64 `json:"mini"`
}

func NewJackpot(jType int, setting []byte, jackpotID int, openGrand bool) (*Jackpot, error) {

	g := &Jackpot{}
	g.JackpotType = jType
	g.OpenGrand = openGrand
	var gs []JackpotSetting

	if err := json.Unmarshal(setting, &gs); err != nil {
		return nil, err
	}
	for index, setting := range gs {
		if setting.JackpotID == jackpotID {
			g.JackpotSetting = &gs[index]
			return g, nil
		}
	}

	return nil, errors.Errorf("JackpotSetting not found")
}

func (j *Jackpot) GetNoResult() *Result {
	return &Result{"", 0, []int{}}
}

// GetResult 用betCredit算出各種jackpot的金額
func (j *Jackpot) GetResult(betCredit float64, symbolID int) (retGetJackpot bool, retResponse *Result, retErr error) {

	retGetJackpot = false
	retResponse = &Result{
		"",
		0,
		[]int{},
	}

	rr := rand.Int63n(j.JackpotSetting.Denominator)

	//機率, 跟投注額有關
	grand := int64(j.JackpotSetting.GrandProbability * betCredit)
	major := int64(j.JackpotSetting.MajorProbability * betCredit)
	minor := int64(j.JackpotSetting.MinorProbability * betCredit)
	mini := int64(j.JackpotSetting.MiniProbability * betCredit)

	p1 := grand + major
	p2 := p1 + minor
	p3 := p2 + mini

	retGetJackpot, retResponse.JackpotID = j.choseJackpot(rr, grand, p1, p2, p3)
	retResponse.SymbolID = j.getJackpotSymbolID(retResponse.JackpotID, symbolID)

	return
}

// CountIncrementCredit 用betCredit算出各種增加jackpot的金額
func (j *Jackpot) CountIncrementCredit(betCredit float64) *IncrementCredit {

	bet := decimal.NewFromFloat(betCredit)
	grand := decimal.NewFromFloat(j.JackpotSetting.GrandIncrementRate)
	major := decimal.NewFromFloat(j.JackpotSetting.MajorIncrementRate)
	minor := decimal.NewFromFloat(j.JackpotSetting.MinorIncrementRate)
	mini := decimal.NewFromFloat(j.JackpotSetting.MiniIncrementRate)

	j0, _ := bet.Mul(grand).Float64()
	j1, _ := bet.Mul(major).Float64()
	j2, _ := bet.Mul(minor).Float64()
	j3, _ := bet.Mul(mini).Float64()

	return &IncrementCredit{j0, j1, j2, j3}
}

func (j *Jackpot) choseJackpot(rr, grandRate, majorRate, minorRate, miniRate int64) (isJP bool, jpID string) {
	//if rr <= grandRate {
	//	return  jackpot.Grand
	//}

	if rr <= majorRate {
		return true, jackpot.Major
	}
	if rr <= minorRate {
		return true, jackpot.Minor
	}

	if rr <= miniRate {
		return true, jackpot.Mini
	}
	return false, ""
}

// getJackpotSymbolID 應該有幾個jackpot symbol
func (j *Jackpot) getJackpotSymbolID(jackpotID string, symbolID int) []int {
	switch jackpotID {
	//case jackpot.Grand:
	//	return []int{symbolID, symbolID, symbolID, symbolID,symbolID}
	case jackpot.Major:
		return []int{symbolID, symbolID, symbolID, symbolID}
	case jackpot.Minor:
		return []int{symbolID, symbolID, symbolID}
	case jackpot.Mini:
		return []int{symbolID, symbolID}
	default:
		return []int{}
	}
}
