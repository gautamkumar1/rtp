package jackpot

const (
	Grand = "grand"
	Major = "major"
	Minor = "minor"
	Mini  = "mini"
)
